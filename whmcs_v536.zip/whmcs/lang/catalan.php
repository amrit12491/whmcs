<?php
/**
 * WHMCS Language File
 * Catalan (ca)
 *
 * Please Note: These language files are overwritten during software updates
 * and therefore editing of these files directly is not advised. Instead we
 * recommend that you use overrides to customise the text displayed in a way
 * which will be safely preserved through the upgrade process.
 *
 * For instructions on overrides, please visit:
 *   http://docs.whmcs.com/Language_Overrides
 *
 * @package    WHMCS
 * @author     WHMCS Limited <development@whmcs.com>
 * @copyright  Copyright (c) WHMCS Limited 2005-2013
 * @license    http://www.whmcs.com/license/ WHMCS Eula
 * @version    $Id$
 * @link       http://www.whmcs.com/
 */

if (!defined("WHMCS")) die("This file cannot be accessed directly");

$_LANG['isocode'] = "ca";

$_LANG['accountinfo'] = "Informació de Compte";
$_LANG['accountstats'] = "Estadístiques del seu Compte";
$_LANG['addfunds'] = "Afegir Fons";
$_LANG['addfundsamount'] = "Quantitat a Afegir";
$_LANG['addfundsmaximum'] = "Dipòsit Màxim";
$_LANG['addfundsmaximumbalance'] = "Balanç Màxim";
$_LANG['addfundsmaximumbalanceerror'] = "Quantitat Màxima Balanç és";
$_LANG['addfundsmaximumerror'] = "Quantitat Màxima a Dipositar és";
$_LANG['addfundsminimum'] = "Dipòsit Mínim";
$_LANG['addfundsminimumerror'] = "Quantitat Mínima a Dipositar és";
$_LANG['addmore'] = "Afegir més";
$_LANG['addtocart'] = "Afegir al Carro";
$_LANG['affiliatesactivate'] = "Activar Compte d' Afiliat";
$_LANG['affiliatesamount'] = "Total";
$_LANG['affiliatesbalance'] = "Balanç Actual";
$_LANG['affiliatesbullet1'] = "Rebi al seu Compte un dipòsit (bonificació inicial) de:";
$_LANG['affiliatesbullet2'] = "de cada pagament fet per cada client que vostè ens enviï";
$_LANG['affiliatescommission'] = "Comissió";
$_LANG['affiliatesdescription'] = "Feu clic aquí per esdevenir afiliat o per veure els seus guanys";
$_LANG['affiliatesdisabled'] = "Ho sentim, actualment no oferim el sistema d'afiliat.";
$_LANG['affiliatesearn'] = "Guanyi";
$_LANG['affiliatesearningstodate'] = "Total guanyat fins ara";
$_LANG['affiliatesfootertext'] = "quan vostè ens refereix un client a la nostra web amb el seu ID únic d' Afiliat, una cookie amb la seva ID és col · locada al PC de la persona esmentada. Així, si la persona que ens refereix torna a visitar la nostra web, el nostre sistema detecta la cookie i assigna la comissió en el seu compte d´afiliat. ";
$_LANG['affiliateshostingpackage'] = "Producte / Servei";
$_LANG['affiliatesintrotext'] = "Activi avui mateix el seu Compte de Afiliat per:";
$_LANG['affiliateslinktous'] = "Enllaci amb nosaltres";
$_LANG['affiliatesnosignups'] = "No s'ha rebut cap activació nova";
$_LANG['affiliatesrealtime'] = "Aquestes són Estadístiques en temps real i actualitzades instantàniament.";
$_LANG['affiliatesreferallink'] = "El seu URL únic per referir clients";
$_LANG['affiliatesreferals'] = "Els seus Referits";
$_LANG['affiliatesregdate'] = "Data de Registre";
$_LANG['affiliatesrequestwithdrawal'] = "Request Withdrawal";
$_LANG['affiliatessignupdate'] = "Data d'Activació";
$_LANG['affiliatesstatus'] = "Estat";
$_LANG['affiliatestitle'] = "Afiliacions";
$_LANG['affiliatesvisitorsreferred'] = "Nombre de Visitants Referits";
$_LANG['affiliateswithdrawalrequestsuccessful'] = "La seva petició ha estat rebuda. Li contactarem en breu.";
$_LANG['affiliateswithdrawn'] = "Total disponible per Retirar";
$_LANG['all'] = "Tot";
$_LANG['alreadyregistered'] = "Està Registrat?:";
$_LANG['announcementsdescription'] = "Veure les últimes notícies i anuncis";
$_LANG['announcementsnone'] = "No Hi Anuncis per Mostrar";
$_LANG['announcementsrss'] = "Veure RSS";
$_LANG['announcementstitle'] = "Promocions";
$_LANG['bannedbanexpires'] = "La Prohibició Venç";
$_LANG['bannedbanreason'] = "Raons de la Prohibició";
$_LANG['bannedhasbeenbanned'] = "ha estat prohibida";
$_LANG['bannedtitle'] = "IP Prohibida";
$_LANG['bannedyourip'] = "La seva IP";
$_LANG['cartaddons'] = "Complements";
$_LANG['cartbrowse'] = "Resum de Productes i Serveis";
$_LANG['cartconfigdomainextras'] = "Configurar Dominis";
$_LANG['cartconfigoptionsdesc'] = "El Producte / Servei triat té algunes opcions que vostè pot triar a continuació per personalitzar la seva Comanda.";
$_LANG['cartconfigserver'] = "Configuri Servidor";
$_LANG['cartcustomfieldsdesc'] = "El Producte / Servei requereix d'informació addicional abans de processar la Comanda. Si us plau, ompli les dades necessàries.";
$_LANG['cartdomainsconfig'] = "Configuració de Dominis";
$_LANG['cartdomainsconfigdesc'] = "A continuació pot configurar els serveis extres relacionats amb el domini, ingressar informació requerida o definir les DNS que utilitzarà.";
$_LANG['cartdomainshashosting'] = "Té Allotjament";
$_LANG['cartdomainsnohosting'] = "Afegiu Pla d' allotjament al seu domini, AQUÍ!";
$_LANG['carteditproductconfig'] = "Edita Configuració";
$_LANG['cartempty'] = "El seu Carro de Comandes està Buit";
$_LANG['cartemptyconfirm'] = "Està segur de voler buidar la cistella?";
$_LANG['cartexistingclientlogin'] = "Accés al seu compte client";
$_LANG['cartexistingclientlogindesc'] = "Per a afegir aquesta Comanda al seu compte necessita identificar-se.";
$_LANG['cartnameserversdesc'] = "Si vol personalitzar les DNS pot introduir a continucació. Per defecte, els nous dominis utilitzaràn les nostres DNS perquè apuntin als nostres servidors.";
$_LANG['cartproductaddons'] = "Complement Producte";
$_LANG['cartproductaddonschoosepackage'] = "Canviar Pla";
$_LANG['cartproductaddonsnone'] = "Complements no permesos per per els seus Productes i Serveis";
$_LANG['cartproductconfig'] = "Configuració de Productes";
$_LANG['cartproductdesc'] = "El Producte / Servei que ha triat té les opcions de configuració següents. Modifiqueu les que li interessin.";
$_LANG['cartproductdomain'] = "Dominis";
$_LANG['cartproductdomainchoose'] = "Escollir Domini";
$_LANG['cartproductdomaindesc'] = "El Producte / Servei que has triat requereix d'un nom de domini. Trii l'opció que desitgi de les següents i introduïu un nom de domini.";
$_LANG['cartproductdomainuseincart'] = "Utilitzar un Domini existent en el meu Carro de Comanda";
$_LANG['cartremove'] = "Elimina";
$_LANG['cartremoveitemconfirm'] = "Està segur que vol eliminar aquest article de la cistella?";
$_LANG['carttaxupdateselections'] = "Els impostos seran carregats depenent del país o estat seleccionat. click per recalcular després de fer els canvis.";
$_LANG['carttaxupdateselectionsupdate'] = "Actualitzar";
$_LANG['carttitle'] = "Carro de Comandes";
$_LANG['changessavedsuccessfully'] = "Canvis guardats satisfactòriament!";
$_LANG['checkavailability'] = "Comprovar Disponibilitat";
$_LANG['checkout'] = "Processar Comanda";
$_LANG['choosecurrency'] = "Triar Divisa";
$_LANG['choosedomains'] = "Triar Dominis";
$_LANG['clickheretologin'] = "click aquí per entrar";
$_LANG['clientareaaccountaddons'] = "addicionals per al Compte";
$_LANG['clientareaactive'] = "Actiu";
$_LANG['clientareaaddfundsdisabled'] = "Actualment no permetem dipositar fons per avançat.";
$_LANG['clientareaaddfundsnotallowed'] = "Vostè ha de tenir com a mínim una ordre activa abans d'afegir fons, per tant no pot fer-ho en aquest moment!";
$_LANG['clientareaaddon'] = "addicional";
$_LANG['clientareaaddonorderconfirmation'] = "Gràcies. S'ha enviat la seva comanda respecte al addicional mostrat més avall. Si us plau triï el seu mètode de pagament de la llista.";
$_LANG['clientareaaddonpricing'] = "Llista de Preus";
$_LANG['clientareaaddonsfor'] = "addicional per";
$_LANG['clientareaaddress1'] = "Direcció 1";
$_LANG['clientareaaddress2'] = "Direcció 2";
$_LANG['clientareabwlimit'] = "Límit d'Ample de Banda";
$_LANG['clientareabwusage'] = "Ús d'Ample de Banda";
$_LANG['clientareacancel'] = "Cancel · lar";
$_LANG['clientareacancelconfirmation'] = "Gràcies. La seva sol · licitud de cancel · lació s'ha enviat. Si això s'ha fet per error, obri immediatament un tiquet de suport per notificar o el seu compte serà tancat i eliminat.";
$_LANG['clientareacancelinvalid'] = "ERROR! O bé el compte per a la qual vostè sol · licita una cancel · lació ja està en espera per ser cancel · lat o l'article no s'ha trobat.";
$_LANG['clientareacancellationendofbillingperiod'] = "Fi del període de contractació";
$_LANG['clientareacancellationimmediate'] = "Immediata";
$_LANG['clientareacancellationtype'] = "Tipus de cancel · lació";
$_LANG['clientareacancelled'] = "Cancel · lat";
$_LANG['clientareacancelproduct'] = "S'ha Sol · licitat Cancel · lació per";
$_LANG['clientareacancelreason'] = "Descriviu breument les seves raons per a la Cancel · lació";
$_LANG['clientareacancelrequest'] = "Sol · licitar Cancel · lació de Compte";
$_LANG['clientareacancelrequestbutton'] = "Sol · licitar Cancel · lació";
$_LANG['clientareachangepassword'] = "Canviar la seva contrasenya";
$_LANG['clientareachangesuccessful'] = "Les seves Dades s'han canviat amb Èxit";
$_LANG['clientareachoosecontact'] = "Escollir contacte";
$_LANG['clientareacity'] = "Ciutat";
$_LANG['clientareacompanyname'] = "Nom de la empresa";
$_LANG['clientareaconfirmpassword'] = "Confirma la contrasenya";
$_LANG['clientareacontactsemails'] = "Preferències Email";
$_LANG['clientareacontactsemailsdomain'] = "Emails Dominis - Notícies Renovació, Confirmació de Registres, etc ...";
$_LANG['clientareacontactsemailsgeneral'] = "Emails General - Notícies Generals i Recordatoris Contrasenyes";
$_LANG['clientareacontactsemailsinvoice'] = "Emails Factures - Factures i Recordatoris Comercials";
$_LANG['clientareacontactsemailsproduct'] = "Emails Productes - Detalls de Comandes, Email de Benvinguda, etc ...";
$_LANG['clientareacontactsemailssupport'] = "Emails suport - Notificació de Tiquets de suport";
$_LANG['clientareacountry'] = "País";
$_LANG['clientareacurrentsecurityanswer'] = "Si us plau introdueixi la seva resposta actual";
$_LANG['clientareacurrentsecurityquestion'] = "Si us plau triï la seva pregunta secreta actual";
$_LANG['clientareadeletecontact'] = "Elimina contacte";
$_LANG['clientareadeletecontactareyousure'] = "Realment vol eliminar aquest contacte?";
$_LANG['clientareadescription'] = "Faci clic aquí per editar les seves dades, veure informació de facturació o contractar serveis addicionals";
$_LANG['clientareadisklimit'] = "Límit d'espai en disc";
$_LANG['clientareadiskusage'] = "Ús d'espai en disc";
$_LANG['clientareadomainexpirydate'] = "Data de Venciment";
$_LANG['clientareadomainnone'] = "No hi ha Dominis Registrats amb Nosaltres";
$_LANG['clientareaemail'] = "Direcció Email";
$_LANG['clientareaemails'] = "Els meus Emails";
$_LANG['clientareaemailsdate'] = "Enviat";
$_LANG['clientareaemailsintrotext'] = "A continuació té un historial de tots els missatges enviats a vostè. Això li permet llegir de manera fàcil qualsevol correspondència relativa al seu compte en cas que vostè perdi algun dels correus electrònics.";
$_LANG['clientareaemailssubject'] = "Assumpte del missatge";
$_LANG['clientareaerroraddress1'] = "No ha ingressat la seva adreça (línia 1)";
$_LANG['clientareaerroraddress12'] = "La seva adreça només pot contenir lletres, nombres i espais";
$_LANG['clientareaerrorbannedemail'] = "Ho sentim, però l'adreça electrònica que utilitzeu no està permesa. Us plau intenti amb una altra adreça de correu.";
$_LANG['clientareaerrorcity'] = "No ha ingressat la seva ciutat";
$_LANG['clientareaerrorcity2'] = "La seva ciutat només pot contenir lletres i espais";
$_LANG['clientareaerrorcountry'] = "Si us plau seleccioni el seu país del menú desplegable";
$_LANG['clientareaerroremail'] = "No ha ingressat la seva adreça de correu";
$_LANG['clientareaerroremailinvalid'] = "L'adreça de correu escrita no és vàlida";
$_LANG['clientareaerrorfirstname'] = "No ha ingressat el seu nom";
$_LANG['clientareaerrorfirstname2'] = "Nom només pot contenir lletres";
$_LANG['clientareaerrorisrequired'] = "és requerit";
$_LANG['clientareaerrorlastname'] = "No ha ingressat el seu cognom";
$_LANG['clientareaerrorlastname2'] = "El seu Cognom només podrà contenir lletres";
$_LANG['clientareaerroroccured'] = "S'ha produït un error, per favor intenti-ho més tard.";
$_LANG['clientareaerrorpasswordconfirm'] = "No ha confirmat la seva contrasenya";
$_LANG['clientareaerrorpasswordnotmatch'] = "La contrasenya escrita no coincideix";
$_LANG['clientareaerrorphonenumber'] = "No ha ingressat el seu número de telèfon";
$_LANG['clientareaerrorphonenumber2'] = "El seu número de telèfon només pot contenir números i espais";
$_LANG['clientareaerrorpostcode'] = "No ha ingressat el seu Codi Postal";
$_LANG['clientareaerrorpostcode2'] = "El seu codi postal només pot contenir lletres, nombres i espais";
$_LANG['clientareaerrors'] = "S'han produït els següents errors:";
$_LANG['clientareaerrorstate'] = "No ha ingressat la seva província / estat";
$_LANG['clientareaexpired'] = "Vençut";
$_LANG['clientareafirstname'] = "Nom";
$_LANG['clientareafraud'] = "Frau";
$_LANG['clientareafullname'] = "Nom de client";
$_LANG['clientareaheader'] = "Benvingut a la seva Àrea de client. L'Àrea de clients li permet veure i actualitzar les dades que posseïm sobre vostè, veure les dades dels Plans d'allotjament i dels Nom de Dominis que té amb nosaltres , enviar Tiquets de suport i demanar Productes i Serveis addicionals. ";
$_LANG['clientareahostingaddons'] = "addicionals";
$_LANG['clientareahostingaddonsintro'] = "Vostè té els següents complements per aquest producte.";
$_LANG['clientareahostingaddonsview'] = "Veure";
$_LANG['clientareahostingamount'] = "Import";
$_LANG['clientareahostingdomain'] = "Domini";
$_LANG['clientareahostingnextduedate'] = "Següent Venciment";
$_LANG['clientareahostingpackage'] = "Plans";
$_LANG['clientareahostingregdate'] = "Data de Registre";
$_LANG['clientarealastname'] = "Cognom";
$_LANG['clientarealastupdated'] = "Última Actualització";
$_LANG['clientarealeaveblank'] = "Deixar en blanc llevat que desitgi canviar la contrasenya.";
$_LANG['clientareamodifydomaincontactinfo'] = "Modificar Informació de contacte del domini";
$_LANG['clientareamodifynameservers'] = "Modificar Nom de Servidors";
$_LANG['clientareamodifywhoisinfo'] = "Modificar Informació de contacte per WHOIS";
$_LANG['clientareanameserver'] = "Nom de Servidors";
$_LANG['clientareanavaddcontact'] = "Afegir Nou contacte";
$_LANG['clientareanavchangecc'] = "Canviar Dades Targeta de Crèdit";
$_LANG['clientareanavchangepw'] = "Canviar Contrasenya";
$_LANG['clientareanavdetails'] = "Les meves Dades";
$_LANG['clientareanavdomains'] = "Els meus Dominis";
$_LANG['clientareanavhome'] = "Àrea d'Inici clients";
$_LANG['clientareanavlogout'] = "Sortir";
$_LANG['clientareanavorder'] = "Demanar Altres Prod. / Serv.";
$_LANG['clientareanavsecurityquestions'] = "Canviar la pregunta de seguretat";
$_LANG['clientareanavservices'] = "Els meus Serveis";
$_LANG['clientareanavsupporttickets'] = "Els meus Tiquets de suport";
$_LANG['clientareanocontacts'] = "contacte no Trobat";
$_LANG['clientareapassword'] = "Contrasenya";
$_LANG['clientareapending'] = "Pendent";
$_LANG['clientareapendingtransfer'] = "Transferència Pendent";
$_LANG['clientareaphonenumber'] = "Número de Telèfon";
$_LANG['clientareapostcode'] = "Codi Postal";
$_LANG['clientareaproductdetails'] = "Detalls de Productes";
$_LANG['clientareaproducts'] = "Els meus Productes i Serveis";
$_LANG['clientareaproductsnone'] = "No hi ha Productes / Serveis Comandes";
$_LANG['clientarearegistrationperiod'] = "Període de Registre";
$_LANG['clientareasavechanges'] = "Desar Canvis";
$_LANG['clientareasecurityanswer'] = "Si us plau introdueixi una resposta";
$_LANG['clientareasecurityconfanswer'] = "Si us plau confirmi la seva resposta";
$_LANG['clientareasecurityquestion'] = "Si us plau triï una pregunta secreta";
$_LANG['clientareaselectcountry'] = "Triar País";
$_LANG['clientareasetlocking'] = "Posar Bloqueig";
$_LANG['clientareastate'] = "Província / Regió";
$_LANG['clientareastatus'] = "Estat";
$_LANG['clientareasuspended'] = "Suspès";
$_LANG['clientareaterminated'] = "Acabat";
$_LANG['clientareaticktoenable'] = "Fer clic per habilitar";
$_LANG['clientareatitle'] = "Àrea del client";
$_LANG['clientareaunlimited'] = "Il · limitat";
$_LANG['clientareaupdatebutton'] = "Actualitzar";
$_LANG['clientareaupdateyourdetails'] = "Actualitzar seves Dades";
$_LANG['clientareaused'] = "Usat";
$_LANG['clientareaviewaddons'] = "Veure addicionals disponibles";
$_LANG['clientareaviewdetails'] = "Veure detalls";
$_LANG['clientlogin'] = "Entrar";
$_LANG['clientregisterheadertext'] = "Si us plau ompli els camps per a registrar un nou compte. Els camps marcats amb un * són requerits.";
$_LANG['clientregistertitle'] = "Registrar";
$_LANG['clientregisterverify'] = "Verificar registre";
$_LANG['clientregisterverifydescription'] = "Si us plau introdueixi el text que apareix a la imatge al quadre de text. Això és requerit per prevenir registres automàtics.";
$_LANG['clientregisterverifyinvalid'] = "El codi de verificació no és vàlid";
$_LANG['closewindow'] = "Tancar Finestra";
$_LANG['completeorder'] = "Comanda Completada";
$_LANG['confirmnewpassword'] = "Confirmar Nova Contrasenya";
$_LANG['contactemail'] = "Email";
$_LANG['contacterrormessage'] = "No ha ingressat un missatge";
$_LANG['contacterrorname'] = "No ha ingressat el seu nom";
$_LANG['contacterrorsubject'] = "No ha ingressat un assumpte";
$_LANG['contactheader'] = "If you have any pre-sales questions or want to contact us, please use the form below.";
$_LANG['contactmessage'] = "Missatge";
$_LANG['contactname'] = "Nom";
$_LANG['contactsend'] = "Enviar Missatge";
$_LANG['contactsent'] = "El seu missatge ha estat enviat";
$_LANG['contactsubject'] = "Assumpte";
$_LANG['contacttitle'] = "contacte de Pre-venda";
$_LANG['continueshopping'] = "Continuar Comprant";
$_LANG['creditcard'] = "Pagar amb targeta de crèdit";
$_LANG['creditcard3dsecure'] = "Com a part de les nostres mesures preventives del frau, ara se li demanarà que realitzi la verificació secureCode Verified by Visa o Mastercard per realitzar el seu pagament. <br /> <br /> No faci clic al botó d'actualització o al botó enrere o la transacció podria ser interrompuda o cancel · lada. ";
$_LANG['creditcardcardexpires'] = "Data d'expiració";
$_LANG['creditcardcardissuenum'] = "Número";
$_LANG['creditcardcardnumber'] = "Número de targeta";
$_LANG['creditcardcardstart'] = "Data de començament";
$_LANG['creditcardcardtype'] = "Tipus de targeta de crèdit";
$_LANG['creditcardccvinvalid'] = "El codi ingressat no és vàlid";
$_LANG['creditcardconfirmation'] = "Gràcies! Les dades de la seva nova targeta han estat acceptats i s'ha pres el primer pagament per al vostre compte. S'ha enviat un correu electrònic de confirmació respecte a això.";
$_LANG['creditcardcvvnumber'] = "Nombre CVV/CVC2 (Seguretat)";
$_LANG['creditcardcvvwhere'] = "On trobo això?";
$_LANG['creditcarddeclined'] = "Les dades de la targeta indicada han estat rebutjades. Si us plau intenti amb una altra targeta o contacti amb el suport tècnic.";
$_LANG['creditcarddetails'] = "Dades de Targeta de Crèdit";
$_LANG['creditcardenterexpirydate'] = "No ha ingressat la data de venciment";
$_LANG['creditcardenternewcard'] = "Introdueixi la informació de la Nova Targeta abaix";
$_LANG['creditcardenternumber'] = "No ha introduït el seu número de targeta crèdit / dèbit";
$_LANG['creditcardinvalid'] = "Les dades de la targeta indicada no són vàlides. Us plau intenti amb una altra targeta o contacti amb el suport tècnic.";
$_LANG['creditcardnumberinvalid'] = "El seu número de targeta de crèdit / dèbit és incorrecte";
$_LANG['creditcardsecuritynotice'] = "Qualsevol dada que vostè ingressi aquí és enviat amb seguretat i està codificada per reduir el risc de frau";
$_LANG['creditcarduseexisting'] = "Utilitzar Targeta Existent";
$_LANG['customfieldvalidationerror'] = "El camp no és vàlid";
$_LANG['days'] = "Dies";
$_LANG['defaultbillingcontact'] = "contacte de Facturació per defecte";
$_LANG['domainalternatives'] = "Provi aquestes alternatives";
$_LANG['domainavailable'] = "Disponible! Comprar ara";
$_LANG['domainavailable1'] = "Felicitats!";
$_LANG['domainavailable2'] = "està disponible!";
$_LANG['domainavailableexplanation'] = "Per registrar aquest domini faci clic a l'enllaç de sota";
$_LANG['domainbulksearch'] = "Cerca Massiva de Dominis";
$_LANG['domainbulksearchintro'] = "El cercador massiu en temps real de dominis li permet buscar fins a 20 dominis d'una sola vegada. Introdueixi els dominis en els camps de sota, un per línia - no escrigui www ni http://";
$_LANG['domainbulktransferdescription'] = "Pot transferir els seus dominis existents cap a nosaltres avui mateix. Per començar, només cal introduir els dominis abaix, un per línia - no incloure www. O http://";
$_LANG['domainbulktransfersearch'] = "Transferència massiva de Dominis";
$_LANG['domaincheckerdescription'] = "Comprovi la disponibilitat d'un domini";
$_LANG['domaincontactinfo'] = "Informació de contacte";
$_LANG['domaincurrentrenewaldate'] = "Data Actual de Renovació";
$_LANG['domaindnsaddress'] = "Direcció";
$_LANG['domaindnshostname'] = "Host Name";
$_LANG['domaindnsmanagement'] = "Gestionar DNS";
$_LANG['domaindnsmanagementdesc'] = "Apunti seu domini a un lloc web apuntant a una adreça IP, envii'l a un altre lloc, o connecti amb una pàgina temporal (conegut com Pàrking), i més. Aquests registres són també coneguts com subdominis. ";
$_LANG['domaindnsrecordtype'] = "Tipus de registre";
$_LANG['domainemailforwarding'] = "Redirecció de Email";
$_LANG['domainemailforwardingdesc'] = "Si el servidor de Redirecció d'Email determina que l'adreça de desti no és vàlida, desactivarem el registre de reenviament automàticament. Si us plau comprovi l'adreça de destí abans de tornar a activar. Els canvis en qualsevol registre de reenviament existent no tindrà efecte fins passada 1 hora. ";
$_LANG['domainemailforwardingforwardto'] = "Envia cap";
$_LANG['domainemailforwardingprefix'] = "Prefix";
$_LANG['domaineppcode'] = "Codi EPP";
$_LANG['domaineppcodedesc'] = "Això ha de ser aportat per l'actual registrador per ser autoritzat";
$_LANG['domaineppcoderequired'] = "Ha d'introduir el codi EPP per";
$_LANG['domainerror'] = "Hi ha hagut un error en la seva sol · licitud:";
$_LANG['domainerrornodomain'] = "Introdueixi un Nom de Domini Vàlid";
$_LANG['domainerrortoolong'] = "El domini ingressat és molt llarg. Els dominis poden tenir fins a 67 caràcters de llarg.";
$_LANG['domaingeteppcode'] = "Obtenir Codi EPP";
$_LANG['domaingeteppcodeemailconfirmation'] = "La petició del codi EPP ha estat un èxit! Ha estat enviada al contacte principal del seu domini.";
$_LANG['domaingeteppcodeexplanation'] = "El codi és bàsicament una clau que tenen els dominis. Són una mesura de seguretat, que asseguren que només el propietari té autorització per transferir el domini. El necessitaràs si vols transferir el domini a un altre registrador. ";
$_LANG['domaingeteppcodefailure'] = "S'ha produït un error amb la petició del codi EPP:";
$_LANG['domaingeteppcodeis'] = "El codi EPP del seu domini és:";
$_LANG['domainidprotection'] = "Protecció de ID";
$_LANG['domainintrotext'] = "Introdueixi abaix el domini i la tld (extensió) que vol, després faci clic a Cerca per veure si aquest domini està disponible per la seva compra.";
$_LANG['domainlookupbutton'] = "Cerca";
$_LANG['domainmanagementtools'] = "Eines de Gestió";
$_LANG['domainminyears'] = "Min Anys";
$_LANG['domainmoreinfo'] = "Més Informació";
$_LANG['domainname'] = "Domini";
$_LANG['domainnameserver1'] = "nameserver 1";
$_LANG['domainnameserver2'] = "nameserver 2";
$_LANG['domainnameserver3'] = "nameserver 3";
$_LANG['domainnameserver4'] = "nameserver 4";
$_LANG['domainnameserver5'] = "nameserver 5";
$_LANG['domainnameservers'] = "nameservers";
$_LANG['domainordernow'] = "Comprar ara!";
$_LANG['domainorderrenew'] = "Sol · licitar Renovació";
$_LANG['domainprice'] = "Preu";
$_LANG['domainregisterns'] = "Registrar nameserver";
$_LANG['domainregisternscurrentip'] = "Adreça IP actual";
$_LANG['domainregisternsdel'] = "Eliminar un nameserver";
$_LANG['domainregisternsdelsuccess'] = "El nameserver ha estat eliminat amb èxit";
$_LANG['domainregisternsexplanation'] = "Des d'aquí pot crear i administrar servidors de nom pel seu domini (per exemple: NS1.TUDOMINIO.COM, NS2.TUDOMINIO.COM ...).";
$_LANG['domainregisternsip'] = "Adreça IP";
$_LANG['domainregisternsmod'] = "Modificar IP de nameserver";
$_LANG['domainregisternsmodsuccess'] = "El nameserver ha estat modificat amb èxit";
$_LANG['domainregisternsnewip'] = "Nova Adreça IP";
$_LANG['domainregisternsns'] = "nameserver";
$_LANG['domainregisternsreg'] = "Registrar un nom de nameserver";
$_LANG['domainregisternsregsuccess'] = "El nameserver ha estat registrat amb èxit";
$_LANG['domainregistrantchoose'] = "Seleccioni el contacte que vol utilitzar";
$_LANG['domainregistrantinfo'] = "Informació del registrador del domini";
$_LANG['domainregistrarlock'] = "Bloquejar Registre";
$_LANG['domainregistrarlockdesc'] = "Habilita el Bloqueig de Registre (Recomanat). Les transferències no autoritzades seran evitades si està habilitat el bloqueig.";
$_LANG['domainregistration'] = "Registre Domini";
$_LANG['domainregistryinfo'] = "Informació de domini registrat";
$_LANG['domainregnotavailable'] = "N / A";
$_LANG['domainrenew'] = "Renovar Domini";
$_LANG['domainrenewal'] = "Renovar Domini";
$_LANG['domainrenewalprice'] = "Renovació";
$_LANG['domainrenewdesc'] = "Asseguri el seu domini afegint més anys a aquest. Seleccioni avall per quants anys està interessat en renovar i a continuació, faci clic a Sol · licitar Renovació.";
$_LANG['domainsautorenew'] = "Auto Renovar";
$_LANG['domainsautorenewdisable'] = "Desactivar Auto Renovació";
$_LANG['domainsautorenewdisabled'] = "Desactivat";
$_LANG['domainsautorenewdisabledwarning'] = "AVÍS! Aquest domini té Auto Renovació desactivat i no rebrà més avisos de renovació. <br /> Per tant caduca al final del període actual.";
$_LANG['domainsautorenewenable'] = "Activar Auto Renovació";
$_LANG['domainsautorenewenabled'] = "Activat";
$_LANG['domainsautorenewstatus'] = "Estat actual";
$_LANG['domainsimplesearch'] = "Cerca Simple de Dominis";
$_LANG['domainspricing'] = "Preu de dominis";
$_LANG['domainsregister'] = "Registrar";
$_LANG['domainsrenew'] = "Renovar";
$_LANG['domainsrenewnow'] = "Renovar Ara";
$_LANG['domainstatus'] = "Estat";
$_LANG['domainstransfer'] = "Transferir";
$_LANG['domaintitle'] = "Cerca Nom de Domini Disponible";
$_LANG['domaintld'] = "TLD";
$_LANG['domaintransfer'] = "Transferir Domini";
$_LANG['domainunavailable'] = "No disponible";
$_LANG['domainunavailable1'] = "Ho Lamentem!";
$_LANG['domainunavailable2'] = "ja està registrat!";
$_LANG['domainviewwhois'] = "veure l'informe Whois";
$_LANG['downloaddescription'] = "Descripció";
$_LANG['downloadloginrequired'] = "Accés denegat - Ha d'ingressar en el seu compte per poder descarregar-lo.";
$_LANG['downloadname'] = "Descarregar";
$_LANG['downloadpurchaserequired'] = "Accés denegat - Ha de contractar el servei relacionat a aquesta descàrrega abans de poder baixar-la";
$_LANG['downloadscategories'] = "Categories";
$_LANG['downloadsdescription'] = "Veure la llibreria de descàrregues";
$_LANG['downloadsfiles'] = "Arxius";
$_LANG['downloadsfilesize'] = "Mida d'Arxius";
$_LANG['downloadsintrotext'] = "La llibreria de descàrregues té tots els manuals, programes i altres arxius que necessita per posar en marxa i dissenyar el seu lloc web.";
$_LANG['downloadspopular'] = "Descàrregues més populars";
$_LANG['downloadsnone'] = "No Hi Descàrregues per Mostrar";
$_LANG['downloadstitle'] = "Descàrregues";
$_LANG['email'] = "Email";
$_LANG['emptycart'] = "Buidar Cistella";
$_LANG['existingpassword'] = "Contrasenya actual";
$_LANG['existingpasswordincorrect'] = "La contrasenya acutal no és correcta";
$_LANG['firstpaymentamount'] = "Import del Primer Pagament";
$_LANG['flashtutorials'] = "Flash d'Aprenentatge";
$_LANG['flashtutorialsdescription'] = "Feu clic aquí per veure imatges sobre l'aprenentatge en l'ús del tauler de control del seu allotjament";
$_LANG['flashtutorialsheadertext'] = "Els nostres Flaixos d'Aprenentatge són aquí per ajudar-lo a utilitzar a ple seu panell de control d'allotjament. Triï una tasca de sota per veure pas a pas un tutorial que li ensenyarà a completar-la.";
$_LANG['forwardingtogateway'] = "Esperi mentre és redirigit a la seva opció de pagament ...";
$_LANG['globalsystemname'] = "Administració";
$_LANG['globalyouarehere'] = "Vostè és aquí";
$_LANG['go'] = "Anar";
$_LANG['headertext'] = "Benvingut a la nostra Àrea d'Administració.";
$_LANG['hometitle'] = "Inici";
$_LANG['imagecheck'] = "Per raons de seguretat, si us plau introdueixi els 5 dígits del codi de sota";
$_LANG['invoiceaddcreditamount'] = "Introdueixi la quantitat per aplicar";
$_LANG['invoiceaddcreditapply'] = "Aplicar crèdit";
$_LANG['invoiceaddcreditdesc1'] = "El seu saldo de crèdit actual és";
$_LANG['invoiceaddcreditdesc2'] = "Això pot ser aplicat a la factura utilitzant el formulari a continuació.";
$_LANG['invoiceaddcreditoverbalance'] = "No pot aplicar més crèdit que la quantitat pendent";
$_LANG['invoiceaddcreditovercredit'] = "No pot aplicar més crèdit del que te al teu compte";
$_LANG['invoicenumber'] = "Factura n º";
$_LANG['invoiceofflinepaid'] = "El Pagament amb Targeta de Crèdit fora de línia es processat manualment. Vostè rebrà una confirmació per e-mail una vegada que el pagament sigui processat.";
$_LANG['invoicerefnum'] = "Referència del Pagament";
$_LANG['invoices'] = "Les meves Factures";
$_LANG['invoicesamount'] = "Import";
$_LANG['invoicesattn'] = "Attn";
$_LANG['invoicesbacktoclientarea'] = "<< Tornar a l'àrea de client";
$_LANG['invoicesbalance'] = "Balanç";
$_LANG['invoicesbefore'] = "abans";
$_LANG['invoicescancelled'] = "Cancel · lada";
$_LANG['invoicescollections'] = "Processar pagaments";
$_LANG['invoicescredit'] = "Crèdit";
$_LANG['invoicesdatecreated'] = "Data de la factura";
$_LANG['invoicesdatedue'] = "Data de Venciment";
$_LANG['invoicesdescription'] = "Descripció";
$_LANG['invoicesdownload'] = "Descarregar";
$_LANG['invoicesdue'] = "Factura vençuda";
$_LANG['invoiceserror'] = "S'ha produït un error. Si us plau torni a provar.";
$_LANG['invoicesinvoicedto'] = "Facturat a";
$_LANG['invoicesinvoicenotes'] = "Notes de la factura";
$_LANG['invoicesnoinvoices'] = "No hi ha Factures";
$_LANG['invoicesnotes'] = "Notes";
$_LANG['invoicesoutstandinginvoices'] = "Factures Pendents";
$_LANG['invoicespaid'] = "Pagada";
$_LANG['invoicespaynow'] = "Pagar Ara";
$_LANG['invoicespayto'] = "Pagar";
$_LANG['invoicesrefunded'] = "Pagament Retornat";
$_LANG['invoicesstatus'] = "Estat";
$_LANG['invoicessubtotal'] = "sub Total";
$_LANG['invoicestax'] = "Impost";
$_LANG['invoicestaxindicator'] = "Producte / Servei subjecte a impost";
$_LANG['invoicestitle'] = "Factura N °";
$_LANG['invoicestotal'] = "Total";
$_LANG['invoicestransactions'] = "Transaccions";
$_LANG['invoicestransamount'] = "Total";
$_LANG['invoicestransdate'] = "Data Transacció";
$_LANG['invoicestransgateway'] = "Mètode / Gateway";
$_LANG['invoicestransid'] = "ID Transacció";
$_LANG['invoicestransnonefound'] = "No s'han trobat transaccions relacionades";
$_LANG['invoicesunpaid'] = "No Pagada";
$_LANG['invoicesview'] = "Veure Factura";
$_LANG['jobtitle'] = "Job Title";
$_LANG['kbsuggestions'] = "Suggeriments en Base de Coneixements";
$_LANG['kbsuggestionsexplanation'] = "Els següents articles han estat trobats a la base de Coneixements i podrien resoldre el seu dubte. Revisi els suggeriments abans de contactar-nos.";
$_LANG['knowledgebasearticles'] = "Articles";
$_LANG['knowledgebasecategories'] = "Categories";
$_LANG['knowledgebasedescription'] = "Descobrir la base de coneixements per a les preguntes més freqüents";
$_LANG['knowledgebasefavorites'] = "Afegir als preferits";
$_LANG['knowledgebasehelpful'] = "Ha estat útil la resposta?";
$_LANG['knowledgebaseintrotext'] = "La base de coneixements està organitzada en diferents categories. Pot triar una categoria de sota o bé, buscar a la base de coneixements per la resposta a la seva pregunta.";
$_LANG['knowledgebasemore'] = "Més";
$_LANG['knowledgebaseno'] = "No";
$_LANG['knowledgebasenoarticles'] = "No s'han trobar articles";
$_LANG['knowledgebasenorelated'] = "No Hi Articles Relacionats";
$_LANG['knowledgebasepopular'] = "Més Popular";
$_LANG['knowledgebaseprint'] = "Imprimeix aquest Article";
$_LANG['knowledgebaserating'] = "Valoració:";
$_LANG['knowledgebaseratingtext'] = "Els usuaris han Trobat Això Útil";
$_LANG['knowledgebaserelated'] = "Articles Relacionats";
$_LANG['knowledgebasesearch'] = "Cerca";
$_LANG['knowledgebasetitle'] = "Preguntes Freqüents - FAQ";
$_LANG['knowledgebaseviews'] = "Vistes";
$_LANG['knowledgebasevote'] = "Votar";
$_LANG['knowledgebasevotes'] = "Vots";
$_LANG['knowledgebaseyes'] = "Si";
$_LANG['language'] = "Idioma";
$_LANG['latefee'] = "Càrrec per demora";
$_LANG['latefeeadded'] = "Afegir";
$_LANG['latestannouncements'] = "Últimes notícies";
$_LANG['loginbutton'] = "Entrada";
$_LANG['loginemail'] = "Direcció Email";
$_LANG['loginforgotten'] = "Ha oblidat la seva contrasenya?";
$_LANG['loginforgotteninstructions'] = "Sol · liciti la seva contrasenya fent clic aquí";
$_LANG['loginincorrect'] = "L'adreça de correu o la contrasenya són incorrectes. Si us plau intenti-ho novament.";
$_LANG['loginintrotext'] = "Vostè ha d'ingressar per accedir a aquesta pàgina. Aquestes dades d'accés difereixen del nom d'usuari i contrasenya del panell de control del seu lloc web.";
$_LANG['loginpassword'] = "Contrasenya";
$_LANG['loginrememberme'] = "Recordar Dades d'usuari";
$_LANG['logoutcontinuetext'] = "Faci clic aquí per a continuar.";
$_LANG['logoutsuccessful'] = "Vostè ha sortit del lloc web amb èxit.";
$_LANG['logouttitle'] = "Sortir";
$_LANG['maxmind_anonproxy'] = "Ho sentim, no acceptem comandes si utilitza un proxy Anònim";
$_LANG['maxmind_callingnow'] = "A continuació farem una trucada automatitzada al seu número de telèfon. Això és part de les nostres mesures de prevenció de fraus. Rebrà un codi de seguretat de 4 dígits que ha d'escriure sota per completar la seva comanda.";
$_LANG['maxmind_countrymismatch'] = "Ho sentim, no podem acceptar la seva comanda. Pel que sembla vostè està comprant des d'un país diferent del que va especificar en la seva adreça.";
$_LANG['maxmind_error'] = "Error";
$_LANG['maxmind_faileddescription'] = "El codi que ha introduit no és correcte. Si creu que això és un error, contacti al nostre departament de suport tan aviat com sigui possible.";
$_LANG['maxmind_highfraudriskscore'] = "El nostre sistema ha detectat un alt risc de frau per la seva comanda i per tant ha estat bloquejat.";
$_LANG['maxmind_highriskcountry'] = "Ho sentim, en aquest moment no podem acceptar la seva comanda. Possiblement ha comprat des d'un país amb alt risc de frau.";
$_LANG['maxmind_incorrectcode'] = "Codi Incorrecte";
$_LANG['maxmind_pincode'] = "Codi PIN";
$_LANG['maxmind_rejectemail'] = "Ho sentim, no acceptem comandes amb adreces de correu gratuïtes (ex. Hotmail, Yahoo, etc). Us plau intenti-ho amb una adreça diferent.";
$_LANG['maxmind_title'] = "MaxMind";
$_LANG['more'] = "Més";
$_LANG['morechoices'] = "Més Opcions";
$_LANG['networkissuesaffecting'] = "Afectant";
$_LANG['networkissuesaffectingyourservers'] = "Atenció: Problemes afectant servidors en què tingui comptes apareixeran amb un fons daurat";
$_LANG['networkissuesdate'] = "Data";
$_LANG['networkissuesdescription'] = "Comprovar si hi ha millores programades o desconnexions temporals del servei";
$_LANG['networkissueslastupdated'] = "Última actualització";
$_LANG['networkissuesnonefound'] = "No s'ha trobat cap problema amb els serveis";
$_LANG['networkissuespriority'] = "Prioritat";
$_LANG['networkissuesprioritycritical'] = "Crític";
$_LANG['networkissuespriorityhigh'] = "Alt";
$_LANG['networkissuesprioritylow'] = "Sota";
$_LANG['networkissuesprioritymedium'] = "Mitjà";
$_LANG['networkissuesstatusinprogress'] = "En Progrés";
$_LANG['networkissuesstatusinvestigating'] = "Investigant";
$_LANG['networkissuesstatusopen'] = "Obert";
$_LANG['networkissuesstatusoutage'] = "Interrupció";
$_LANG['networkissuesstatusreported'] = "Reportat";
$_LANG['networkissuesstatusresolved'] = "Resolt";
$_LANG['networkissuesstatusscheduled'] = "programat";
$_LANG['networkissuestitle'] = "Estat de Serveis";
$_LANG['networkissuestypeother'] = "Un altre";
$_LANG['networkissuestypeserver'] = "Servidor";
$_LANG['networkissuestypesystem'] = "Sistema";
$_LANG['newpassword'] = "Nova Contrasenya";
$_LANG['nextpage'] = "Pàgina Següent";
$_LANG['no'] = "No";
$_LANG['nocarddetails'] = "No hi ha detalls de la targeta en el registre";
$_LANG['none'] = "Res";
$_LANG['norecordsfound'] = "Sense Resultats";
$_LANG['or'] = "o";
$_LANG['orderadditionalrequiredinfo'] = "Informació addicional requerida";
$_LANG['orderaddon'] = "addicional";
$_LANG['orderaddondescription'] = "Els següents addicionals estan disponibles per aquest producte. Triï l'addicional que vol demanar de la llista d'abaix.";
$_LANG['orderavailable'] = "Disponible";
$_LANG['orderavailableaddons'] = "Faci clic per veure addicionals disponibles";
$_LANG['orderbillingcycle'] = "Cicle de facturació";
$_LANG['ordercategories'] = "Categories";
$_LANG['orderchangeaddons'] = "Canviar addicionals";
$_LANG['orderchangeconfig'] = "Canviar Opcions de Configuració";
$_LANG['orderchangedomain'] = "Canviar Domini";
$_LANG['orderchangenameservers'] = "Canviar Només Nom de Servidors";
$_LANG['orderchangeproduct'] = "Canviar Producte";
$_LANG['ordercheckout'] = "Anar a Caixa";
$_LANG['orderchooseaddons'] = "Selecciona addicionals del Producte";
$_LANG['orderchooseapackage'] = "Triar un Pla";
$_LANG['ordercodenotfound'] = "El codi insertat no existeix";
$_LANG['ordercompletebutnotpaid'] = "Atenció! La seva comanda ha estat completada correctament. Per activar els Procutes / Serveis ha de fer el pagament corresponent. <br /> Clic en aquest enllaç per anar a la seva factura i realitzar el pagament.";
$_LANG['orderconfigpackage'] = "Opcions Configurables";
$_LANG['orderconfigure'] = "Configurar";
$_LANG['orderconfirmation'] = "Confirmació de la comanda";
$_LANG['orderconfirmorder'] = "Confirmar Comanda";
$_LANG['ordercontinuebutton'] = "Faci clic per Continuar >>";
$_LANG['orderdesc'] = "Descripció";
$_LANG['orderdescription'] = "Faci una nova Comanda amb nosaltres";
$_LANG['orderdiscount'] = "Descompte";
$_LANG['orderdomain'] = "Nom de Domini";
$_LANG['orderdomainoption1part1'] = "Jo vull que";
$_LANG['orderdomainoption1part2'] = "registri un nou nom de domini en el meu nom.";
$_LANG['orderdomainoption2'] = "Auto administraré el nom de domini modificant un d'existent o registrant un nou domini.";
$_LANG['orderdomainoption3'] = "Vull transferir el meu domini a";
$_LANG['orderdomainoption4'] = "Vull utilitzar un sub-domini gratis.";
$_LANG['orderdomainoptions'] = "Opcions de Domini";
$_LANG['orderdomainregistration'] = "Registre de domini";
$_LANG['orderdomainregonly'] = "Demanar Només Registre de Domini";
$_LANG['orderdomaintransfer'] = "Transferència de Domini";
$_LANG['orderdontusepromo'] = "No Utilitzar Codi de Promoció";
$_LANG['ordererroraccepttos'] = "Vostè ha d'acceptar els nostres Termes del Servei i condicions d'ús";
$_LANG['ordererrordomainalreadyexists'] = "El domini que ha introduït ja està registrat amb nosaltres - vostè haurà de cancel · lar abans d'Realitzar una nova comanda.";
$_LANG['ordererrordomaininvalid'] = "El domini ingressat no és vàlid";
$_LANG['ordererrordomainnotld'] = "Ha de ingressar l'extensió (TLD) del domini";
$_LANG['ordererrordomainnotregistered'] = "No pot transferir un domini que no està registrat";
$_LANG['ordererrordomainregistered'] = "El domini que vostè acaba d'ingressar ja està registrat";
$_LANG['ordererrornameserver1'] = "Vostè ha d'ingressar el nom de servidor 1";
$_LANG['ordererrornameserver2'] = "Vostè ha d'ingressar el nom de servidor 2";
$_LANG['ordererrornodomain'] = "No ha ingressat un nom de domini";
$_LANG['ordererrorpassword'] = "No ha ingressat una contrasenya";
$_LANG['ordererrorserverhostnameinuse'] = "El nom de host que ha introduït ja està en ús. Si us plau, triï un altre.";
$_LANG['ordererrorservernohostname'] = "Ha d'introduir un nom de servidor per el seu servidor";
$_LANG['ordererrorservernonameservers'] = "Heu de introduir un prefix per a tots dos noms de servidor";
$_LANG['ordererrorservernorootpw'] = "Vostè ha d'ingressar la contrasenya de root";
$_LANG['ordererrorsubdomaintaken'] = "El subdomini està registrat, provi amb un altre diferent";
$_LANG['ordererrortransfersecret'] = "Vostè necessita introduir el codi per a la transferència";
$_LANG['ordererroruserexists'] = "Ja existeix un usuari amb aquesta adreça de correu";
$_LANG['orderexistinguser'] = "Sóc un client existent i desitjo afegir aquesta comanda al meu compte";
$_LANG['orderfailed'] = "La Comanda ha fallat";
$_LANG['orderfinalinstructions'] = "Si vostè té alguna pregunta respecte a la seva comanda, si us plau obri un tiquet de suport dins de la seva Àrea de client i indiqui el número de comanda.";
$_LANG['orderfree'] = "GRATIS!";
$_LANG['orderfreedomainappliesto'] = "s'aplica només per les següents extensions";
$_LANG['orderfreedomaindescription'] = "en les condicions de pagament triades";
$_LANG['orderfreedomainonly'] = "Domini Gratis";
$_LANG['orderfreedomainregistration'] = "Registre Gratis de Domini";
$_LANG['ordergotoclientarea'] = "Faci clic aquí per anar a l'Àrea de client";
$_LANG['orderinvalidcodeforbillingcycle'] = "Aquest codi no és aplicable als cicles de facturació elegits";
$_LANG['orderlogininfo'] = "Informació d'ingrés";
$_LANG['orderlogininfopart1'] = "Introdueixi la contrasenya que vol utilitzar per a ingressar al seu";
$_LANG['orderlogininfopart2'] = "Àrea de client. El nom d'usuari i contrasenya seran diferents als que correspon al Panell de Control del seu lloc web.";
$_LANG['ordernewuser'] = "Sóc un nou client i vull crear un compte amb vostès";
$_LANG['ordernoproducts'] = "No s`han trobat Productes";
$_LANG['ordernotes'] = "Notes / Altres";
$_LANG['ordernotesdescription'] = "Pot introduir qualsevol nota o informació addicional que vulgui incloure a la seva comanda aquí ...";
$_LANG['ordernowbutton'] = "Demanar Ara";
$_LANG['ordernumberis'] = "El número de Comanda és:";
$_LANG['orderpaymentmethod'] = "Mètode de pagament";
$_LANG['orderpaymentterm12month'] = "12 Mesos";
$_LANG['orderpaymentterm1month'] = "1 Mes";
$_LANG['orderpaymentterm24month'] = "24 Mesos";
$_LANG['orderpaymentterm3month'] = "3 Mesos";
$_LANG['orderpaymentterm6month'] = "6 Mesos";
$_LANG['orderpaymenttermannually'] = "Anual";
$_LANG['orderpaymenttermbiennially'] = "Bi-Anual";
$_LANG['orderpaymenttermfreeaccount'] = "Compte Gratis";
$_LANG['orderpaymenttermmonthly'] = "Mensual";
$_LANG['orderpaymenttermonetime'] = "Una vegada";
$_LANG['orderpaymenttermquarterly'] = "Trimestral";
$_LANG['orderpaymenttermsemiannually'] = "Semi-Anual";
$_LANG['orderprice'] = "Preu";
$_LANG['orderproduct'] = "Producte / Servei";
$_LANG['orderprogress'] = "Progrés";
$_LANG['orderpromoexpired'] = "Ho sentim, aquest codi de promoció està vençut";
$_LANG['orderpromoinvalid'] = "Aquest codi no és aplicable a aquest Prodcute / Servei";
$_LANG['orderpromomaxusesreached'] = "El codi de promoció ha estat utilitzat";
$_LANG['orderpromotioncode'] = "Codi de Promoció";
$_LANG['orderpromovalidatebutton'] = "Validar Codi >>";
$_LANG['orderprorata'] = "Prorrateig";
$_LANG['orderreceived'] = "Gràcies per la seva comanda. Rebrà un email de confirmació en breu.";
$_LANG['orderregisterdomain'] = "Registrar un Nou Domini";
$_LANG['orderregperiod'] = "Període de Registre";
$_LANG['ordersecure'] = "Per motius de seguretat guardarem la seva IP actual, la seva IP";
$_LANG['ordersecure2'] = "ha estat guardada a la nostra base de dades.";
$_LANG['orderserverhostname'] = "Nom de Servidors d'allotjament";
$_LANG['orderservernameservers'] = "Nom de Servidors";
$_LANG['orderservernameserversdescription'] = "Els prefixos que vostè ingressi aquí han de determinar els noms de servidors per defecte per al servidor. P.ex. ns1.sudominio.com i ns2.sudominio.com";
$_LANG['orderservernameserversprefix1'] = "Prefix 1";
$_LANG['orderservernameserversprefix2'] = "Prefix 2";
$_LANG['orderserverrootpassword'] = "Contrasenya Root";
$_LANG['ordersetupfee'] = "Cost d'instal · lació";
$_LANG['orderstartover'] = "Començar novament";
$_LANG['ordersubdomaininuse'] = "El sub-domini ingressat està en ús";
$_LANG['ordersubtotal'] = "subtotal";
$_LANG['ordersummary'] = "Sumari de Comanda";
$_LANG['ordertaxcalculations'] = "Càlcul de l'impost";
$_LANG['ordertaxstaterequired'] = "Ha de indicar la seva Ciutat / Estat perquè poguem calcular l'impost a pagar.";
$_LANG['ordertitle'] = "Fer Comanda";
$_LANG['ordertos'] = "Termes del Servei i condicions d'ús";
$_LANG['ordertosagreement'] = "Jo he llegit i estic d'acord amb els";
$_LANG['ordertotalduetoday'] = "Import a la Data";
$_LANG['ordertotalrecurring'] = "Total Recurrent";
$_LANG['ordertransferdomain'] = "Transferir un Nom de Domini Existent";
$_LANG['ordertransfersecret'] = "Codi per Transferir";
$_LANG['ordertransfersecretexplanation'] = "El codi per transferir el pot obtenir amb el seu actual registrador.";
$_LANG['orderusesubdomain'] = "Utilitzar sub-Domini";
$_LANG['orderyears'] = "Any (s)";
$_LANG['orderyourinformation'] = "La seva Informació";
$_LANG['orderyourorder'] = "La seva cistella";
$_LANG['organizationname'] = "Organization Name";
$_LANG['outofstock'] = "Esgotat";
$_LANG['outofstockdescription'] = "Aquest producte actualment està esgotat, per tant les comandes per aquest article han estat suspesos fins que en tinguem més disponibles. Per a més informació contacti amb nosaltres.";
$_LANG['page'] = "Pàgina";
$_LANG['pageof'] = "de";
$_LANG['please'] = "Si us plau";
$_LANG['pleasewait'] = "Si us plau, esperi ...";
$_LANG['presalescontactdescription'] = "Feu qualsevol consulta prevenda aquí";
$_LANG['previouspage'] = "Pàgina Prèvia";
$_LANG['proformainvoicenumber'] = "Factura Proforma número";
$_LANG['promoexistingclient'] = "Cal que tingui algun producte / servei actiu per utilitzar aquest codi";
$_LANG['promoonceperclient'] = "Aquest codi només es pot utilitzar una vegada per client";
$_LANG['pwstrengthfail'] = "La contrasenya que ha introduït no és prou complexa - si us plau, introdueixi una contrasenya més complexa";
$_LANG['quicknav'] = "Accessos directes";
$_LANG['recordsfound'] = "Registres trobats";
$_LANG['recurring'] = "Recurrent";
$_LANG['recurringamount'] = "Import de la quota";
$_LANG['every'] = "Cada";
$_LANG['registerdomain'] = "Registrar Domini";
$_LANG['registerdomaindesc'] = "Introdueixi el domini que vol registrar per comprovar si està lliure.";
$_LANG['registerdomainname'] = "Registrar un Nom de Domini";
$_LANG['relatedservice'] = "Serveis Relacionats";
$_LANG['rssfeed'] = "RSS Feed";
$_LANG['securityanswerrequired'] = "Cal que introdueixi una resposta a la pregunta secreta";
$_LANG['securitybothnotmatch'] = "Les respostes no coincideixen";
$_LANG['securitycurrentincorrect'] = "La seva pregunta i resposta actual és incorrecta";
$_LANG['serverchangepassword'] = "Canviar Contrasenya";
$_LANG['serverchangepasswordintro'] = "Des d'aquí es pot canviar la contrasenya del producte / servei (nota: això no afecta la seva contrasenya per a la nostra àrea de clients)";
$_LANG['serverchangepasswordconfirm'] = "Confirmar la contrasenya";
$_LANG['serverchangepasswordenter'] = "Introduir nova contrasenya";
$_LANG['serverchangepasswordfailed'] = "No s'ha pogut canviar la contrasenya!";
$_LANG['serverchangepasswordsuccessful'] = "Contrasenya canviada correctament!";
$_LANG['serverchangepasswordupdate'] = "Actualitzar";
$_LANG['serverhostname'] = "Hostname";
$_LANG['serverlogindetails'] = "Detalls de connexió";
$_LANG['servername'] = "Server";
$_LANG['serverns1prefix'] = "NS1 Prefix";
$_LANG['serverns2prefix'] = "NS2 Prefix";
$_LANG['serverpassword'] = "Contrasenya";
$_LANG['serverrootpw'] = "Root Password";
$_LANG['serverstatusdescription'] = "Observar l'estat del nostre servidor";
$_LANG['serverstatusnoservers'] = "Al moment no s'està monitoritzant cap servidor";
$_LANG['serverstatusnotavailable'] = "No disponible";
$_LANG['serverstatusoffline'] = "Fora de Servei";
$_LANG['serverstatusonline'] = "En Servei";
$_LANG['serverstatusphpinfo'] = "Info de PHP";
$_LANG['serverstatusserverload'] = "Càrrega del servidor";
$_LANG['serverstatustitle'] = "Estat del servidor";
$_LANG['serverstatusuptime'] = "Hores d'Alta";
$_LANG['serverusername'] = "Usuari";
$_LANG['show'] = "Mostra";
$_LANG['ssladmininfo'] = "Informació del contacte Administratiu";
$_LANG['ssladmininfodetails'] = "La informació del contacte següent no serà desplegada en el Certificat - això només és usat per contactar amb respecte a aquesta ordre. El Certificat SSL i les futures renovacions seran enviades a l'adreça email especificada abaix.";
$_LANG['sslcertapproveremail'] = "Email d'aprovació del Certificat";
$_LANG['sslcertapproveremaildetails'] = "Vostè ara ha d'escollir de les opcions de sota l'email a on vol enviar el correu d'aprovació d'aquest certificat.";
$_LANG['sslcertinfo'] = "Informació del certificat SSL";
$_LANG['pleasechooseone'] = "Si us plau triï un ...";
$_LANG['sslcerttype'] = "Tipus de Certificat";
$_LANG['sslconfigcomplete'] = "Configuració Completa";
$_LANG['sslconfigcompletedetails'] = "La configuració del seu certificat SSL ha estat completada i enviada a l'entitat emissora de certificats per a la seva validació. Vostè ha de rebre ben aviat un correu d'ells amb l'aprovació.";
$_LANG['sslconfsslcertificate'] = "Configurar Certificat SSL";
$_LANG['sslcsr'] = "CSR";
$_LANG['sslerrorapproveremail'] = "Ha de triar una adreça de correu d'aprovació";
$_LANG['sslerrorentercsr'] = "Vostè ha d'ingressar el CSR (Certificate Signing Request)";
$_LANG['sslerrorselectserver'] = "Ha de seleccionar el tipus de servidor";
$_LANG['sslinvalidlink'] = "Enllaç invàlid de SSL.";
$_LANG['sslorderdate'] = "Data de Comanda";
$_LANG['sslserverinfo'] = "Informació del servidor";
$_LANG['sslserverinfodetails'] = "Vostè ha de tenir un \"CSR\"(Certificate Signing Request) vàlid per configurar el seu Certificat SSL. LCSR és una peça de texte encriptat que és generat pel servidor en que s'instal · larà el Certificat SSL . Si encara no té un CSR, vostè ha generar o demanar al seu proveïdor d'allotjament que generi un per a vostè. A més, asseguris d'haver ingressat la informació correcta ja que vostè no podrà canviar un Certificat SSL que ja ha estat creat.";
$_LANG['sslservertype'] = "Tipus de Servidors Web";
$_LANG['sslstatus'] = "Estat de Configuració";
$_LANG['statscreditbalance'] = "balanç de crèdit";
$_LANG['statsdueinvoicesbalance'] = "Balanç de factures Impagades";
$_LANG['statsnumdomains'] = "Nombre de Dominis";
$_LANG['statsnumproducts'] = "Nombre de serveis / productes";
$_LANG['statsnumreferredsignups'] = "Nombre d'Altes de Referits";
$_LANG['statsnumtickets'] = "Nombre de Tiquets";
$_LANG['submitticketdescription'] = "Si encara no és el nostre client o si ho és i vol fer una consulta ràpida, utilitzi aquest formulari";
$_LANG['supportclickheretocontact'] = "Faci clic aquí per contactar";
$_LANG['supportpresalesquestions'] = "Si vostè vol consultar abans de fer la seva comanda";
$_LANG['supportticketinvalid'] = "S'ha produït un error. No s'ha trobat el tiquet sol · licitat";
$_LANG['supportticketsallowedextensions'] = "Extensions de fitxer permeses";
$_LANG['supportticketschoosedepartment'] = "Triar Departament";
$_LANG['supportticketsclient'] = "client";
$_LANG['supportticketsclientemail'] = "Adreça electrònica";
$_LANG['supportticketsclientname'] = "Nom";
$_LANG['supportticketsdate'] = "Data";
$_LANG['supportticketsdepartment'] = "Departament";
$_LANG['supportticketsdescription'] = "Veure i respondre als tiquets existents";
$_LANG['supportticketserror'] = "Error";
$_LANG['supportticketserrornoemail'] = "No ha ingressat la seva adreça de correu";
$_LANG['supportticketserrornomessage'] = "No ha ingressat un missatge";
$_LANG['supportticketserrornoname'] = "No ha ingressat el seu nom";
$_LANG['supportticketserrornosubject'] = "No ha ingressat un assumpte";
$_LANG['supportticketsfilenotallowed'] = "L'arxiu que tracta de pujar no està permès.";
$_LANG['supportticketsheader'] = "Si no pot trobar una solució al seu problema a la base de coneixements, pot enviar un tiquet de suport triant el departament adequat abaix.";
$_LANG['supportticketsnotfound'] = "Tiquet No Trobat";
$_LANG['supportticketsopentickets'] = "Tiquets de suport Oberts";
$_LANG['supportticketspagetitle'] = "Tiquets de suport";
$_LANG['supportticketsposted'] = "Enviat";
$_LANG['supportticketsreply'] = "Respondre";
$_LANG['supportticketsstaff'] = "Empleat";
$_LANG['supportticketsstatus'] = "Estat";
$_LANG['supportticketsstatusanswered'] = "Contestat";
$_LANG['supportticketsstatusclosed'] = "Tancat";
$_LANG['supportticketsstatuscloseticket'] = "Tancar tiquet";
$_LANG['supportticketsstatuscustomerreply'] = "Resposta-client";
$_LANG['supportticketsstatusinprogress'] = "En Progrés";
$_LANG['supportticketsstatusonhold'] = "Retingut";
$_LANG['supportticketsstatusopen'] = "Obert";
$_LANG['supportticketssubject'] = "Assumpte";
$_LANG['supportticketssubmitticket'] = "Envia ticket de Consulta";
$_LANG['supportticketssystemdescription'] = "El sistema de tiquets de suport ens permet respondre a les seves consultes i problemes tan ràpid com sigui possible. Un cop hem elaborat una resposta per al seu tiquet, vostè serà notificat via email.";
$_LANG['supportticketsticketattachments'] = "Adjunts";
$_LANG['supportticketsticketcreated'] = "Tiquet Creat";
$_LANG['supportticketsticketcreateddesc'] = "El seu tiquet ha estat creat amb èxit. S'ha enviat a la seva adreça de correu un missatge amb la informació del tiquet. Si desitja veure el tiquet ara ho pot fer.";
$_LANG['supportticketsticketid'] = "ID del Tiquet";
$_LANG['supportticketsticketsubject'] = "Assumpte";
$_LANG['supportticketsticketsubmit'] = "Enviar";
$_LANG['supportticketsticketurgency'] = "Urgència";
$_LANG['supportticketsticketurgencyhigh'] = "Alta";
$_LANG['supportticketsticketurgencylow'] = "Baixa";
$_LANG['supportticketsticketurgencymedium'] = "Mitjana";
$_LANG['supportticketsuploadfailed'] = "No s'ha pogut pujar el fitxer adjunt";
$_LANG['supportticketsviewticket'] = "Veure ticket";
$_LANG['telesignincorrectpin'] = "Pin Incorrecte!";
$_LANG['telesigninitiatephone'] = "No podem iniciar la verificació de telèfon per al seu número. Posis en contacte amb nosaltres.";
$_LANG['telesigninvalidnumber'] = "Número de telèfon Invàlid";
$_LANG['telesigninvalidpin'] = "El PIN introduït no és vàlid!";
$_LANG['telesigninvalidpin2'] = "El PIN introduït no és vàlid.";
$_LANG['telesigninvalidpinmessage'] = "Verificació del codi Pin, Error";
$_LANG['telesignmessage'] = "Phone verification initiated for number% s. please wait ...";
$_LANG['telesignphonecall'] = "Trucada telefònica";
$_LANG['telesignpin'] = "Introdueixi el PIN:";
$_LANG['telesignsms'] = "Sms";
$_LANG['telesignsmstextmessage'] = "Thank you for using our SMS verification system. Your code is:% s please enter this code on your computer now.!";
$_LANG['telesigntitle'] = "TeleSign phone verification.";
$_LANG['telesigntype'] = "choose verification type for number% s:";
$_LANG['telesignverificationcanceled'] = "There is a temporary problem with the phone verification service and phone verification ha rebut canceled.";
$_LANG['telesignverificationproblem'] = "There was a problem with the phone verification service and your order could not be validated. please try again later.";
$_LANG['telesignverify'] = "Your phone number% s needs to be verified to completi the order.";
$_LANG['ticketratingexcellent'] = "Excel · lent";
$_LANG['ticketratingpoor'] = "Pobre";
$_LANG['ticketratingquestion'] = "Com qualificaria aquesta resposta?";
$_LANG['ticketreatinggiven'] = "Vostè ha qualificat aquesta resposta";
$_LANG['transferdomain'] = "Transferir Domini";
$_LANG['transferdomaindesc'] = "transferirà el seu domini a nosaltres. Introdueix el domini a continuació per començar.";
$_LANG['transferdomainname'] = "transferir un Nom de Domini";
$_LANG['updatecart'] = "Actualitzar Carro";
$_LANG['upgradechooseconfigoptions'] = "Canviar de pla d'allotjament o característiques";
$_LANG['upgradechoosepackage'] = "Seleccioni el paquet al que vostè vol actualitzar (augmentar / disminuir)";
$_LANG['upgradecurrentconfig'] = "Configuració actual";
$_LANG['upgradedowngradeconfigoptions'] = "Canviar opcions";
$_LANG['upgradenewconfig'] = "Nova configuració";
$_LANG['upgradenochange'] = "No canviar";
$_LANG['upgradeproductlogic'] = "L'actualització de preus es calcula a partir d'un crèdit de la part no utilitzada del pla actual i de facturació del nou pla per al mateix període";
$_LANG['upgradesummary'] = "Aquest és un sumari de les seves actualitzacions en plans d'allotjament.";
$_LANG['usedefaultcontact'] = "Utilitzar contacte per defecte (Dades superiors)";
$_LANG['varilogixfraudcall_callnow'] = "Trucar Ara!";
$_LANG['varilogixfraudcall_description'] = "Com a mesura de seguretat, farem una trucada telefònica al número que ha especificat. Se li demanarà que ingressi el Codi PIN de dalt. Prengui nota d'aquest Codi i quan estigui llest faci clic al botó de sota . ";
$_LANG['varilogixfraudcall_error'] = "S'ha produït un error i la trucada per verificar la seva comanda s'ha pogut fer. Posis en contacte amb el nostre Departament de suport per completar la seva comanda.";
$_LANG['varilogixfraudcall_fail'] = "La trucada per verificar la seva comanda ha fallat. Això pot ser degut a que ha ingressat malament número de telèfon o bé aquest número està bloquejat pel nostre sistema. Posis en contacte amb el nostre Departament de suport per a completar la seva comanda. ";
$_LANG['varilogixfraudcall_failed'] = "No s'ha pogut";
$_LANG['varilogixfraudcall_pincode'] = "Codi PIN";
$_LANG['varilogixfraudcall_title'] = "varilogix FraudCall";
$_LANG['viewcart'] = "Veure Carro";
$_LANG['welcomeback'] = "Benvingut";
$_LANG['whoisresults'] = "Resultats de WHOIS per";
$_LANG['yes'] = "Si";
$_LANG['yourdetails'] = "Les seves Dades";

# Version 4.1

$_LANG['clientareafiles'] = "Arxius adjunts";
$_LANG['clientareafilesdate'] = "Data en què es va afegir";
$_LANG['clientareafilesfilename'] = "Nom del fitxer";

$_LANG['pwreset'] = "Restaurar contrasenya oblidada";
$_LANG['pwresetdesc'] = "Si ha oblidat la seva contrasenya, la pot restaurar aquí. Quan vostè ompli la seva adreça electrònica registrada (i contesti a la seva pregunta de seguretat del seu compte si es va establir), li enviarem instruccions de com restaurar la contrasenya. ";
$_LANG['pwresetemailrequired'] = "No ha omplert la seva adreça de correu";
$_LANG['pwresetemailnotfound'] = "No s'ha trobat cap client amb aquesta adreça de correu";
$_LANG['pwresetsecurityquestionrequired'] = "En cas de tenir una pregunta de seguretat establerta en el seu compte, ha d'introduir a continuació la resposta a aquesta pregunta.";
$_LANG['pwresetsecurityquestionincorrect'] = "La resposta a la pregunta de seguretat introduïda no coincideix amb la resposta establerta en el seu compte";
$_LANG['pwresetsubmit'] = "Enviar";
$_LANG['pwresetvalidationsent'] = "Correu de validació enviat";
$_LANG['pwresetvalidationcheckemail'] = "Ha començat el procés de restauració de contrasenya. Si us plau, comprovi en el seu mail les instruccions que ha de seguir a continuació.";
$_LANG['pwresetkeyinvalid'] = "L'enllaç per a restaurar que ha usat no és vàlid. Torni-ho a provar de nou.";
$_LANG['pwresetkeyexpired'] = "L'enllaç per restaurar que ha usat ha caducat. Torni-ho a provar de nou.";
$_LANG['pwresetvalidationsuccess'] = "Contrasenya restaurada amb èxit";

$_LANG['overagescharges'] = "Càrrec de sobreús de recursos";
$_LANG['overagestotaldiskusage'] = "Ús del disc total";
$_LANG['overagestotalbwusage'] = "Ús total de l'ample de banda";

$_LANG['affiliatescommissionspending'] = "Comissions pendents de maduració";
$_LANG['affiliatescommissionsavailable'] = "Balanç de comissions disponibles";
$_LANG['affiliatessignups'] = "Nombre de membres";
$_LANG['affiliatesconversionrate'] = "Tipus de canvi";

$_LANG['configoptionqtyminmax'] = "% s té un requisit mínim de %s i màxim de %s";

$_LANG['creditcardnostore'] = "Marqui aquesta casella si NO vol que es guardin les dades de la targeta de crèdit per quan es torni a emetre factura";
$_LANG['creditcarddelete'] = "Esborrar les dades de la targeta guardats";
$_LANG['creditcarddeleteconfirmation'] = "Les dades de la targeta guardats han estat eliminats del seu compte";
$_LANG['creditcardupdatenotpossible'] = "Les dades de la targeta de crèdit no poden ser actualitzats en aquest moment. Torni-ho a provar més tard.";

$_LANG['invoicepaymentsuccessconfirmation'] = "Gràcies! El seu pagament s'ha realitzat correctament.";
$_LANG['invoicepaymentfailedconfirmation'] = "El vostre intent de pagament no s'ha realitzat amb èxit. <br /> Torni-ho a provar de nou o contacti amb nosaltres.";

# Version 4.2

$_LANG['promoappliedbutnodiscount'] = "El codi de descompte introduït s'ha aplicat a la seva cistella però encara no hi ha articles amb dret a descompte - si us plau comprovi les condicions de la promoció";

$_LANG['upgradeerroroverdueinvoice'] = "Actualment no pot actualitzar ni desactualizar aquest producte perquè s'ha generat ja una factura per a la pròxima renovació. <br /> <br /> Per procedir a fer-ho, si us plau en primer lloc pagui la factura pendent i llavors podrà actualitzi i desactualizi immediatament després i la diferència serà abonada o carregada segons correspongui. ";

$_LANG['subaccountactivate'] = "sub-Compte activat";
$_LANG['subaccountactivatedesc'] = "Marqui per configurar com subcompte amb accés a l'àrea de clients";
$_LANG['subaccountpermissions'] = "Permisos de subcompte";
$_LANG['subaccountpermsprofile'] = "Modifica el perfil del compte principal";
$_LANG['subaccountpermscontacts'] = "Veure i Gestionar contactes";
$_LANG['subaccountpermsproducts'] = "Veure Productes i Serveis";
$_LANG['subaccountpermsmanageproducts'] = "Veure i Modificar contrasenyes de producte";
$_LANG['subaccountpermsdomains'] = "Veure dominis";
$_LANG['subaccountpermsmanagedomains'] = "Administrar Configuració de Domini";
$_LANG['subaccountpermsinvoices'] = "Veure i Pagar factures";
$_LANG['subaccountpermstickets'] = "Veure i Obrir tiquets de suport";
$_LANG['subaccountpermsaffiliates'] = "Veure i Gestionar compte d'afiliat";
$_LANG['subaccountpermsemails'] = "Veure Emails";
$_LANG['subaccountpermsorders'] = "Establir Noves Sol · licituds / Actualitzacions / Cancel·lacions";
$_LANG['subaccountpermissiondenied'] = "No té els permisos necessaris per accedir a aquesta pàgina";
$_LANG['subaccountallowedperms'] = "Els seus permisos autoritzats són:";
$_LANG['subaccountcontactmaster'] = "Contacti amb el propietari del compte principal si vostè creu que això és un error.";

$_LANG['knowledgebasealsoread'] = "Llegir també";

$_LANG['orderpaymenttermtriennially'] = "triennalment";
$_LANG['orderpaymentterm36month'] = "Preu de 36 mesos";

$_LANG['domainrenewals'] = "Renovació de Dominis";
$_LANG['domaindaysuntilexpiry'] = "Dies per caducar";
$_LANG['domainrenewalsnoneavailable'] = "No hi ha dominis elegits per renovar en el seu compte";
$_LANG['domainrenewalspastgraceperiod'] = "S'ha passat el període de renovació";
$_LANG['domainrenewalsingraceperiod'] = "Darrera oportunitat per renovar!";
$_LANG['domainrenewalsdays'] = "Dies";
$_LANG['domainrenewalsdaysago'] = "Dies passats";

$_LANG['invoicespartialpayments'] = "Pagaments parcials";
$_LANG['invoicestotaldue'] = "Deute total";

$_LANG['masspaytitle'] = "Pagament massiu";
$_LANG['masspaydescription'] = "A continuació hi ha un resum de les factures seleccionades i el deute total per pagar-les en la seva totalitat. Per a realitzar el pagament, si us plau, únicament seleccioni el mètode de pagament establert més avall.";
$_LANG['masspayselected'] = "Pagament seleccionat";
$_LANG['masspayall'] = "Pagar-la";
$_LANG['masspaymakepayment'] = "Fer el pagament";

# Version 4.3

$_LANG['searchenterdomain'] = "Escrigui el domini";
$_LANG['searchfilter'] = "Filtre";

$_LANG['suspendreason'] = "Motiu de suspensió";
$_LANG['suspendreasonoverdue'] = "Pagament vençut";

$_LANG['vpsnetmanagement'] = "Administració VPS";
$_LANG['vpsnetpowermanagement'] = "Administració d'energia";
$_LANG['poweron'] = "endollat";
$_LANG['poweroffforced'] = "Power Off (Forced)";
$_LANG['powerreboot'] = "Reiniciar";
$_LANG['powershutdown'] = "Tancar";
$_LANG['vpsnetcpugraphs'] = "Gràfics CPU";
$_LANG['vpsnetnetworkgraphs'] = "Gràfics de xarxa";
$_LANG['vpsnethourly'] = "Cada hora";
$_LANG['vpsnetdaily'] = "Cada dia";
$_LANG['vpsnetweekly'] = "Cada setmana";
$_LANG['vpsnetmonthly'] = "Cada mes";
$_LANG['view'] = "Veure";
$_LANG['vpsnetbackups'] = "Opcions de còpia de seguretat";
$_LANG['vpsnetgenbackup'] = "Generar còpia de seguretat";
$_LANG['vpsnetrestorebackup'] = "Restaurar còpia de seguretat";
$_LANG['vpsnetrestorebackupwarning'] = "En resturar la còpia de seguretat s'escriurà sobre del seu servidor VPS";
$_LANG['vpsnetnobackups'] = "No hi ha còpies de seguretat";
$_LANG['vpsnetrunning'] = "Funcionant";
$_LANG['vpsnetnotrunning'] = "No funcionant";
$_LANG['vpsnetpowercycling'] = "Passant energia";
$_LANG['vpsnetcloud'] = "En núvol";
$_LANG['vpsnettemplate'] = "Plantilla";
$_LANG['vpsnetstatus'] = "Estat del sistema";
$_LANG['vpsnetbwusage'] = "Ús d'ample de banda";

$_LANG['twitterlatesttweets'] = "Els nostres últims Tweets";
$_LANG['twitterfollow'] = "Segueix-nos a Twitter";
$_LANG['twitterfollowus'] = "Segueixi-nos";
$_LANG['twitterfollowuswhy'] = "per mantenir-se al dia amb les nostres últimes notícies i ofertes";

$_LANG['chatlivehelp'] = "Ajuda vital";

$_LANG['domainrelease'] = "Cessió de domini";
$_LANG['domainreleasedescription'] = "Introdueixi una nova ETIQUETA aquí per a traslladar el seu nom de domini a un altre registre";
$_LANG['domainreleasetag'] = "Nova etiqueta registradora";

# Ajax Order Form

$_LANG['orderformtitle'] = "Formulari de comanda";

$_LANG['signup'] = "Registrar";
$_LANG['loading'] = "Carregant ...";

$_LANG['ordersummarybegin'] = "El Carro de compres és buit <br/> triï un producte per començar ...";

$_LANG['cartchooseproduct'] = "Triar producte";
$_LANG['cartconfigurationoptions'] = "Opcions de configuració";

$_LANG['ordererrorsoccurred'] = "S'han produït els següents errors i han de ser corregits abans de verificar:";
$_LANG['ordererrortermsofservice'] = "Les condicions del servei han de ser acceptades per";
$_LANG['ordertostickconfirm'] = "Si us plau, marqui per confirmar que està d'acord amb";

$_LANG['cartnewcustomer'] = "Sóc un nou client";
$_LANG['cartexistingcustomer'] = "Estic registrat com a client";

$_LANG['cartpromo'] = "Oferta";
$_LANG['cartenterpromo'] = "Introduir codi d'oferta";
$_LANG['cartremovepromo'] = "Eliminar oferta";

$_LANG['cartrecurringcharges'] = "Càrrecs recurrents";

$_LANG['cartenterdomain'] = "Si us plau, introdueixi el domini que vol utilitzar a continuació.";

$_LANG['cartdomainavailableoptions'] = "Felicitats, aquest domini està disponible!";
$_LANG['cartdomainavailableregister'] = "Si us plau registrar aquest domini per";
$_LANG['cartdomainavailablemanual'] = "Em registraré a mi mateix per separat";

$_LANG['cartdomainunavailableoptions'] = "Ho sentim, aquest domini ja s'està utilitzat.Si és vostè el propietari, si us plau seleccioneu una de les següents opcions ...";
$_LANG['cartdomainunavailabletransfer'] = "Si us plau transfereixi el meu domini a";
$_LANG['cartdomainunavailablemanual'] = "Jo tinc aquest domini i actualitzaré els servidors de noms";

$_LANG['cartdomaininvalid'] = "El domini introduït no és vàlid. Introdueixi només la part després de www. I inclogui el TLD";

# Version 4.4

$_LANG['dlinvalidlink'] = "L'enllaç no és vàlid, si us plau contacti amb suport";

$_LANG['domaindnsmanagementlaunch'] = "Iniciar Administrador de DNS";
$_LANG['domainemailforwardinglaunch'] = "Iniciar Administrador de Redirecció de correu";

# Version 4.5

$_LANG['domaindnspriority'] = "Prioritat";
$_LANG['domaindnsmxonly'] = "Prioritat de Registre MX Només";

$_LANG['orderpromoprestart'] = "Aquesta promoció encara no ha començat. Provi-ho més tard.";

$_LANG['ticketmerge'] = "fusionats";

$_LANG['quote'] = "Cotitzar";
$_LANG['quotestitle'] = "Les meves Cotitzacions";
$_LANG['quoteview'] = "Veure";
$_LANG['quotedownload'] = "Veure / Descarregar";
$_LANG['quoteacceptbtn'] = "Acceptar Cotització";
$_LANG['quotedlpdfbtn'] = "Descarregar PDF";
$_LANG['quotediscountheading'] = "Descompte (%)";
$_LANG['noquotes'] = "Actualment no hi ha cotitzacions guardades en el seu compte. <br /> Per sol · licitar una cotització, si us plau obri un tiquet.";
$_LANG['quotenumber'] = "Cotització #";
$_LANG['quotesubject'] = "Assumpte";
$_LANG['quotedatecreated'] = "Data de creació";
$_LANG['quotevaliduntil'] = "Vàlid Fins";
$_LANG['quotestage'] = "Etapa";
$_LANG['quoterecipient'] = "Recipient";
$_LANG['quoteqty'] = "Quant.";
$_LANG['quotedesc'] = "Descripció";
$_LANG['quoteunitprice'] = "Preu Unitari";
$_LANG['quotediscount'] = "Descompte %";
$_LANG['quotelinetotal'] = "Total";
$_LANG['quotestagedraft'] = "Esborrany";
$_LANG['quotestagedelivered'] = "Enviada";
$_LANG['quotestageonhold'] = "En Espera";
$_LANG['quotestageaccepted'] = "Acceptada";
$_LANG['quotestagelost'] = "Perduda";
$_LANG['quotestagedead'] = "Morta";
$_LANG['quoteref'] = "Re Cotització #";
$_LANG['quotedeposit'] = "Dipòsit";
$_LANG['quotefinalpayment'] = "Saldo del Dipòsit";

$_LANG['invoiceoneoffpayment'] = "Fer pagament únic";
$_LANG['invoicesubscriptionpayment'] = "Crea subscripció Recurrent Automàtica";

$_LANG['invoicepaymentpendingreview'] = "Gràcies! El seu pagament s'ha realitzat correctament i s'aplicarà a la seva factura tan aviat com la revisió del procés de 2checkOut s'hagi completat. <br /> <br /> Això pot prendre fins a un parell d'hores pel que la seva paciència és apreciada. ";

$_LANG['step'] = "Pas %s";
$_LANG['cartdomainexists'] = "Aquest domini ja existeix a la nostra base de dades per tant no pot tornar a demanar-lo.";
$_LANG['cartcongratsdomainavailable'] = "Felicitats, %s està disponible!";
$_LANG['cartregisterhowlong'] = "Per quant de temps voleu registrar?";
$_LANG['cartdomaintaken'] = "Ho sento, %s ja està registrat";
$_LANG['carttransfernotregistered'] = "%s sembla no estar registrat encara";
$_LANG['carttransferpossible'] = "Felicitacions, nosaltres podem transferir %s cap a nosaltres per només %s";
$_LANG['cartotherdomainsuggestions'] = "Altres dominis en què pogués estar interessat ...";
$_LANG['cartdomainsconfiginfo'] = "Les següents opcions i ajustaments estan disponibles per als dominis que vostè ha triat. Els camps obligatoris es troben indicats amb un *.";
$_LANG['cartnameserverchoice'] = "Trieu el nameserver";
$_LANG['cartnameserverchoicedefault'] = "Utilitza els noms del servidor per defecte del nostre Allotjament";
$_LANG['cartnameserverchoicecustom'] = "Utilitza noms de servidor personalitzats";
$_LANG['cartfollowingaddonsavailable'] = "Els següents addicionals a disposició dels seus productes actius i serveis.";
$_LANG['cartregisterdomainchoice'] = "Registrar un nou domini";
$_LANG['carttransferdomainchoice'] = "Transferir el seu domini des d'un altre registrar";
$_LANG['cartexistingdomainchoice'] = "Jo utilitzaré el meu propi domini i modificaré els noms del servidor";
$_LANG['cartsubdomainchoice'] = "Utilitza un subdomini de %s";
$_LANG['carterrordomainconfigskipped'] = "Vostè ha de tornar enrere i completar els camps requerits de la configuració del domini";
$_LANG['cartproductchooseoptions'] = "Seleccioni les Opcions";
$_LANG['cartproductselection'] = "Selecció de Productes";
$_LANG['cartreviewcheckout'] = "Revisar i Pagar";
$_LANG['cartchoosecycle'] = "Triï Cicle de facturació";
$_LANG['cartavailableaddons'] = "addicionals disponibles";
$_LANG['cartsetupfees'] = "Cost d'instal · lació";
$_LANG['cartchooseanotherproduct'] = "Triï un altre producte";
$_LANG['cartaddandcheckout'] = "Afegir a la cistella i pagar";
$_LANG['cartchooseanothercategory'] = "Veure Altres Categories";
$_LANG['carttryanotherdomain'] = "Provar un altre domini";
$_LANG['cartmakedomainselection'] = "Si us plau, indiquins el domini que vol utilitzar amb el seu servei d'allotjament, seleccionant una de les opcions.";
$_LANG['cartfraudcheck'] = "Revisió de Frau";

$_LANG['newcustomer'] = "Nou client";
$_LANG['existingcustomer'] = "client Existent";
$_LANG['newcustomersignup'] = "No està Registrat? %SClic aquí per registrar-se ...%s";

$_LANG['upgradeonselectedoptions'] = "(En Opcions Seleccionades)";
$_LANG['recurringpromodesc'] = "Aquest codi de promoció també inclou un %s Descompte Recurrent <br /> (Aquest descompte també s'aplicarà per a futures renovacions en el preu total del producte)";

# Version 4.5.2

$_LANG['ajaxcartcheckout'] = "Anar directament a la caixa» ";
$_LANG['ordersummarybegin'] = "El Carro de compres és buit <br/> triï un producte per començar ...";
$_LANG['ajaxcartconfigreqnotice'] = "Està a punt de registrar-se amb nosaltres, però cal triar un domini abans d'afegir el producte seleccionat a la seva cistella ...";

# Version 5.0.0

$_LANG['cancelrequestdomain'] = "Cancel · lar la renovació del domini?";
$_LANG['cancelrequestdomaindesc'] = "Ja te un registre de domini actiu per al domini associat a aquest producte <br /> Aquest domini serà renovat el %s a un preu de %s per %s Any / s <br /> < br /> Si vol cancel · lar aquest domini i no vol renovar quan finalitzi el temps de registre acutal, simplement marqui la casella de sota. ";
$_LANG['cancelrequestdomainconfirm'] = "Confirmo que no vull renovar aquest domini una altra vegada";

$_LANG['startingfrom'] = "Desde";

$_LANG['orderpromopriceoverride'] = "substituir preu";
$_LANG['orderpromofreesetup'] = "Alta gratis";

$_LANG['thereisaproblem'] = "Uups, hi ha un problema ...";
$_LANG['problemgoback'] = "Torna enrere i torni a provar";

$_LANG['quantity'] = "Quantitat";
$_LANG['cartqtyenterquantity'] = "Vol més d'1 unitat d'aquest producte? Introdueixi Quantitat:";
$_LANG['cartqtyupdate'] = "Actualitzar";
$_LANG['invoiceqtyeach'] = "/ unitat";

$_LANG['nschoicedefault'] = "Utilitzar nameservers per defecte";
$_LANG['nschoicecustom'] = "Utilitzar nameservers personalitzats (introduir-los abaix)";

$_LANG['jumpto'] = "Anar a";
$_LANG['top'] = "Amunt";

$_LANG['domaincontactusexisting'] = "Utilitzar compte de contacte existent";
$_LANG['domaincontactusecustom'] = "Especificar informació personalitzada abaix";
$_LANG['domaincontactchoose'] = "Triar contacte";
$_LANG['domaincontactprimary'] = "Dades del perfil Primari";

$_LANG['invoicepdfgenerated'] = "PDF Generat el";

$_LANG['domainrenewalsbeforerenewlimit'] = "El període mínim per a una nova renovació és de %s Dies";

$_LANG['promonewsignupsonly'] = "Aquest codi de promoció és vàlid només per als nous clients";

# Bulk Domain Management

$_LANG['domainbulkmanagement'] = "Gestió Massiva d'Accions";
$_LANG['domainbulkmanagementchangesaffect'] = "Els canvis realitzats a sota afectaran als següents dominis:";
$_LANG['domainbulkmanagementchangeaffect'] = "Aquest canvi s'aplicarà als següents dominis:";
$_LANG['domaincannotbemanaged'] = "no es pot gestionar automàticament - si us plau, contacti amb suport i sol · liciti qualsevol canvi que vulgui fer";
$_LANG['domainbulkmanagementnotpossible'] = "Desafortunadament, aquestes opcions no poden ser editades des del nostre àrea de clients en aquest moment. Si us plau, contacti amb suport i sol · liciti qualsevol canvi que vulgui fer.";

$_LANG['domainmanagens'] = "Gestionar nameservers";

$_LANG['domainautorenewstatus'] = "Estat d'autorenovació";
$_LANG['domainautorenewinfo'] = "L'autorenovació ajuda a protegir el seu domini. Quan està habilitada, li enviarem automàticament una factura de renovació unes setmanes abans que el seu domini expiri, i el seu domini serà renovat quan realitzi el pagament.";
$_LANG['domainautorenewrecommend'] = "Li recomanem que habiliti l'autorenovació per prevenir la pèrdua del seu domini.";

$_LANG['domainreglockstatus'] = "Estat de Bloqueig de Registre";
$_LANG['domainreglockinfo'] = "El Bloqueig de Registre assegura el seu domini contra transferències no autoritzades.";
$_LANG['domainreglockrecommend'] = "Li recomanem que activi aquesta opció, excepte quan vulgui transferir el seu domini a un altre registrant.";
$_LANG['domainreglockenable'] = "Activar Bloqueig de Registre";
$_LANG['domainreglockdisable'] = "Desactivar Bloqueig de Registre";

$_LANG['domaincontactinfoedit'] = "Editar Informació de contacte";

$_LANG['domainmassrenew'] = "Renovar Dominis";

# reCAPTCHA

$_LANG['captchatitle'] = "Verificació anti-spam";
$_LANG['captchaverify'] = "Si us plau, introdueix dins de la caixa de text els caràcters que veu a la imatge de sota. Això és requerit per evitar enviaments automàtics.";
$_LANG['captchaverifyincorrect'] = "Els caràcters que ha introduït no es corresponen amb els de la imatge. Torni-ho a provar de nou.";
$_LANG['recaptcha-invalid-site-private-key'] = "S'ha produït un error, si us plau, contacti amb suport (codi d'error: cap1)";
$_LANG['recaptcha-invalid-request-cookie'] = "S'ha produït un error, si us plau torni-ho a provar (codi d'error: cap2)";
$_LANG['recaptcha-incorrect-captcha-sol'] = "Els caràcters que ha introduït no es corresponen amb la paraula de verificació. Torni-ho a provar de nou.";

# Product Bundles

$_LANG['bundledeal'] = "Paquet d'oferta!";
$_LANG['bundlevaliddateserror'] = "Paquet no disponible";
$_LANG['bundlevaliddateserrordesc'] = "Aquest paquet ja no està actiu o ha expirat. Si considera que això pot ser un error, si us plau, contacti amb suport.";
$_LANG['bundlemaxusesreached'] = "Paquet no disponible";
$_LANG['bundlemaxusesreacheddesc'] = "Aquest paquet d'oferta ha rebut el màxim nombre d'usos permesos i ja no està disponible. Si us plau, contacti amb nosaltres si està interessat en els nostres serveis.";
$_LANG['bundlereqsnotmet'] = "Requisits del Paquet no complerts";
$_LANG['bundlewarningpromo'] = "El paquet seleccionat no pot ser utilitzat en conjunt amb cap altra promoció o oferta";
$_LANG['bundlewarningproductcycle'] = "El paquet seleccionat requereix que esculli el cicle de facturació '%s' per al producte %s per a cualificar-lo";
$_LANG['bundlewarningproductconfopreq'] = "El paquet seleccionat requereix que seleccioni '%s' per '%s' per poder cualificar-lo";
$_LANG['bundlewarningproductconfopyesnoenable'] = "El paquet seleccionat requereix que activi l'opció '%s' per poder cualificar-lo";
$_LANG['bundlewarningproductconfopyesnodisable'] = "El paquet seleccionat requereix que deseleccioni l'opció '%s' per poder cualificar-lo";
$_LANG['bundlewarningproductconfopqtyreq'] = "El paquet seleccionat requereix que esculli una quantitat de '%s' per '%s' per poder cualificar-lo";
$_LANG['bundlewarningproductaddonreq'] = "El paquet seleccionat requereix que seleccioni el complement '%s' per al producte %s per a poder cualificar-lo";
$_LANG['bundlewarningdomainreq'] = "El paquet seleccionat requereix que registri o transfereixi un domini amb el producte %s per a poder cualificar-lo";
$_LANG['bundlewarningdomaintld'] = "El paquet seleccionat requereix que triï un domini amb l'extensió (és) '%s' per al domini %s per a poder cualificar-lo";
$_LANG['bundlewarningdomainregperiod'] = "El paquet seleccionat requereix que seleccioni el període de registre '%s' per al domini %s per a poder cualificar-lo";
$_LANG['bundlewarningdomainaddon'] = "El paquet seleccionat requereix que seleccioni el complement '%s' per al domini %s per a poder cualificar-lo";

# New Client Area Template  Lines

$_LANG['navservices'] = "Serveis";
$_LANG['navservicesorder'] = "Comprar Nou Servei";
$_LANG['navdomains'] = "Dominis";
$_LANG['navrenewdomains'] = "Renovar Dominis";
$_LANG['navregisterdomain'] = "Registrar un Nou Domini";
$_LANG['navtransferdomain'] = "transferir un Domini";
$_LANG['navwhoislookup'] = "Whois Lookup";
$_LANG['navbilling'] = "Facturació";
$_LANG['navsupport'] = "suport";
$_LANG['navtickets'] = "Tiquets";
$_LANG['navopenticket'] = "Tiquet Obert";
$_LANG['navmanagecc'] = "Gestionar targeta de crèdit";
$_LANG['navemailssent'] = "Emails enviats";

$_LANG['hello'] = "Hola";
$_LANG['account'] = "Compte";
$_LANG['login'] = "Entrada";
$_LANG['register'] = "Registrar-se";
$_LANG['forgotpw'] = "Ha perdut la contrasenya?";
$_LANG['editaccountdetails'] = "Editar Detalls del Compte";

$_LANG['clientareanavccdetails'] = "Detalls de la targeta de crèdit";
$_LANG['clientareanavcontacts'] = "contactes / sub-Comptes";

$_LANG['manageyouraccount'] = "Gestionar el seu compte";
$_LANG['accountoverview'] = "Visualitzar Compte";
$_LANG['paymentmethod'] = "Mètode de pagament";
$_LANG['paymentmethoddefault'] = "Utilitzar per defecte (Definir per Comanda)";
$_LANG['productmanagementactions'] = "Gestionar Accions";
$_LANG['clientareanoaddons'] = "No has comprat complements";
$_LANG['downloadssearch'] = "Buscar descàrregues";
$_LANG['emailviewmessage'] = "Veure Missatge";
$_LANG['resultsperpage'] = "resultats per Pàgina";
$_LANG['accessdenied'] = "Accés Denegat";
$_LANG['search'] = "Cerca";
$_LANG['cancel'] = "Cancel · lar";
$_LANG['clientareabacklink'] = "« Enrere ";
$_LANG['backtoserviceslist'] = "« Tornar a la llista de serveis ";
$_LANG['backtodomainslist'] = "« Tornar a la llista de dominis ";

$_LANG['clientareahomeorder'] = "Visitar el formulari de comanda per veure els Productes i Serveis que oferim. Els clients existents també poden comprar extres opcionals i complements des d'aquí.";
$_LANG['clientareahomelogin'] = "Ja està registrat? Si és així, faci clic al botó de sota per accedir a la seva àrea de client, des d'on podrà gestionar el seu compte.";
$_LANG['clientareahomeorderbtn'] = "Anar al Formulari de Comanda";
$_LANG['clientareahomeloginbtn'] = "Accés Segur client";

$_LANG['clientareaproductsintro'] = "Aquests són tots els serveis que ha registrat en aquest compte.";
$_LANG['clientareaproductdetailsintro'] = "Aquest és un resum del seu producte / servei amb nosaltres.";
$_LANG['clientareadomainsintro'] = "Aquests són tots els dominis que ha registrat en aquest compte.";
$_LANG['invoicesintro'] = "Abaix pot veure un historial complert de les factures.";
$_LANG['quotesintro'] = "Aquí estan tots els pressupostos que hem generat per a vostè.";
$_LANG['emailstagline'] = "Aquí hi ha una còpia de tots els correus electrònics recents que li hem enviat ...";
$_LANG['supportticketsintro'] = "Enviï i segueixi qualsevol qüestió que tingui amb nosaltres aquí ...";
$_LANG['addfundsintro'] = "Dipositar diners per avançat";
$_LANG['registerintro'] = "Crear un compte amb nosaltres ...";
$_LANG['masspayintro'] = "Pagar totes les factures llistades avall en una única i senzilla transacció escollint un mètode de pagament";
$_LANG['domaincheckerintro'] = "Comenci la seva elecció de Allotjament Web comprovant aquí si el seu domini està disponible ...";
$_LANG['networkstatusintro'] = "Informació de l'Estat del Servei i Anuncis de la Xarxa";

$_LANG['creditcardyourinfo'] = "Informació de facturació";
$_LANG['ourlatestnews'] = "Les nostres últimes notícies";
$_LANG['ccexpiringsoon'] = "La targeta de crèdit caduca aviat";
$_LANG['ccexpiringsoondesc'] = "La seva targeta de crèdit caducarà aviat així que, si us plau, asseguri's d'actualitzar els detalls de la targeta %s així que pugui";
$_LANG['availcreditbal'] = "Crèdit Disponible";
$_LANG['availcreditbaldesc'] = "Ten un crèdit de %s i serà aplicat automàticament a les noves factures";
$_LANG['youhaveoverdueinvoices'] = "Té %s Factura (es) Vençuda (s)";
$_LANG['overdueinvoicesdesc'] = "Per prevenir la interrupció del servei, si us plau, pagi les factures vençudes com més aviat millor. %S Pagar Ara &raquo;%s";
$_LANG['supportticketsnoneopen'] = "Actualment no hi ha cap tiquet de suport obert";
$_LANG['invoicesnoneunpaid'] = "Actualment no hi ha factures sense pagar";

$_LANG['registerdisablednotice'] = "Per registrar-se, si us plau, faci una <strong><a href=\"cart.php\">comanda</a></strong>";

$_LANG['pwstrength'] = "Seguretat de la contrasenya";
$_LANG['pwstrengthenter'] = "Introduir una contrasenya";
$_LANG['pwstrengthweak'] = "Baixa";
$_LANG['pwstrengthmoderate'] = "Moderada";
$_LANG['pwstrengthstrong'] = "Alta";

$_LANG['managing'] = "Gestionar";
$_LANG['information'] = "Informació";
$_LANG['withselected'] = "Amb Seleccionat (s)";
$_LANG['managedomain'] = "Gestionar Domini";
$_LANG['changenameservers'] = "Canviar nameservers";
$_LANG['clientareadomainmanagedns'] = "Gestionar DNS";
$_LANG['clientareadomainmanageemailfwds'] = "Gestionar Redireccions de Email";
$_LANG['moduleactionsuccess'] = "Acció Completada Satisfactòriament!";
$_LANG['moduleactionfailed'] = "Acció fallida";

$_LANG['domaininfoexp'] = "A la dreta trobarà els detalls del seu domini. Pot gestionar el seu domini fent servir les pestanyes de dalt.";
$_LANG['domainrenewexp'] = "Activar la autorenovació perquè li enviem una factura de renovació automàticament abans que el seu domini expiri.";
$_LANG['domainnsexp'] = "Des d'aquí pot canviar la direcció a la qual apunta el seu domini. Recordi que els canvis poden trigar fins a 24h en propagar-se.";
$_LANG['domainlockingexp'] = "Bloquegi el seu domini per a evitar que sigui transferit sense la seva autorització.";
$_LANG['domaincurrentlyunlocked'] = "El Domini està Desbloquejat!";
$_LANG['domaincurrentlyunlockedexp'] = "Hauria d'activar el bloqueig de registre a menys que estigui transferint el domini a un altre registrador.";
$_LANG['searchmultipletlds'] = "Cerca múltiples TLDs";

$_LANG['networkstatustitle'] = "Estat de la xarxa";
$_LANG['networkstatusnone'] = "Actualment no hi ha %s fallades en la xarxa";
$_LANG['serverstatusheadingtext'] = "A sota hi ha una llista en temps real dels nostres servidors, on pot comprovar qualsevol problema conegut.";

$_LANG['clientareacancelreasonrequired'] = "Ha d'introduïr un motiu per a la cancel · lació";

$_LANG['addfundsdescription'] = "Afegeixi fons al seu compte per evitar realitzar moltes transaccions petites i per pagar automàticament les noves factures generades.";
$_LANG['addfundsnonrefundable'] = "* Els dipòsits no són reembolsables.";

$_LANG['creditcardexpirydateinvalid'] = "La data de caducitat ha de ser introduïda en el format MM / AA i no pot ser una data passada";

$_LANG['domaincheckerchoosedomain'] = "Esculli un domini ...";
$_LANG['domaincheckerchecknewdomain'] = "Comprovi la disponibilitat d'un domini";
$_LANG['domaincheckerdomainexample'] = "ex. Tudominio.com";
$_LANG['domaincheckerinvalidtld'] = "no és un TLD vàlid. Torni-ho a provar de nou.";
$_LANG['domaincheckerhostingonly'] = "Comprar només allotjament";
$_LANG['domaincheckeravailtransfer'] = "Disponible per Transferir";
$_LANG['domaincheckerenterdomain'] = "Comenci a provar els nostres serveis introduint un domini que vulgui registrar o transferir, o simplement compri un allotjament web abaix ...";
$_LANG['domaincheckerbulkinvaliddomain'] = "Un o més dels dominis que ha introduït adalt no són vàlids i han estat omesos en els resultats";

$_LANG['kbquestionsearchere'] = "Té alguna pregunta? Comenci la cerca aquí.";
$_LANG['contactus'] = "Contacti'ns";

$_LANG['opennewticket'] = "Obrir Nou ticket";
$_LANG['searchtickets'] = "Introduir ticket # o Assumpte";
$_LANG['supportticketspriority'] = "Prioritat";
$_LANG['supportticketsubmitted'] = "Enviat";
$_LANG['supportticketscontact'] = "contacte";
$_LANG['supportticketsticketlastupdated'] = "Última Actualització";

$_LANG['upgradedowngradepackage'] = "Augmentar / Reduir";
$_LANG['upgradedowngradechooseproduct'] = "Escollir Producte";

$_LANG['jobtitlereqforcompany'] = "(Requerit si el Nom de la Companyia s'ha introduït)";

$_LANG['downloadproductrequired'] = "Per baixar aquest document és necessari que tingui el següent producte / servei actiu:";

$_LANG['affiliatesignuptitle'] = "Aconsegueixi ingressos per referir clients";
$_LANG['affiliatesignupintro'] = "Activi seu compte d'afiliat i comenci a guanyar diners avui ...";
$_LANG['affiliatesignupinfo1'] = "Paguem comissions per cada registre que ve a través del seu enllaç personalitzat.";
$_LANG['affiliatesignupinfo2'] = "Fem un seguiment dels visitants que es refereixen a nosaltres a través de les cookies, perquè rebi la seva comissió encara que l'usuari no contracti el seu producte a l'instant. Les cookies duren fins a 90 dies després de la visita inicial. ";
$_LANG['affiliatesignupinfo3'] = "Per a més informació, posis en contacte amb nosaltres.";

# Version 5.1

$_LANG['copyright'] = "Copyright";
$_LANG['allrightsreserved'] = "Tots els drets reservats";
$_LANG['supportticketsclose'] = "Tancar ticket";
$_LANG['affiliatesinitialthen'] = "Initially then";
$_LANG['invoicesoutstandingbalance'] = "Outstanding Balanç";

$_LANG['cpanellogin'] = "Entrada a cPanel";
$_LANG['cpanelwhmlogin'] = "Entrada a WHM";
$_LANG['cpanelwebmaillogin'] = "Entrada a Webmail";
$_LANG['enkompasslogin'] = "Login to Enkompass";
$_LANG['plesklogin'] = "Entrada a Plesk Control Panel";
$_LANG['helmlogin'] = "Login to Helm Control Panel";
$_LANG['hypervmrestart'] = "Reiniciar VPS server";
$_LANG['siteworxlogin'] = "Entrada a SiteWorx Control Panel";
$_LANG['nodeworxlogin'] = "Entrada a NodeWorx Control Panel";
$_LANG['veportallogin'] = "Entrada a vePortal";
$_LANG['virtualminlogin'] = "Entrada a Control Panel";
$_LANG['websitepanellogin'] = "Entrada a Control Panel";
$_LANG['whmsoniclogin'] = "Entrada a Control Panel";
$_LANG['xpanelmaillogin'] = "Entrada a Webmail";
$_LANG['xpanellogin'] = "Entrada a XPanel";
$_LANG['heartinternetlogin'] = "Entrada a Control Panel";
$_LANG['gamecplogin'] = "Entrada a GameCP";
$_LANG['fluidvmrestart'] = "Reiniciar VPS server";
$_LANG['enomtrustedesc'] = "The TrustE Control Panel contains the set up wizard to get your Privacy Policy up and running.";
$_LANG['enomtrustelogin'] = "Entrada a TrustE Control Panel";
$_LANG['directadminlogin'] = "Entrada a DirectAdmin";
$_LANG['centovacastlogin'] = "Entrada a Centova Cast";
$_LANG['castcontrollogin'] = "Entrada a Control Panel";

$_LANG['sslconfigurenow'] = "Configurar Ara";
$_LANG['sslprovisioningdate'] = "SSL Provisioning Date";
$_LANG['globalsignvoucherscode'] = "Your OneclickSSL Voucher Code";
$_LANG['globalsignvouchersnotissued'] = "Not Yet Issued";

$_LANG['domaintrffailreasonunavailable'] = "Failure Reason unavailable";

$_LANG['clientareaprojects'] = "Els meus Projectes";

$_LANG['clientgroupdiscount'] = "client Discount";
$_LANG['billableitemshours'] = "Hores";
$_LANG['billableitemshour'] = "Hora";

$_LANG['invoicefilename'] = "Factura-";
$_LANG['quotefilename'] = "Cotització-";

# Licensing Addon

$_LANG['licensingkey'] = "license Key";
$_LANG['licensingvaliddomains'] = "Valid domains";
$_LANG['licensingvalidips'] = "Valid IP";
$_LANG['licensingvaliddirectory'] = "Valid Directory";
$_LANG['licensingstatus'] = "license Status";
$_LANG['licensingreissue'] = "Reissue license";
$_LANG['licensingreissued'] = "The Valid domain, IP and Directory will be Detected & saved the next time the license is used.";

# Domain Addons

$_LANG['domainaddons'] = "Complements";
$_LANG['domainaddonsinfo'] = "Els complements següents estan disponibles per al seu (s) domini (s) ...";
$_LANG['domainaddonsdnsmanagement'] = "DNS Host Record Management";
$_LANG['domainaddonsidprotectioninfo'] = "Protegeixi la seva informació personal i redueixi la quantitat d'spam a la safata d'entrada, activant la protecció d'identitat.";
$_LANG['domainaddonsdnsmanagementinfo'] = "External DNS Hosting can help speed up your website and improve availability with reduced redundancy.";
$_LANG['domainaddonsemailforwardinginfo'] = "Get emails forwarded to alternate email addresses of your choice sobre that you can monitor all from a single account.";
$_LANG['domainaddonsbuynow'] = "Buy Now for";
$_LANG['domainaddonsperyear'] = "/ Any";
$_LANG['domainaddonscancelareyousure'] = "Are you sure you want to disable & cancel this domain addon?";
$_LANG['domainaddonsconfirm'] = "Confirmar cancel · lació";
$_LANG['domainaddonscancelsuccess'] = "Addon Deactivated Successfully!";
$_LANG['domainaddonscancelfailed'] = "Failed to deactivate addon. Please contact support.";

# Version 5.2

$_LANG['yourclientareahostingaddons'] = "You have the following addons for this product.";
$_LANG['loginrequired'] = "Login Required";
$_LANG['unsubscribe'] = "Unsubscribe";
$_LANG['emailoptout'] = "Newsletter Opt-out";
$_LANG['newsletterunsubscribe'] = "Newsletter Unsubscribe";
$_LANG['emailoptoutdesc'] = "Tick to unsubscribe from our newsletters";
$_LANG['alreadyunsubscribed'] = "You have already unsubscribed from our newsletter.";
$_LANG['newsletterresubscribe'] = "If you wish to re-subscribe you can do so from the %sMy Details%s section of our client area at any time.";
$_LANG['unsubscribehashinvalid'] = "Unsubscribe failed, please contact support.";
$_LANG['unsubscribesuccess'] = "Unsubscribe Successful";
$_LANG['newsletterremoved'] = "Thank you, Your email has now been removed from our mailing list.";
$_LANG['erroroccured'] = "An Error Occurred";
$_LANG['pwresetsuccessdesc'] = "Your password has now been reset. %sClick here%s to continue to the client area...";
$_LANG['pwresetenternewpw'] = "Please enter your desired new password below.";
$_LANG['ordererrorsbudomainbanned'] = "The subdomain prefix you entered is not allowed - please try another";

$_LANG['ticketfeedbacktitle'] = "Feedback Request for Ticket";

$_LANG['nosupportdepartments'] = "No support departments found. Please try again later.";

$_LANG['feedbackclosed'] = "Feedback cannot be provided until the ticket is closed";
$_LANG['feedbackprovided'] = "You have already provided feedback for this ticket";
$_LANG['feedbackthankyou'] = "We thank you for taking the time to provide your feedback.";
$_LANG['feedbackreceived'] = "Submission Received";
$_LANG['feedbackdesc'] = "Please can we ask you to take a moment of your time to fill out the below form about the quality of your experience with our support team.";
$_LANG['feedbackclickreview'] = "Click here to Review The Ticket";
$_LANG['feedbackopenedat'] = "Opened At";
$_LANG['feedbacklastreplied'] = "Last Replied To";
$_LANG['feedbackstaffinvolved'] = "Staff Involved";
$_LANG['feedbacktotalduration'] = "Total Duration";
$_LANG['feedbackpleaserate1'] = "Please rate (on a scale of 1 to 10) how well";
$_LANG['feedbackpleasecomment1'] = "Please comment on how well";
$_LANG['feedbackhandled'] = "handled this support request";
$_LANG['feedbackworst'] = "Worst";
$_LANG['feedbackbest'] = "Best";
$_LANG['feedbackimprove'] = "How may we make your experience better in the future?";
$_LANG['pleaserate2'] = "handled this support request";
$_LANG['returnclient'] = "Return to Client Area";

$_LANG['clientareanavsecurity'] = "Security Settings";
$_LANG['twofactorauth'] = "Two-Factor Authentication";
$_LANG['twofaenable'] = "Enable Two-Factor Authentication";
$_LANG['twofadisable'] = "Disable Two-Factor Authentication";
$_LANG['twofaenableclickhere'] = "Click here to Enable";
$_LANG['twofadisableclickhere'] = "Click here to Disable";
$_LANG['twofaenforced'] = "The system administrator has enforced that you must enable Two-Factor Authentication before you can continue. This page will guide you through the process of setting it up.";
$_LANG['twofasetup'] = "Two-Factor Authentication Setup Process";
$_LANG['twofasetupgetstarted'] = "Get Started";
$_LANG['twofaactivationintro'] = "Two-Factor Authentication adds an extra layer of protection to logins. Once enabled &amp; configured, each time you sign in you will be asked to enter both your username & password as well as a second factor such as a security code.";
$_LANG['twofaactivationmultichoice'] = "To continue, please choose your desired Two-Factor Authentication method from below.";
$_LANG['twofadisableintro'] = "To disable Two-Factor Authentication please confirm your password in the field below.";
$_LANG['twofaactivationerror'] = "An error occurred while attempting to activate Two-Factor Authentication for your account. Please try again.";
$_LANG['twofamoduleerror'] = "An error occurred loading the module. Please try again.";
$_LANG['twofaactivationcomplete'] = "Two-Factor Authentication Setup is Complete!";
$_LANG['twofadisableconfirmation'] = "Two-Factor Authentication has now been disabled for your account.";
$_LANG['twofabackupcodeis'] = "Your Backup Code is";
$_LANG['twofanewbackupcodeis'] = "Your New Backup Code is";
$_LANG['twofabackupcodelogin'] = "Enter Your Backup Code Above to Login";
$_LANG['twofabackupcodeexpl'] = "Write this down on paper and keep it safe.<br />It will be needed if you ever lose your 2nd factor device or it is unavailable to you.";
$_LANG['twofaconfirmpw'] = "Enter Your Password";
$_LANG['twofa2ndfactorreq'] = "Your second factor is required to complete login.";
$_LANG['twofa2ndfactorincorrect'] = "The second factor you supplied was incorrect. Please try again.";
$_LANG['twofabackupcodereset'] = "Login via Backup Code Successful. Backup Codes are valid once only. It will now be reset.";
$_LANG['twofacantaccess2ndfactor'] = "Can't Access Your 2nd Factor Device?";
$_LANG['twofaloginusingbackupcode'] = "Login using Backup Code";
$_LANG['twofageneralerror'] = "An error occurred loading the module. Please try again.";

$_LANG['continue'] = "Continue";
$_LANG['disable'] = "Disable";
$_LANG['manage'] = "Manage";
