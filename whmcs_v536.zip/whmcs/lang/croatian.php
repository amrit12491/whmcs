<?php
/**
 * WHMCS Language File
 * Croatian (hr)
 *
 * Please Note: These language files are overwritten during software updates
 * and therefore editing of these files directly is not advised. Instead we
 * recommend that you use overrides to customise the text displayed in a way
 * which will be safely preserved through the upgrade process.
 *
 * For instructions on overrides, please visit:
 *   http://docs.whmcs.com/Language_Overrides
 *
 * @package    WHMCS
 * @author     WHMCS Limited <development@whmcs.com>
 * @copyright  Copyright (c) WHMCS Limited 2005-2013
 * @license    http://www.whmcs.com/license/ WHMCS Eula
 * @version    $Id$
 * @link       http://www.whmcs.com/
 */

if (!defined("WHMCS")) die("This file cannot be accessed directly");

$_LANG['isocode'] = "hr";

$_LANG['accountinfo'] = "Informacije o računu";
$_LANG['accountstats'] = "Statistika";
$_LANG['addfunds'] = "Dodaj na račun";
$_LANG['addfundsamount'] = "Iznos";
$_LANG['addfundsmaximum'] = "Maksimalni depozit";
$_LANG['addfundsmaximumbalance'] = "Maksimalna bilanca";
$_LANG['addfundsmaximumbalanceerror'] = "Maksimalni iznos bilance je";
$_LANG['addfundsmaximumerror'] = "Maksimalni iznos depozita je";
$_LANG['addfundsminimum'] = "Minimalni depozit";
$_LANG['addfundsminimumerror'] = "Minimalni iznos depozita je";
$_LANG['addmore'] = "Dodaj još";
$_LANG['addtocart'] = "Dodaj u košaricu";
$_LANG['affiliatesactivate'] = "Aktiviraj affiliate račun";
$_LANG['affiliatesamount'] = "Iznos";
$_LANG['affiliatesbalance'] = "Trenutna bilanca";
$_LANG['affiliatesbullet1'] = "Primite početni bonus na svoj affiliate račun";
$_LANG['affiliatesbullet2'] = "od svake uplate korisnika kojeg ste uputili na naše usluge tijekom trajanja njegove hosting usluge";
$_LANG['affiliatescommission'] = "Provizija";
$_LANG['affiliatesdescription'] = "Pristupite našem affiliate programu ili pregledajte prihod";
$_LANG['affiliatesdisabled'] = "Trenutno ne nudimo affiliate sustav klijentima.";
$_LANG['affiliatesearn'] = "Zarada";
$_LANG['affiliatesearningstodate'] = "Sveukupna zarada do datuma";
$_LANG['affiliatesfootertext'] = "Kada uputite nekoga na naše stranice sa svojim jedinstvenim ID, na njegovom računalu postavi se cookie koji sadrži Vaš ID. Ukoliko osoba koju ste uputili zabilježi i ponovno posjeti naše stranice, Vi dobivate proviziju.";
$_LANG['affiliateshostingpackage'] = "Hosting paket";
$_LANG['affiliatesintrotext'] = "Aktivirajte svoj affiliate račun danas za:";
$_LANG['affiliateslinktous'] = "Naša adresa";
$_LANG['affiliatesnosignups'] = "Trenutno niste primili niti jednu prijavu.";
$_LANG['affiliatesrealtime'] = "Statistike se prikazuju u realnom vemenu i stalno se ažuriraju";
$_LANG['affiliatesreferallink'] = "Vaša jedinstvena adresa za preporuke";
$_LANG['affiliatesreferals'] = "Preporuke";
$_LANG['affiliatesregdate'] = "Datum registracije";
$_LANG['affiliatesrequestwithdrawal'] = "Zahtjev za isplatu";
$_LANG['affiliatessignupdate'] = "Datum pristupa";
$_LANG['affiliatesstatus'] = "Status";
$_LANG['affiliatestitle'] = "Affiliates";
$_LANG['affiliatesvisitorsreferred'] = "Broj referiranih posjetitelja";
$_LANG['affiliateswithdrawalrequestsuccessful'] = "Vaš zahtjev za isplatu je podnesen. Uskoro ćete biti kontaktirani.";
$_LANG['affiliateswithdrawn'] = "Ukupan iznos isplate";
$_LANG['all'] = "Svi";
$_LANG['alreadyregistered'] = "Već ste registrirani?";
$_LANG['announcementsdescription'] = "Pogledajte naše najnovije vijesti i obavijesti";
$_LANG['announcementsnone'] = "Nema obavijesti za prikaz";
$_LANG['announcementsrss'] = "Pregled RSS obavijesti";
$_LANG['announcementstitle'] = "Obavijesti";
$_LANG['bannedbanexpires'] = "Kazna ističe";
$_LANG['bannedbanreason'] = "Razlog kazne";
$_LANG['bannedhasbeenbanned'] = "je pod kaznom";
$_LANG['bannedtitle'] = "IP je pod zabranom";
$_LANG['bannedyourip'] = "Vaš IP";
$_LANG['cartaddons'] = "Dodaci";
$_LANG['cartbrowse'] = "Pregled proizvoda &amp; usluga";
$_LANG['cartconfigdomainextras'] = "Podesi dodatke domene";
$_LANG['cartconfigoptionsdesc'] = "Ovaj proizvod/usluga nudi opcije koje možete dolje odabrati kako biste si prilagodili narudžbu.";
$_LANG['cartconfigserver'] = "Podesi poslužitelja";
$_LANG['cartcustomfieldsdesc'] = "Ovaj proizvod/usluga zahtijeva dodatne informacije od Vas kako bismo bili u mogućnosti obraditi narudžbu.";
$_LANG['cartdomainsconfig'] = "Podešavanje domena";
$_LANG['cartdomainsconfigdesc'] = "Niže možete podesiti nazive domena u košarici odabirom dodatnih usluga, pružanjem potrebnih informacija i određivanjem domenskih poslužitelja.";
$_LANG['cartdomainshashosting'] = "Has hosting";
$_LANG['cartdomainsnohosting'] = "Nema hostinga! Odaberite opciju za dodavanje stavki";
$_LANG['carteditproductconfig'] = "Uredi postavke";
$_LANG['cartempty'] = "Vaša košarica je prazna";
$_LANG['cartemptyconfirm'] = "Sigurni ste da želite isprazniti košaricu?";
$_LANG['cartexistingclientlogin'] = "Prijava postojećeg korisnika";
$_LANG['cartexistingclientlogindesc'] = "Za dodavanje narudžbe postojećem korisničkom računu, potrebna je prijava.";
$_LANG['cartnameserversdesc'] = "Ukoliko želite koristiti posebne domenske poslužitelje, unesite ih ispod. Prema zadanim postavkama, nove domene koriste naše domenske poslužitelje za hosting na našoj mreži.";
$_LANG['cartproductaddons'] = "Dodaci proizvoda";
$_LANG['cartproductaddonschoosepackage'] = "Odaberite paket";
$_LANG['cartproductaddonsnone'] = "Za Vaš proizvode &amp; usluge nema dostupnih dodataka";
$_LANG['cartproductconfig'] = "Postavke proizvoda";
$_LANG['cartproductdesc'] = "Odabrani proizvod/usluga nudi sljedeće opcije postavki.";
$_LANG['cartproductdomain'] = "Domene";
$_LANG['cartproductdomainchoose'] = "Odaberite domenu";
$_LANG['cartproductdomaindesc'] = "Odabrani proizvod/usluga zahtjeva naziv domene. Molimo, odaberite iz dolje ponuđenih naziva.";
$_LANG['cartproductdomainuseincart'] = "Koristite domenu koja je već u mojoj košarici";
$_LANG['cartremove'] = "Ukloni";
$_LANG['cartremoveitemconfirm'] = "Jeste li sigurni da želite ukloniti odabranu stavku iz košarice?";
$_LANG['carttaxupdateselections'] = "Porez može biti obračunan prema državi koju ste odabrali. Kliknite za rekalkulaciju nakon odabira.";
$_LANG['carttaxupdateselectionsupdate'] = "Ažuriraj";
$_LANG['carttitle'] = "Košarica";
$_LANG['changessavedsuccessfully'] = "Promjene su pohranjene!";
$_LANG['checkavailability'] = "Provjeri raspoloživost";
$_LANG['checkout'] = "Blagajna";
$_LANG['choosecurrency'] = "Odaberite valutu";
$_LANG['choosedomains'] = "Odaberite domene";
$_LANG['clickheretologin'] = "Kliknite ovdje za prijavu";
$_LANG['clientareaaccountaddons'] = "Dodaci računa";
$_LANG['clientareaactive'] = "Aktivna";
$_LANG['clientareaaddfundsdisabled'] = "We do not allow depositing funds in advance with us at the current time.";
$_LANG['clientareaaddfundsnotallowed'] = "Morate imati barem jednu aktivnu narudžbu prije dodavanja sredstava stoga trenutno nastavak nije moguć!";
$_LANG['clientareaaddon'] = "Dodatak";
$_LANG['clientareaaddonorderconfirmation'] = "Zahvaljujemo. Vaša narudžba za dolje prikazani dodatak je zaprimljena. Molimo, odaberite metodu plaćanja.";
$_LANG['clientareaaddonpricing'] = "Izračun cijena";
$_LANG['clientareaaddonsfor'] = "Dodaci za";
$_LANG['clientareaaddress1'] = "Adresa 1";
$_LANG['clientareaaddress2'] = "Adresa 2";
$_LANG['clientareabwlimit'] = "Ograničenje prometa";
$_LANG['clientareabwusage'] = "Iskorištenost prometa";
$_LANG['clientareacancel'] = "Poništi promjene";
$_LANG['clientareacancelconfirmation'] = "Zahvaljujemo. Vaš zahtjev za poništenjem je poslan. Ukoliko ste zahtjev greškom poslali, otvorite upit za podršku ili nas obavijestite drugim putem u što skorijem roku kako Vaš rečun ne bi bio ukinut.";
$_LANG['clientareacancelinvalid'] = "Zahtjev za poništenjem s ovog korisničkog računa već je zaprimljen, stoga ne možete poslati drugi.";
$_LANG['clientareacancellationendofbillingperiod'] = "Kraj obračunskog perioda";
$_LANG['clientareacancellationimmediate'] = "Odmah";
$_LANG['clientareacancellationtype'] = "Vrsta poništenja";
$_LANG['clientareacancelled'] = "Poništen";
$_LANG['clientareacancelproduct'] = "Zatraženo poništenje za";
$_LANG['clientareacancelreason'] = "Ukratko obrazložite zahtjev za poništenjem";
$_LANG['clientareacancelrequest'] = "Zahtjev za poništenje korisničkog računa";
$_LANG['clientareacancelrequestbutton'] = "Zatraži poništenje";
$_LANG['clientareachangepassword'] = "Promijeni lozinku";
$_LANG['clientareachangesuccessful'] = "Vaši podaci su promijenjeni";
$_LANG['clientareachoosecontact'] = "Odaberite kontakt";
$_LANG['clientareacity'] = "Grad";
$_LANG['clientareacompanyname'] = "Naziv tvrtke";
$_LANG['clientareaconfirmpassword'] = "Potvrdi lozinku";
$_LANG['clientareacontactsemails'] = "Postavke e-mail pošte";
$_LANG['clientareacontactsemailsdomain'] = "E-mail pošta domene - Obavijesti o obnovi, Potvrde registracije, itd...";
$_LANG['clientareacontactsemailsgeneral'] = "Opća E-mail pošta - Opće najave &amp; Podsjetnici za loziku";
$_LANG['clientareacontactsemailsinvoice'] = "E-mail pošta potraživanja - Računi &amp; Podsjetnici za uplatu";
$_LANG['clientareacontactsemailsproduct'] = "E-mail pošta proizvoda - Detalji narudžbi, Pozdravne poruke, itd...";
$_LANG['clientareacontactsemailssupport'] = "E-mail pošta podrške - Dopušta tom korisniku otvaranje upita u Vašem korisničkom računu";
$_LANG['clientareacountry'] = "Država";
$_LANG['clientareacurrentsecurityanswer'] = "Molimo, upišite svoj sadašnji odgovor";
$_LANG['clientareacurrentsecurityquestion'] = "Molimo, odaberite svoje sadašnje sigurnosno pitanje";
$_LANG['clientareadeletecontact'] = "Izbriši kontakt";
$_LANG['clientareadeletecontactareyousure'] = "Jeste li sigurni da želite izbrisati odabrani kontakt?";
$_LANG['clientareadescription'] = "Pregled i ažuriranje podataka vašeg računa";
$_LANG['clientareadisklimit'] = "Ograničenje prostora na disku";
$_LANG['clientareadiskusage'] = "Upotrebljenost prostora na disku";
$_LANG['clientareadomainexpirydate'] = "Datum isteka";
$_LANG['clientareadomainnone'] = "Nema kod nas registriranih domena";
$_LANG['clientareaemail'] = "E-mail adresa";
$_LANG['clientareaemails'] = "Moja E-mail pošta";
$_LANG['clientareaemailsdate'] = "Datum slanja";
$_LANG['clientareaemailsintrotext'] = "Niže je arhiva svih poruka koje smo Vam poslali. Ukoliko izgubite koju poruku e-mail pošte na ovaj način možete korespodenciju vezanu uz svoj korisnički račun.";
$_LANG['clientareaemailssubject'] = "Predmet poruke";
$_LANG['clientareaerroraddress1'] = "Niste unijeli svoju adresu (linija 1)";
$_LANG['clientareaerroraddress12'] = "Adresa može sadržavati samo slova, brojeve i razmake";
$_LANG['clientareaerrorbannedemail'] = "Ne dopuštamo korisnike s e-mail adresama navedenog pružatelja usluga. Molimo, unesite drugu adresu eletroničke pošte.";
$_LANG['clientareaerrorcity'] = "Niste unijeli grad";
$_LANG['clientareaerrorcity2'] = "Grad može sadržavati samo slova i razmake";
$_LANG['clientareaerrorcountry'] = "Molimo, odaberite državu u padajućem izborniku";
$_LANG['clientareaerroremail'] = "Niste unijeli e-mail adresu";
$_LANG['clientareaerroremailinvalid'] = "E-mail adresa koju ste unijeli nije valjana";
$_LANG['clientareaerrorfirstname'] = "Niste unijeli svoje ime";
$_LANG['clientareaerrorfirstname2'] = "Vaše ime može sadržavati samo slova";
$_LANG['clientareaerrorisrequired'] = "je potrebno";
$_LANG['clientareaerrorlastname'] = "Niste unijeli svoje prezime";
$_LANG['clientareaerrorlastname2'] = "Vaše prezime može sadržavati samo slova";
$_LANG['clientareaerroroccured'] = "Došlo je do greške. Molimo, pokušajte ponovno kasnije.";
$_LANG['clientareaerrorpasswordconfirm'] = "Niste potvrdili svoju lozinku";
$_LANG['clientareaerrorpasswordnotmatch'] = "Unesene lozinke se ne podudaraju";
$_LANG['clientareaerrorphonenumber'] = "Niste unijeli telefonski broj";
$_LANG['clientareaerrorphonenumber2'] = "Uneseni telefonski broj nije valjan";
$_LANG['clientareaerrorpostcode'] = "Niste unijeli poštanski broj";
$_LANG['clientareaerrorpostcode2'] = "Poštanski broj može sadržavati samo slova, brojeve i razmake";
$_LANG['clientareaerrors'] = "Došlo je do sljedećih pogrešaka:";
$_LANG['clientareaerrorstate'] = "Niste unijeli svoju zemlju";
$_LANG['clientareaexpired'] = "Isteklo";
$_LANG['clientareafirstname'] = "Ime";
$_LANG['clientareafraud'] = "Prijevara";
$_LANG['clientareafullname'] = "Ime korisnika";
$_LANG['clientareaheader'] = "Dobrodošli na korisničke stranice! Ovdje možete upravljati svojim korisničkim računom. Ova stranica pruža Vam kratki uvid u račun uključujući otvorene zahtjeve za podrškom i neplaćene račune. Molimo da svoje kontakt podatke redovno ažurirate.";
$_LANG['clientareahostingaddons'] = "Dodaci";
$_LANG['clientareahostingaddonsintro'] = "You have the following addons for this product.";
$_LANG['clientareahostingaddonsview'] = "Pregled";
$_LANG['clientareahostingamount'] = "Iznos";
$_LANG['clientareahostingdomain'] = "Domena";
$_LANG['clientareahostingnextduedate'] = "Datum sljedeće uplate";
$_LANG['clientareahostingpackage'] = "Paket";
$_LANG['clientareahostingregdate'] = "Datum registracije";
$_LANG['clientarealastname'] = "Prezime";
$_LANG['clientarealastupdated'] = "Ažurirano";
$_LANG['clientarealeaveblank'] = "Ostavite polje praznim ukoliko ne želite promijeniti lozinku.";
$_LANG['clientareamodifydomaincontactinfo'] = "Promijeni kontakt podatke domene";
$_LANG['clientareamodifynameservers'] = "Promijeni domenske poslužitelje";
$_LANG['clientareamodifywhoisinfo'] = "Promijeni WHOIS kontakt podatke";
$_LANG['clientareanameserver'] = "Domenski poslužitelji";
$_LANG['clientareanavaddcontact'] = "Dodaj novi kontakt";
$_LANG['clientareanavchangecc'] = "Promijeni podatke kreditne kartice";
$_LANG['clientareanavchangepw'] = "Promijeni lozinku";
$_LANG['clientareanavdetails'] = "Moji detalji";
$_LANG['clientareanavdomains'] = "Moje domene";
$_LANG['clientareanavhome'] = "Početna";
$_LANG['clientareanavlogout'] = "Odjava";
$_LANG['clientareanavorder'] = "Naruči dodatne stavke";
$_LANG['clientareanavsecurityquestions'] = "Promijeni sigurnosno pitanje";
$_LANG['clientareanavservices'] = "Moje usluge";
$_LANG['clientareanavsupporttickets'] = "Moji zahtjevi za podršku";
$_LANG['clientareanocontacts'] = "Nema pronađenih kontakata";
$_LANG['clientareapassword'] = "Lozinka";
$_LANG['clientareapending'] = "U tijeku";
$_LANG['clientareapendingtransfer'] = "Prijenos na čekanju";
$_LANG['clientareaphonenumber'] = "Telefonski broj";
$_LANG['clientareapostcode'] = "Poštanski broj";
$_LANG['clientareaproductdetails'] = "Detalji proizvoda";
$_LANG['clientareaproducts'] = "Moji proizvodi &amp; usluge";
$_LANG['clientareaproductsnone'] = "Nema naručenih proizvoda/usluga";
$_LANG['clientarearegistrationperiod'] = "Razdoblje registracije";
$_LANG['clientareasavechanges'] = "Spremi promjene";
$_LANG['clientareasecurityanswer'] = "Molimo, unesite odgovor";
$_LANG['clientareasecurityconfanswer'] = "Molimo, potvrdite odgovor";
$_LANG['clientareasecurityquestion'] = "Molimo, odaberite sigurnosno pitanje";
$_LANG['clientareaselectcountry'] = "Odaberite državu";
$_LANG['clientareasetlocking'] = "Podesi zaključavanje";
$_LANG['clientareastate'] = "Država/Regija";
$_LANG['clientareastatus'] = "Status";
$_LANG['clientareasuspended'] = "Suspendirana";
$_LANG['clientareaterminated'] = "Ukinuta";
$_LANG['clientareaticktoenable'] = "Označi za omogućavanje opcije";
$_LANG['clientareatitle'] = "Korisnički dio";
$_LANG['clientareaunlimited'] = "Neograničen";
$_LANG['clientareaupdatebutton'] = "Ažuriraj";
$_LANG['clientareaupdateyourdetails'] = "Ažurirajte svoje podatke";
$_LANG['clientareaused'] = "Korišten";
$_LANG['clientareaviewaddons'] = "Pregled dostupnih dodataka";
$_LANG['clientareaviewdetails'] = "Pregled detalja";
$_LANG['clientlogin'] = "Prijava korisnika";
$_LANG['clientregisterheadertext'] = "Molimo, ispunite polja za registraciju novog korisničkog računa.";
$_LANG['clientregistertitle'] = "Registriraj se";
$_LANG['clientregisterverify'] = "Potvrdi registraciju";
$_LANG['clientregisterverifydescription'] = "Molimo, unesite prikazani tekst u zadano polje.";
$_LANG['clientregisterverifyinvalid'] = "Unesen je netočan verifikacijski kod";
$_LANG['closewindow'] = "Zatvori prozor";
$_LANG['completeorder'] = "Završi narudžbu";
$_LANG['confirmnewpassword'] = "Potvrdi novu lozinku";
$_LANG['contactemail'] = "E-mail";
$_LANG['contacterrormessage'] = "Poruka nije unesena";
$_LANG['contacterrorname'] = "Niste unijeli svoje ime";
$_LANG['contacterrorsubject'] = "Predmet poruke nije naveden";
$_LANG['contactheader'] = "Ukoliko imate kakva pitanja prije naručivanja ili nas želite kontaktirati, molimo, poslužite se donjom formom.";
$_LANG['contactmessage'] = "Poruka";
$_LANG['contactname'] = "Ime";
$_LANG['contactsend'] = "Pošalji poruku";
$_LANG['contactsent'] = "Vaša poruka je poslana";
$_LANG['contactsubject'] = "Predmet";
$_LANG['contacttitle'] = "Kontaktirajte nas prije narudžbe";
$_LANG['continueshopping'] = "Nastavi kupovinu";
$_LANG['creditcard'] = "Plaćanje kreditnom karticom";
$_LANG['creditcard3dsecure'] = "U sklopu naših mjera za spriječavanje prevara, bit ćete zamoljeni za verifikaciju Visa ili MasterCard sigurnosnog koda kako biste završili uplatu.<br /><br />Ne pritišćite tipku za osvježavanje stranice ili povratak jer će transakcija biti prekinuta ili poništena.";
$_LANG['creditcardcardexpires'] = "Datum isteka";
$_LANG['creditcardcardissuenum'] = "Datum izdavanja";
$_LANG['creditcardcardnumber'] = "Broj kartice";
$_LANG['creditcardcardstart'] = "Datum početka";
$_LANG['creditcardcardtype'] = "Vrsta kartice";
$_LANG['creditcardccvinvalid'] = "Potreban je CVV broj kartice";
$_LANG['creditcardconfirmation'] = "Zahvaljujemo! Vaši novi podaci kreditne kartice i prva uplata su zaprimljeni. Primit ćete potvrdu na e-mail adresu.";
$_LANG['creditcardcvvnumber'] = "CVV/CVC2 broj";
$_LANG['creditcardcvvwhere'] = "Gdje mogu naći ovo?";
$_LANG['creditcarddeclined'] = "Uneseni podaci kreditne kartice su odbijeni. Molimo, pokušajte s drugom karticom ili kontaktirajte podršku.";
$_LANG['creditcarddetails'] = "Podaci kreditne kartice";
$_LANG['creditcardenterexpirydate'] = "Niste unijeli datum isteka kreditne kartice";
$_LANG['creditcardenternewcard'] = "Unesite nove podatke kreditne kartice";
$_LANG['creditcardenternumber'] = "Broj kreditne kartice nije unešen";
$_LANG['creditcardinvalid'] = "Uneseni podaci kreditne kartice nisu valjani. Molimo, pokušajte s drugom karticom ili kontaktirajte podršku.";
$_LANG['creditcardnumberinvalid'] = "Uneseni broj kartice nije valjan";
$_LANG['creditcardsecuritynotice'] = "Svi uneseni podaci su zaštićeni i kodirani kako bi se smanjio rizik od prijevare.";
$_LANG['creditcarduseexisting'] = "Koristi postojeću karticu";
$_LANG['customfieldvalidationerror'] = "vrijednost nije ispravna";
$_LANG['days'] = "Dani";
$_LANG['defaultbillingcontact'] = "Zadani podaci za naplatu";
$_LANG['domainalternatives'] = "Pokušajte sljedeće alternative:";
$_LANG['domainavailable'] = "Slobodna! Naruči odmah";
$_LANG['domainavailable1'] = "Čestitamo!";
$_LANG['domainavailable2'] = "je slobodna!";
$_LANG['domainavailableexplanation'] = "Za registraciju odabrane domene slijedite dolje navedenu adresu";
$_LANG['domainbulksearch'] = "Bulk tražilica domena";
$_LANG['domainbulksearchintro'] = "Bulk tražilicom domena moguće je pretraživati do 20 domena odjednom. Unesite domene u zadana polja (jedna domena po polju) bez www. ili htpp:// ispred naziva.";
$_LANG['domainbulktransferdescription'] = "Već danas možete svoje postojeće domene prebaciti kod nas. Za početak, jednostavno unesite nazive domena ispod, bez www. ili htpp:// ispred naziva.";
$_LANG['domainbulktransfersearch'] = "Prijenos bulk domena";
$_LANG['domaincheckerdescription'] = "Provjeri dostupnost domene";
$_LANG['domaincontactinfo'] = "Kontakt podaci";
$_LANG['domaincurrentrenewaldate'] = "Trenutni datum obnove";
$_LANG['domaindnsaddress'] = "Adresa";
$_LANG['domaindnshostname'] = "Naziv poslužitelja";
$_LANG['domaindnsmanagement'] = "DNS administracija";
$_LANG['domaindnsmanagementdesc'] = "Usmjerite svoju domenu na internetsku stranicu ukazujući na IP adresu, proslijedite na drugu stranicu ili ukažite na privremenu stranicu (poznato kao parking) i više. Ovi zapisi poznati su i kao poddomene.";
$_LANG['domaindnsrecordtype'] = "Vrsta zapisa";
$_LANG['domainemailforwarding'] = "Prosljeđivanje elektronske pošte";
$_LANG['domainemailforwardingdesc'] = "Ako poslužitelj koji proslijeđuje elektroničku poštu odredi odredišnu adresu nevaljalom, automatski će se onemogućiti slanje zapisa. Molimo, provjerite odredišnu adresu prije uključivanja opcije. Promjene na postojećim zapisima mogu nastupiti tek nakon sat vremena.";
$_LANG['domainemailforwardingforwardto'] = "Proslijedi za";
$_LANG['domainemailforwardingprefix'] = "Prefiks";
$_LANG['domaineppcode'] = "EPP kod";
$_LANG['domaineppcodedesc'] = "Ovo treba biti dobiveno od trenutnog registrara za autorizaciju";
$_LANG['domaineppcoderequired'] = "Morate unijeti EPP kod za";
$_LANG['domainerror'] = "Došlo je do greške u Vašem zahtjevu";
$_LANG['domainerrornodomain'] = "Molimo, unesite ispravni naziv domene";
$_LANG['domainerrortoolong'] = "Domena koju ste unijeli je preduga. Domene mogu biti do 67 znakova dužine.";
$_LANG['domaingeteppcode'] = "Saznajte EPP kod";
$_LANG['domaingeteppcodeemailconfirmation'] = "Vaš zahtjev za EPP kodom je poslan registraru.";
$_LANG['domaingeteppcodeexplanation'] = "EPP kod je u osnovi lozinka za naziv domene. On je sigurnosna mjera koja osigurava da samo vlasnik domene može prebacivati istu različitim registrarima.";
$_LANG['domaingeteppcodefailure'] = "Došlo je do greške pri zahtjevu za EPP kod:";
$_LANG['domaingeteppcodeis'] = "EPP kod za Vašu domenu je:";
$_LANG['domainidprotection'] = "ID zaštita";
$_LANG['domainintrotext'] = "Zbog prilagodbe sustava novom način registracija .hr, .com.hr i .from.hr domena, trenutno nije moguće provjeriti dostupnost navedenih domena direktno sa naše stranice, pa vam molimo da to učinite na adresi http://www.carnet.hr/dns. Zahvaljujemo na razumijevanju. Unesite domenu koju želite koristiti u polja ispod i odaberite opciju Pretraži kako biste vidjeli je li domena slobodna. ";
$_LANG['domainlookupbutton'] = "Pretraži";
$_LANG['domainmanagementtools'] = "Alati za upravljanje";
$_LANG['domainminyears'] = "Min. godina";
$_LANG['domainmoreinfo'] = "Više informacija";
$_LANG['domainname'] = "Naziv domene";
$_LANG['domainnameserver1'] = "Domenski poslužitelj 1";
$_LANG['domainnameserver2'] = "Domenski poslužitelj 2";
$_LANG['domainnameserver3'] = "Domenski poslužitelj 3";
$_LANG['domainnameserver4'] = "Domenski poslužitelj 4";
$_LANG['domainnameserver5'] = "Nameserver 5";
$_LANG['domainnameservers'] = "Domenski poslužitelji";
$_LANG['domainordernow'] = "Naruči!";
$_LANG['domainorderrenew'] = "Obnova narudžbe";
$_LANG['domainprice'] = "Cijena";
$_LANG['domainregisterns'] = "Registrirani domenski poslužitelji";
$_LANG['domainregisternscurrentip'] = "Trenutna IP adresa";
$_LANG['domainregisternsdel'] = "Izbrišite domenskog poslužitelja";
$_LANG['domainregisternsdelsuccess'] = "Domenski poslužitelj je izbrisan";
$_LANG['domainregisternsexplanation'] = "Odavde možete kreirati i upravljati domenskim poslužiteljima svojih domena (npr. NS1.vasadomena.com, NS2.vasadomena.com...).";
$_LANG['domainregisternsip'] = "IP adresa";
$_LANG['domainregisternsmod'] = "Promijeni IP domenkog poslužitelja";
$_LANG['domainregisternsmodsuccess'] = "Domenski poslužitelj je izmjenjen";
$_LANG['domainregisternsnewip'] = "Nova IP adresa";
$_LANG['domainregisternsns'] = "Domenski poslužitelj";
$_LANG['domainregisternsreg'] = "Registrirajte naziv domenskog poslužitelja";
$_LANG['domainregisternsregsuccess'] = "Domenski poslužitelj je registriran";
$_LANG['domainregistrantchoose'] = "Odaberite kontakt koji želite koristiti";
$_LANG['domainregistrantinfo'] = "Podaci registranta domene";
$_LANG['domainregistrarlock'] = "Registrarova zaštita";
$_LANG['domainregistrarlockdesc'] = "Omogući registrarovi zaštitu (preporučeno. Neautorizirani premještaj će biti spriječen ako je opcija uključena.";
$_LANG['domainregistration'] = "Registracija domene";
$_LANG['domainregistryinfo'] = "Podaci registracije domene";
$_LANG['domainregnotavailable'] = "N/A";
$_LANG['domainrenew'] = "Obnovi domenu";
$_LANG['domainrenewal'] = "Obnova domene";
$_LANG['domainrenewalprice'] = "Obnova";
$_LANG['domainrenewdesc'] = "Osigurajte svoju domenu tako da je obnovite na nekoliko godina. Odredite broj godina za koji je želite obnoviti.";
$_LANG['domainsautorenew'] = "Automatska obnova";
$_LANG['domainsautorenewdisable'] = "Onemogući automatsku obnovu";
$_LANG['domainsautorenewdisabled'] = "Onemogućeno";
$_LANG['domainsautorenewdisabledwarning'] = "PAŽNJA! Ova domena ima onemogućenu automatsku obnovu.<br /> Nakon isteka, postat će neaktivna ukoliko se ručno ne obnovi.";
$_LANG['domainsautorenewenable'] = "Omogući automatsku obnovu";
$_LANG['domainsautorenewenabled'] = "Omogućeno";
$_LANG['domainsautorenewstatus'] = "Trenutni status";
$_LANG['domainsimplesearch'] = "Jednostavna pretraga domena";
$_LANG['domainspricing'] = "Cjenik domena";
$_LANG['domainsregister'] = "Registriraj";
$_LANG['domainsrenew'] = "Obnavljanje";
$_LANG['domainsrenewnow'] = "Renew Now";
$_LANG['domainstatus'] = "Status";
$_LANG['domainstransfer'] = "Prijenos";
$_LANG['domaintitle'] = "Pretraživač domena";
$_LANG['domaintld'] = "TLD";
$_LANG['domaintransfer'] = "Prijenos domene";
$_LANG['domainunavailable'] = "Neraspoloživa";
$_LANG['domainunavailable1'] = "Žao nam je!";
$_LANG['domainunavailable2'] = "je već zauzeta!";
$_LANG['domainviewwhois'] = "pregled whois izvještaja";
$_LANG['downloaddescription'] = "Opis";
$_LANG['downloadloginrequired'] = "Pristup nije dopušten - Morate biti prijavljeni za preuzimanje ove datoteke";
$_LANG['downloadname'] = "Preuzimanje";
$_LANG['downloadpurchaserequired'] = "Pristup nije dopušten - Morate kupiti vezani proizvod prije preuzimanja ove datoteke";
$_LANG['downloadscategories'] = "Kategorije";
$_LANG['downloadsdescription'] = "Pregled datoteka za preuzimanje";
$_LANG['downloadsfiles'] = "Datoteke";
$_LANG['downloadsfilesize'] = "Veličina datoteke";
$_LANG['downloadsintrotext'] = "Zbirka datoteka za preuzimanje sadrži sva uputstva, programe i druge datoteke koje Vam mogu zatrebati da pokrenete internetsku stranicu.";
$_LANG['downloadspopular'] = "Najpopularnije datoteke";
$_LANG['downloadsnone'] = "Nema datoteka za prikazati";
$_LANG['downloadstitle'] = "Preuzimanja";
$_LANG['email'] = "E-mail";
$_LANG['emptycart'] = "Isprazni košaricu";
$_LANG['existingpassword'] = "Postojeća lozinka";
$_LANG['existingpasswordincorrect'] = "Vaša postojeća lozinka nije točna";
$_LANG['firstpaymentamount'] = "Iznos prve uplate";
$_LANG['flashtutorials'] = "Flash instrukcije";
$_LANG['flashtutorialsdescription'] = "Kliknite za pregled instrukcija kako koristiti hosting korisničko sučelje";
$_LANG['flashtutorialsheadertext'] = "Flash instrukcije pomoći će Vam da u potpunosti i iskoristite mogućnosti korisničkog sučelja. Odaberite zadatak koji će Vam biti objašnjen korak po korak u instrukcijama.";
$_LANG['forwardingtogateway'] = "Molimo, pričakajte. Uskoro ćete biti preusmjereni...";
$_LANG['globalsystemname'] = "Početna WHMCS";
$_LANG['globalyouarehere'] = "Nalazite se ovdje:";
$_LANG['go'] = "Idi";
$_LANG['headertext'] = "Dobrodošli na naš portal za podršku korisnicima.";
$_LANG['hometitle'] = "Početna";
$_LANG['imagecheck'] = "Molimo da unesete sigurnosni kod prikazan na slici";
$_LANG['invoiceaddcreditamount'] = "Unesite iznos za primjenu";
$_LANG['invoiceaddcreditapply'] = "Primijeni već postojeći iznos";
$_LANG['invoiceaddcreditdesc1'] = "Vaš iznos na računu je";
$_LANG['invoiceaddcreditdesc2'] = "To se može primijeniti na račun koristeći donji obrazac.";
$_LANG['invoiceaddcreditoverbalance'] = "Ne možete primijeniti veći iznos na računu nego što je određeno";
$_LANG['invoiceaddcreditovercredit'] = "Ne možete primijeniti veći iznos nego što je na Vašem računu";
$_LANG['invoicenumber'] = "PONUDA #";
$_LANG['invoiceofflinepaid'] = "Plaćanja kreditnom karticom izvan mreže obavljaju se ručno.<br />Primit ćete potvrdu na e-mail adresu kada Vaša uplata bude obrađena.";
$_LANG['invoicerefnum'] = "Referentni broj";
$_LANG['invoices'] = "Moji računi";
$_LANG['invoicesamount'] = "Iznos";
$_LANG['invoicesattn'] = "ATTN";
$_LANG['invoicesbacktoclientarea'] = "<< Povratak na korisničke stranice";
$_LANG['invoicesbalance'] = "Stanje računa";
$_LANG['invoicesbefore'] = "prije";
$_LANG['invoicescancelled'] = "Otkazano";
$_LANG['invoicescollections'] = "Kolekcije";
$_LANG['invoicescredit'] = "Iznos na računu";
$_LANG['invoicesdatecreated'] = "Datum izdavanja računa";
$_LANG['invoicesdatedue'] = "Datum dospijeća";
$_LANG['invoicesdescription'] = "Opis";
$_LANG['invoicesdownload'] = "Preuzimanje";
$_LANG['invoicesdue'] = "Neplaćeni računi";
$_LANG['invoiceserror'] = "Došlo je do pogreške. Molimo, pokušajte ponovno.";
$_LANG['invoicesinvoicedto'] = "Ponuda za";
$_LANG['invoicesinvoicenotes'] = "Bilješke računa";
$_LANG['invoicesnoinvoices'] = "Nema računa";
$_LANG['invoicesnotes'] = "Bilješke";
$_LANG['invoicesoutstandinginvoices'] = "Izdvojeni računi";
$_LANG['invoicespaid'] = "Plaćen";
$_LANG['invoicespaynow'] = "Plati odmah";
$_LANG['invoicespayto'] = "Plati za";
$_LANG['invoicesrefunded'] = "Vraćeno";
$_LANG['invoicesstatus'] = "Status";
$_LANG['invoicessubtotal'] = "Međusuma";
$_LANG['invoicestax'] = "Iznos poreza";
$_LANG['invoicestaxindicator'] = "Označava oporezivu stavku.";
$_LANG['invoicestitle'] = "Ponuda #";
$_LANG['invoicestotal'] = "Ukupno";
$_LANG['invoicestransactions'] = "Transakcije";
$_LANG['invoicestransamount'] = "Iznos";
$_LANG['invoicestransdate'] = "Datum transakcije";
$_LANG['invoicestransgateway'] = "Sučelje";
$_LANG['invoicestransid'] = "ID transakcije";
$_LANG['invoicestransnonefound'] = "Nema povezanih transakcija";
$_LANG['invoicesunpaid'] = "Neplaćeno";
$_LANG['invoicesview'] = "Pregled računa";
$_LANG['jobtitle'] = "Naziv položaja/posla";
$_LANG['kbsuggestions'] = "Savjeti iz baze znanja";
$_LANG['kbsuggestionsexplanation'] = "Sljedeći članci koji bi Vam mogli odgovoriti na pitanje pronađeni su u bazi podataka.  Molimo, pregledajte savjete prije slanja upita.";
$_LANG['knowledgebasearticles'] = "Članci";
$_LANG['knowledgebasecategories'] = "Kategorije";
$_LANG['knowledgebasedescription'] = "Pretražite našu bazu podataka za odgovorima na ČPP";
$_LANG['knowledgebasefavorites'] = "Dodaj među favorite";
$_LANG['knowledgebasehelpful'] = "Je li Vam ovaj odgovor pomogao?";
$_LANG['knowledgebaseintrotext'] = "Baza znanja je organizirana u različite kategorije. Ili odaberite kategoriju od ispod ili pretražite bazu znanja za odgovorom na Vaše pitanje.";
$_LANG['knowledgebasemore'] = "Više";
$_LANG['knowledgebaseno'] = "Ne";
$_LANG['knowledgebasenoarticles'] = "Nema pronađenih članaka";
$_LANG['knowledgebasenorelated'] = "Nema vezanih članaka";
$_LANG['knowledgebasepopular'] = "Najpopularnije";
$_LANG['knowledgebaseprint'] = "Ispiši članak";
$_LANG['knowledgebaserating'] = "Ocjena:";
$_LANG['knowledgebaseratingtext'] = "Korisnici koji smatraju članak korisnim";
$_LANG['knowledgebaserelated'] = "Vezani članci";
$_LANG['knowledgebasesearch'] = "Traži";
$_LANG['knowledgebasetitle'] = "Baza znanja";
$_LANG['knowledgebaseviews'] = "Pregleda";
$_LANG['knowledgebasevote'] = "Glasaj";
$_LANG['knowledgebasevotes'] = "Glasovi";
$_LANG['knowledgebaseyes'] = "Da";
$_LANG['language'] = "Jezik";
$_LANG['latefee'] = "Nedavni zapisi";
$_LANG['latefeeadded'] = "Dodano";
$_LANG['latestannouncements'] = "Najnovije obavijesti";
$_LANG['loginbutton'] = "Prijava";
$_LANG['loginemail'] = "E-mail adresa";
$_LANG['loginforgotten'] = "Zaboravili ste lozinku?";
$_LANG['loginforgotteninstructions'] = "Zatraži poništenje lozinke";
$_LANG['loginincorrect'] = "Netočni podaci prijave. Molimo, pokušajte ponovno.";
$_LANG['loginintrotext'] = "Za pristup stranici trebate biti prijavljeni.";
$_LANG['loginpassword'] = "Lozinka";
$_LANG['loginrememberme'] = "Zapamti me";
$_LANG['logoutcontinuetext'] = "Nastavak";
$_LANG['logoutsuccessful'] = "Odjavili ste se.";
$_LANG['logouttitle'] = "Odjava";
$_LANG['maxmind_anonproxy'] = "Ne dopuštamo narudžbe s anonimnog Proxy poslužitelja.";
$_LANG['maxmind_callingnow'] = "Upravo ćete primiti automatski telefonski poziv koji je dio naših mjera za obranu od prijevare. Primit ćete četveroznamenkasti sigurnosni kod koji trebate unijeti ispod za završetak narudžbe.";
$_LANG['maxmind_countrymismatch'] = "Zemlja Vaše IP adrese ne podudara se s zemljom koju ste naveli pod adresom računa tako da ne možemo zaprimiti Vašu narudžbu.";
$_LANG['maxmind_error'] = "Greška";
$_LANG['maxmind_faileddescription'] = "Uneseni kod je netočan. Ukoliko smatrate da je došlo do greške, molimo da kontaktirate naš odjel podrške u što kraćem roku.";
$_LANG['maxmind_highfraudriskscore'] = "MaxMind smatra Vašu narudžbu mogućim visokim rizikom, pa je ona zadržana radi ručne obrade.<br /><br />Ukoliko mislite da ste primili ovu poruku greškom, molimo da primite naše isprike i <a href=\"submitticket.php\">kontaktirajte</a> podršku. Hvala.";
$_LANG['maxmind_highriskcountry'] = "Nažalost, ne možemo primiti Vašu narudžbu zbog mnogih prijevara i nezakonitih aktivnosti u Vašoj zemlji. Ukoliko želite dogovoriti alternativni način plaćanja, molimo da nam se obratite.";
$_LANG['maxmind_incorrectcode'] = "Netočan kod";
$_LANG['maxmind_pincode'] = "Pin kod";
$_LANG['maxmind_rejectemail'] = "Ne dopuštamo korištenje e-mail adresa besplatnih pružatelja usluga. Molimo, unesite drugu e-mail adresu";
$_LANG['maxmind_title'] = "MaxMind";
$_LANG['more'] = "Više";
$_LANG['morechoices'] = "Više izbora";
$_LANG['networkissuesaffecting'] = "Odgovarajući";
$_LANG['networkissuesaffectingyourservers'] = "Napomena: Predmeti koji utječu na poslužitelje s Vašim korisničkim računima bit će označeni zlatnom pozadinom";
$_LANG['networkissuesdate'] = "Datum";
$_LANG['networkissuesdescription'] = "Saznajte o trenutnim i predviđenim gubicima mreže";
$_LANG['networkissueslastupdated'] = "Zadnje ažurirano";
$_LANG['networkissuesnonefound'] = "Nema pronađenih pitanja mreže";
$_LANG['networkissuespriority'] = "Prioritet";
$_LANG['networkissuesprioritycritical'] = "Kritično";
$_LANG['networkissuespriorityhigh'] = "Visok";
$_LANG['networkissuesprioritylow'] = "Nizak";
$_LANG['networkissuesprioritymedium'] = "Srednji";
$_LANG['networkissuesstatusinprogress'] = "U tijeku";
$_LANG['networkissuesstatusinvestigating'] = "Istraga u tijeku";
$_LANG['networkissuesstatusopen'] = "Otvori";
$_LANG['networkissuesstatusoutage'] = "Gubitak";
$_LANG['networkissuesstatusreported'] = "Prijavljen";
$_LANG['networkissuesstatusresolved'] = "Riješen";
$_LANG['networkissuesstatusscheduled'] = "predviđen";
$_LANG['networkissuestitle'] = "Problemi mreže";
$_LANG['networkissuestypeother'] = "Drugo";
$_LANG['networkissuestypeserver'] = "Poslužitelj";
$_LANG['networkissuestypesystem'] = "Sustav";
$_LANG['newpassword'] = "Nova lozinka";
$_LANG['nextpage'] = "Sljedeća stranica";
$_LANG['no'] = "Ne";
$_LANG['nocarddetails'] = "Nema zabilježenih podataka kartice";
$_LANG['none'] = "Nijedan";
$_LANG['norecordsfound'] = "Nema zapisa";
$_LANG['or'] = "ili";
$_LANG['orderadditionalrequiredinfo'] = "Potrebne dodatne informacije";
$_LANG['orderaddon'] = "Dodatak";
$_LANG['orderaddondescription'] = "Sljedeći dodaci su dostupni za ovaj proizvod. Odaberite dodatke koje želite naručiti.";
$_LANG['orderavailable'] = "Dostupan";
$_LANG['orderavailableaddons'] = "Kliknite za pregled dostupnih dodataka";
$_LANG['orderbillingcycle'] = "Ciklus naplate";
$_LANG['ordercategories'] = "Kategorije";
$_LANG['orderchangeaddons'] = "Promijeni dodatke";
$_LANG['orderchangeconfig'] = "Promijeni podesive opcije";
$_LANG['orderchangedomain'] = "Promijeni domenu";
$_LANG['orderchangenameservers'] = "Promjeni samo domenske poslužitelje";
$_LANG['orderchangeproduct'] = "Promijeni proizvod";
$_LANG['ordercheckout'] = "Blagajna";
$_LANG['orderchooseaddons'] = "Odaberi dodatke proizvoda";
$_LANG['orderchooseapackage'] = "Odaberi paket";
$_LANG['ordercodenotfound'] = "Promocijski kod koji ste unijeli ne postoji";
$_LANG['ordercompletebutnotpaid'] = "Pažnja! Vaša narudžba je završena, ali nije plaćena pa još nije aktivirana.<br />Slijedite adresu ispod kako biste izvršili plaćanje.";
$_LANG['orderconfigpackage'] = "Podesive opcije";
$_LANG['orderconfigure'] = "Podesi";
$_LANG['orderconfirmation'] = "Potvrda narudžbe";
$_LANG['orderconfirmorder'] = "Potvrdi narudžbu";
$_LANG['ordercontinuebutton'] = "Nastavak >>";
$_LANG['orderdesc'] = "Opis";
$_LANG['orderdescription'] = "Nova narudžba";
$_LANG['orderdiscount'] = "Popust";
$_LANG['orderdomain'] = "Domena";
$_LANG['orderdomainoption1part1'] = "Želim da";
$_LANG['orderdomainoption1part2'] = "registrira novu domenu za mene.";
$_LANG['orderdomainoption2'] = "Ažurirat ću domenske poslužitelje na postojećoj domeni ili ću registrirati novu domenu.";
$_LANG['orderdomainoption3'] = "Želim premjestiti domenu na";
$_LANG['orderdomainoption4'] = "Želim koristiti besplatnu poddomenu.";
$_LANG['orderdomainoptions'] = "Opcije domene";
$_LANG['orderdomainregistration'] = "Registracija domene";
$_LANG['orderdomainregonly'] = "Registracija domene";
$_LANG['orderdomaintransfer'] = "Premještaj domene";
$_LANG['orderdontusepromo'] = "Ne koristi promocijski kod";
$_LANG['ordererroraccepttos'] = "Morate prihvatiti naše Uvjete korištenja";
$_LANG['ordererrordomainalreadyexists'] = "Domenu koju ste unijeli veće je registrirana kod nas. Morat ćete je otkazati prije ostavljanja nove narudžbe";
$_LANG['ordererrordomaininvalid'] = "Unesena domena nije valjana";
$_LANG['ordererrordomainnotld'] = "Morate unijeti TLD domene";
$_LANG['ordererrordomainnotregistered'] = "Ne možete premijestiti domenu koja nije registrirana";
$_LANG['ordererrordomainregistered'] = "Domena koju ste unijeli već je registrirana";
$_LANG['ordererrornameserver1'] = "Morate unijeti domenski poslužitelj 1";
$_LANG['ordererrornameserver2'] = "Morate unijeti domenski poslužitelj 2";
$_LANG['ordererrornodomain'] = "Niste unijeli naziv domene";
$_LANG['ordererrorpassword'] = "Niste unijeli lozinku";
$_LANG['ordererrorserverhostnameinuse'] = "Domena koju ste unijeli već je u upotrebi. Molimo unesite drugu.";
$_LANG['ordererrorservernohostname'] = "Morate unijeti naziv poslužitelja";
$_LANG['ordererrorservernonameservers'] = "Morate unijeti prefiks za oba domenska poslužitelja";
$_LANG['ordererrorservernorootpw'] = "Morate unijeti željenu lozinku glavnog direktorija";
$_LANG['ordererrorsubdomaintaken'] = "Poddomena koju ste unijeli je već zauzeta - molimo, pokušajte ponovno";
$_LANG['ordererrortransfersecret'] = "Morate unijeti transferni kod";
$_LANG['ordererroruserexists'] = "Već postoji korisnik s ovom e-mail adresom";
$_LANG['orderexistinguser'] = "Postojeći sam korisnik i želim dodati ovu narudžbu na svoj račun";
$_LANG['orderfailed'] = "Neuspjela narudžba";
$_LANG['orderfinalinstructions'] = "Imate li kakvih pitanja vezanih uz narudžbu, molimo pošaljite upit podršci preko korisničkih stranica s navedenim brojem narudžbe.";
$_LANG['orderfree'] = "BESPLATNO!";
$_LANG['orderfreedomainappliesto'] = "odnosi se samo na sljedeće ekstenzije";
$_LANG['orderfreedomaindescription'] = "na odabrane načine plaćanja";
$_LANG['orderfreedomainonly'] = "Besplatna domena";
$_LANG['orderfreedomainregistration'] = "Besplatna registracija domene";
$_LANG['ordergotoclientarea'] = "Kliknite ovdje za odlazak na korisničke stranice";
$_LANG['orderinvalidcodeforbillingcycle'] = "Ovaj kod se ne odnosi na odabrani ciklus naplate";
$_LANG['orderlogininfo'] = "Podaci prijave";
$_LANG['orderlogininfopart1'] = "Molimo, unesite lozinku koju želite koristiti za prijavu u svoje";
$_LANG['orderlogininfopart2'] = "korisničke stranice. Ona će se razlikovati od korisničkog imena &amp; lozinke za korisničko sučelje.";
$_LANG['ordernewuser'] = "Novi sam korisnik i želim kreirati korisnički račun";
$_LANG['ordernoproducts'] = "Nema pronađenih proizvoda";
$_LANG['ordernotes'] = "Bilješke / Dodatne informacije";
$_LANG['ordernotesdescription'] = "Ovdje možete unijeti sve dodatne bilješke i informacije koje želite uključiti u narudžbu...";
$_LANG['ordernowbutton'] = "Naruči";
$_LANG['ordernumberis'] = "Vaš broj narudžbe je:";
$_LANG['orderpaymentmethod'] = "Način plaćanja";
$_LANG['orderpaymentterm12month'] = "Cijena za 12 mjeseci";
$_LANG['orderpaymentterm1month'] = "Cijena za 1 mjesec";
$_LANG['orderpaymentterm24month'] = "Cijena za 24 mjeseca";
$_LANG['orderpaymentterm3month'] = "Cijena za 3 mjeseca";
$_LANG['orderpaymentterm6month'] = "Cijena za 6 mjeseci";
$_LANG['orderpaymenttermannually'] = "Godišnje";
$_LANG['orderpaymenttermbiennially'] = "Dvogodišnje";
$_LANG['orderpaymenttermfreeaccount'] = "Besplatni račun";
$_LANG['orderpaymenttermmonthly'] = "Mjesečno";
$_LANG['orderpaymenttermonetime'] = "Odjednom";
$_LANG['orderpaymenttermquarterly'] = "Kvartalno";
$_LANG['orderpaymenttermsemiannually'] = "Polu-godišnje";
$_LANG['orderprice'] = "Cijena";
$_LANG['orderproduct'] = "Proizvod/Usluga";
$_LANG['orderprogress'] = "Napredak";
$_LANG['orderpromoexpired'] = "Uneseni promotivni kod je istekao";
$_LANG['orderpromoinvalid'] = "Uneseni promotivni kod ne odnosi se na niti jednu stavku Vaše narudžbe";
$_LANG['orderpromomaxusesreached'] = "Uneseni promotivni kod već je iskorišten";
$_LANG['orderpromotioncode'] = "Promotivni kod";
$_LANG['orderpromovalidatebutton'] = "Potvrdite kod >>";
$_LANG['orderprorata'] = "Pro Rata";
$_LANG['orderreceived'] = "Zahvaljujemo na narudžbi. Uskoro ćete primiti e-mail poruku potvrde.";
$_LANG['orderregisterdomain'] = "Registriraj novu domenu";
$_LANG['orderregperiod'] = "Razdoblje registracije";
$_LANG['ordersecure'] = "Ova forma za narudžbu nalazi se u sigurnom području i za zaštitu od prijevare na Vašoj IP adresi";
$_LANG['ordersecure2'] = "je prijavljen.";
$_LANG['orderserverhostname'] = "Domenski poslužitelj";
$_LANG['orderservernameservers'] = "Domenski poslužitelji";
$_LANG['orderservernameserversdescription'] = "Prefiksi koje ste unijeli odredit će zadane domenske poslužitelje npr. ns1.vasadomena.com i ns2.vasadomena.com";
$_LANG['orderservernameserversprefix1'] = "Prefiks 1";
$_LANG['orderservernameserversprefix2'] = "Prefiks 2";
$_LANG['orderserverrootpassword'] = "Lozinka glavnog direktorija";
$_LANG['ordersetupfee'] = "Naknada za postavljanje";
$_LANG['orderstartover'] = "Krenuti ponovno";
$_LANG['ordersubdomaininuse'] = "Poddomena koju ste unijeli je već u upotrebi";
$_LANG['ordersubtotal'] = "Međusuma";
$_LANG['ordersummary'] = "Sažetak narudžbe";
$_LANG['ordertaxcalculations'] = "Izračun poreza";
$_LANG['ordertaxstaterequired'] = "Morate unijeti zemlju kako bi se primijenili izračuni poreza";
$_LANG['ordertitle'] = "Narudžba";
$_LANG['ordertos'] = "Uvjeti korištenja";
$_LANG['ordertosagreement'] = "Pročitao/la sam i prihvaćam";
$_LANG['ordertotalduetoday'] = "Ukupni dug na današnji dan";
$_LANG['ordertotalrecurring'] = "Ukupni iznos rata";
$_LANG['ordertransferdomain'] = "Premještaj postojećeg naziva domene";
$_LANG['ordertransfersecret'] = "Transferni kod";
$_LANG['ordertransfersecretexplanation'] = "Molimo, unesite transferni kod koji možete dobiti od trenutnog registrara.";
$_LANG['orderusesubdomain'] = "Koristi poddomenu";
$_LANG['orderyears'] = "Godina";
$_LANG['orderyourinformation'] = "Vaši podaci";
$_LANG['orderyourorder'] = "Vaša narudžba";
$_LANG['organizationname'] = "Naziv tvrtke";
$_LANG['outofstock'] = "Nije raspoloživo";
$_LANG['outofstockdescription'] = "Trenutno ova stavka nije raspoloživa, pa su obustavljene narudžbe za istu dok se ne popune zalihe. Molimo, kontaktirajte nas za više informacija.";
$_LANG['page'] = "Stranica";
$_LANG['pageof'] = "od";
$_LANG['please'] = "Molimo";
$_LANG['pleasewait'] = "Molimo, pričekajte...";
$_LANG['presalescontactdescription'] = "Ovdje možete slati upite prije kupovine";
$_LANG['previouspage'] = "Prethodna stranica";
$_LANG['proformainvoicenumber'] = "Ponuda broj #";
$_LANG['promoexistingclient'] = "Morate imati aktivan proizvod/uslugu za korištenje ovog koda";
$_LANG['promoonceperclient'] = "Ovaj kod se može koristiti samo jednom po korisniku";
$_LANG['pwstrengthfail'] = "Unesena lozina nije dovoljno snažna - molimo, unesite složeniju lozinku";
$_LANG['quicknav'] = "Brza navigacija";
$_LANG['recordsfound'] = "Pronađeno zapisa";
$_LANG['recurring'] = "Ponavljajući";
$_LANG['recurringamount'] = "Rata";
$_LANG['every'] = "Every";
$_LANG['registerdomain'] = "Registriraj domenu";
$_LANG['registerdomaindesc'] = "Unesite niže domenu koju želite registrirati kako biste utvrdili raspoloživost.";
$_LANG['registerdomainname'] = "Registriraj naziv domene";
$_LANG['relatedservice'] = "Vezane usluge";
$_LANG['rssfeed'] = "Obavijesti";
$_LANG['securityanswerrequired'] = "Potrebno je unijeti sigurnosni odgovor";
$_LANG['securitybothnotmatch'] = "Vaš odgovor i potvrda odgovora se ne podudaraju";
$_LANG['securitycurrentincorrect'] = "Vaše sadašnje pitanje i odgovor su netočni";
$_LANG['serverchangepassword'] = "Promijeni lozinku";
$_LANG['serverchangepasswordintro'] = "From here you can change the password of the product/service (note: this does not affect your password for our client area)";
$_LANG['serverchangepasswordconfirm'] = "Potvrdi lozinku";
$_LANG['serverchangepasswordenter'] = "Unesi novu lozinku";
$_LANG['serverchangepasswordfailed'] = "Promjena lozinke nije uspjela!";
$_LANG['serverchangepasswordsuccessful'] = "Lozinka je promijenjena!";
$_LANG['serverchangepasswordupdate'] = "Ažuriraj";
$_LANG['serverhostname'] = "Naziv poslužitelja";
$_LANG['serverlogindetails'] = "Podaci prijave";
$_LANG['servername'] = "Poslužitelj";
$_LANG['serverns1prefix'] = "NS1 Prefiks";
$_LANG['serverns2prefix'] = "NS2 Prefiks";
$_LANG['serverpassword'] = "Lozinka";
$_LANG['serverrootpw'] = "Lozinka glavnog direktorija";
$_LANG['serverstatusdescription'] = "Pregled podataka o statusu naših poslužitelja uživo";
$_LANG['serverstatusnoservers'] = "Trenutno nema poslužitelja za pratiti";
$_LANG['serverstatusnotavailable'] = "Nije dostupno";
$_LANG['serverstatusoffline'] = "Izvan mreže";
$_LANG['serverstatusonline'] = "Na mreži";
$_LANG['serverstatusphpinfo'] = "PHP Info";
$_LANG['serverstatusserverload'] = "Opterećenje poslužitelja";
$_LANG['serverstatustitle'] = "Status poslužitelja";
$_LANG['serverstatusuptime'] = "Vrijeme";
$_LANG['serverusername'] = "Korisničko ime";
$_LANG['show'] = "Prikaži";
$_LANG['ssladmininfo'] = "Administrativni podaci kontakta";
$_LANG['ssladmininfodetails'] = "Navedeni podaci kontakta neće biti prikazani na Certifikatu - korišteni će biti samo za kontakt vezan uz ovu narudžbu. SSL Certifikat i budući podsjetnici za obnovu bit će slani na dolje navedenu e-mail adresu.";
$_LANG['sslcertapproveremail'] = "E-mail odobritelja certifikata";
$_LANG['sslcertapproveremaildetails'] = "Morate odabrati između nižih opcija gdje želite da e-mail zahtjev za odobrenjem certifikata bude poslan.";
$_LANG['sslcertinfo'] = "Podaci SSL certifikata";
$_LANG['pleasechooseone'] = "Please choose one...";
$_LANG['sslcerttype'] = "Vrsta certifikata";
$_LANG['sslconfigcomplete'] = "Konfiguracija završena";
$_LANG['sslconfigcompletedetails'] = "Vaša konfiguracija SSL certifikata je završena i poslana na odobrenje. Uskoro ćete primiti e-mail za potvrdu.";
$_LANG['sslconfsslcertificate'] = "Podesi SSL Certifikat";
$_LANG['sslcsr'] = "CSR";
$_LANG['sslerrorapproveremail'] = "Morate odabrati e-mail adresu odobritelja";
$_LANG['sslerrorentercsr'] = "Morate unijeti svoj CSR (certificate signing request)";
$_LANG['sslerrorselectserver'] = "Morate odabrati vrstu svog poslužitelja";
$_LANG['sslinvalidlink'] = "Neispravna adresa.";
$_LANG['sslorderdate'] = "Datum narudžbe";
$_LANG['sslserverinfo'] = "Podaci poslužitelja";
$_LANG['sslserverinfodetails'] = "Morate imati ispravan \"CSR\" (Certificate Signing Request) za podešavanje SSL Certifikata. CSR je kodirani dio teksta generiran od strane poslužitelja gdje će SSL Certifikat biti postavljen. Ukoliko još nemate CSR, trebate ga generirati ili zatražiti hosting pružatelja usluge da to učini za Vas. Također, molimo, da pazite da unesete točne podatke jer se ne mogu mijenjati nakon što se SSL Certifikat izda.";
$_LANG['sslservertype'] = "Vrsta poslužitelja";
$_LANG['sslstatus'] = "Status konfiguracije";
$_LANG['statscreditbalance'] = "Stanje računa/kredit";
$_LANG['statsdueinvoicesbalance'] = "Ukupno neplaćenih računa";
$_LANG['statsnumdomains'] = "Ukupno domena";
$_LANG['statsnumproducts'] = "Ukupno usluga";
$_LANG['statsnumreferredsignups'] = "Broj referiranih prijava";
$_LANG['statsnumtickets'] = "Ukupno korisničkih upita";
$_LANG['submitticketdescription'] = "Zatraži korisničku podršku";
$_LANG['supportclickheretocontact'] = "kontaktirajte nas";
$_LANG['supportpresalesquestions'] = "Ukoliko imate pitanja prije naručivanja";
$_LANG['supportticketinvalid'] = "Došlo je do greške. Zatraženi upit nije pronađen.";
$_LANG['supportticketsallowedextensions'] = "Dozvoljene ekstenzije datoteka";
$_LANG['supportticketschoosedepartment'] = "Odaberi odjel";
$_LANG['supportticketsclient'] = "Korisnik";
$_LANG['supportticketsclientemail'] = "E-mail adresa";
$_LANG['supportticketsclientname'] = "Naziv";
$_LANG['supportticketsdate'] = "Datum";
$_LANG['supportticketsdepartment'] = "Odjel";
$_LANG['supportticketsdescription'] = "Pregledaj i odgovori na postojeće upite";
$_LANG['supportticketserror'] = "Greška";
$_LANG['supportticketserrornoemail'] = "Niste unijeli e-mail adresu";
$_LANG['supportticketserrornomessage'] = "Niste unijeli poruku";
$_LANG['supportticketserrornoname'] = "Niste unijeli svoje ime";
$_LANG['supportticketserrornosubject'] = "Niste unijeli predmet poruke";
$_LANG['supportticketsfilenotallowed'] = "Datoteka koju ste pokušali postaviti nije dozvoljena.";
$_LANG['supportticketsheader'] = "Ako ne možete pronaći rješenje problema u našoj bazi znanja, predajte upit tako da odaberete pravi odjel.";
$_LANG['supportticketsnotfound'] = "Upit nije pronađen";
$_LANG['supportticketsopentickets'] = "Otvoreni upiti za podršku";
$_LANG['supportticketspagetitle'] = "Upiti za podršku";
$_LANG['supportticketsposted'] = "Objavljen";
$_LANG['supportticketsreply'] = "Odgovori";
$_LANG['supportticketsstaff'] = "Osoblje";
$_LANG['supportticketsstatus'] = "Status";
$_LANG['supportticketsstatusanswered'] = "Odgovoren";
$_LANG['supportticketsstatusclosed'] = "Zatvoren";
$_LANG['supportticketsstatuscloseticket'] = "Ukoliko je riješen, zatvori upit";
$_LANG['supportticketsstatuscustomerreply'] = "Korisnički-Odgovor";
$_LANG['supportticketsstatusinprogress'] = "U tijeku";
$_LANG['supportticketsstatusonhold'] = "Na čekanju";
$_LANG['supportticketsstatusopen'] = "Otvoren";
$_LANG['supportticketssubject'] = "Predmet";
$_LANG['supportticketssubmitticket'] = "Pošalji upit";
$_LANG['supportticketssystemdescription'] = "Sustav upita omogućuje nam da odgovorimo na Vaše upite u što kraćem roku. Kada odgovorimo, bit ćete obaviješteni na e-mail adresu.";
$_LANG['supportticketsticketattachments'] = "Prilozi";
$_LANG['supportticketsticketcreated'] = "Upit je poslan";
$_LANG['supportticketsticketcreateddesc'] = "Vaš upit je kreiran. Poslana Vam je e-mail poruka s podacima o upitu. Ako ga želite pregledati, sada je prilika.";
$_LANG['supportticketsticketid'] = "ID upita";
$_LANG['supportticketsticketsubject'] = "Predmet";
$_LANG['supportticketsticketsubmit'] = "Pošalji";
$_LANG['supportticketsticketurgency'] = "Hitnost";
$_LANG['supportticketsticketurgencyhigh'] = "Visoka";
$_LANG['supportticketsticketurgencylow'] = "Niska";
$_LANG['supportticketsticketurgencymedium'] = "Srednja";
$_LANG['supportticketsuploadfailed'] = "Postavljanje nije uspjelo";
$_LANG['supportticketsviewticket'] = "Pregled upita";
$_LANG['telesignincorrectpin'] = "Netočan Pin!";
$_LANG['telesigninitiatephone'] = "Ne možemo pokrenuti telefonsku potvrdu za Vaš broj. Molimo, kontaktirajte nas.";
$_LANG['telesigninvalidnumber'] = "Nevažeći telefonski broj";
$_LANG['telesigninvalidpin'] = "PIN nije važeći!";
$_LANG['telesigninvalidpin2'] = "Pin koji ste unijeli nije važeći.";
$_LANG['telesigninvalidpinmessage'] = "Neuspjela potvrda Pin koda";
$_LANG['telesignmessage'] = "Pokrenuta provjera za broj %s . Molimo, pričekajte...";
$_LANG['telesignphonecall'] = "Telefonski poziv";
$_LANG['telesignpin'] = "Unesite svoj PIN:";
$_LANG['telesignsms'] = "Sms";
$_LANG['telesignsmstextmessage'] = "Hvala što koristite naš SMS sustav potvrde. Vaš kod je: %s Molimo, unesite ga u svoje računalo!";
$_LANG['telesigntitle'] = "TeleSign telefonska provjera.";
$_LANG['telesigntype'] = "Odaberite vrstu provjere za broj %s:";
$_LANG['telesignverificationcanceled'] = "Došlo je do privremenog problema s telefonskom provjerom i ona je otkazana.";
$_LANG['telesignverificationproblem'] = "Došlo je do problema prilikom telefonske provjere i Vaša narudžba nije potvrđena. Molimo, pokušajte kasnije.";
$_LANG['telesignverify'] = "Vaš telefonski broj %s treba biti potvrđen kako bi se završila narudžba.";
$_LANG['ticketratingexcellent'] = "Izvrsna";
$_LANG['ticketratingpoor'] = "Slaba";
$_LANG['ticketratingquestion'] = "Kako biste ocijenili ovaj odgovor?";
$_LANG['ticketreatinggiven'] = "Ocijenili ste odgovor";
$_LANG['transferdomain'] = "Premijesti domenu";
$_LANG['transferdomaindesc'] = "Želite premijestiti domenu k nama? U tom slučaju, unesite niže svoju domenu za početak.";
$_LANG['transferdomainname'] = "premijesti naziv doemene";
$_LANG['updatecart'] = "Ažuriraj košaricu";
$_LANG['upgradechooseconfigoptions'] = "Povećaj/Smanji podesive opcije ovog proizvoda.";
$_LANG['upgradechoosepackage'] = "Odaberite paket kojim želite povećati/smanjiti svoj trenutni paket.";
$_LANG['upgradecurrentconfig'] = "Trenutna konfiguracija";
$_LANG['upgradedowngradeconfigoptions'] = "Opcije povećanja/smanjenja";
$_LANG['upgradenewconfig'] = "Nova konfiguracija";
$_LANG['upgradenochange'] = "Nema promjene";
$_LANG['upgradeproductlogic'] = "Cijena povećanja je uračunata u iznos na računu neiskorištenog dijela već postojećeg plana plaćanja i novi plan plaćanja za isto razdoblje.";
$_LANG['upgradesummary'] = "Niže je sažetak Vaše narudžbe povećanja.";
$_LANG['usedefaultcontact'] = "Koristi zadani kontakt (detalji niže prikazani)";
$_LANG['varilogixfraudcall_callnow'] = "Nazovite odmah!";
$_LANG['varilogixfraudcall_description'] = "Kao mjera naše zaštite od prijevare, nazvat ćemo Vas na registrirani telefonski broj i zamoliti da unesete pin kod. Molimo, pripremite pin kod i kada ste spremni za poziv kliknite na donju tipku.";
$_LANG['varilogixfraudcall_error'] = "Došlo je do greške i nismo bili u mogućnosti nazvati vas radi potvrde. Molimo da kontaktirate naš odjel podrške što prije kako biste dovršili narudžbu.";
$_LANG['varilogixfraudcall_fail'] = "Poziv za potvrdu Vaše narudžbe nije uspio. Razlog tome je što ste možda krivo unijeli telefonski broj ili je on na našoj listi nepoćudnih korisnika. Molimo da kontaktirate naš odjel podrške što prije kako biste dovršili narudžbu.";
$_LANG['varilogixfraudcall_failed'] = "Nije uspio";
$_LANG['varilogixfraudcall_pincode'] = "Pin kod";
$_LANG['varilogixfraudcall_title'] = "VariLogix FraudCall";
$_LANG['viewcart'] = "Pregled košarice";
$_LANG['welcomeback'] = "Dobrodošli natrag";
$_LANG['whoisresults'] = "WHOIS rezultati za";
$_LANG['yes'] = "Da";
$_LANG['yourdetails'] = "Vaši detalji";

# Version 4.1

$_LANG['clientareafiles'] = "Datoteke u prilogu";
$_LANG['clientareafilesdate'] = "Datum dodavanja";
$_LANG['clientareafilesfilename'] = "Naziv datoteke";

$_LANG['pwreset'] = "Poništenje izgubljenje lozinke";
$_LANG['pwresetdesc'] = "Ukoliko ste zaboravili svoju lozinku, možete je poništiti. Pošto unesete svoju registriranu e-mail adresu (i odgovorite na sigurnosno pitanje, ukoliko je postavljeno)daljna uputstva za poništenje loinke bit će Vam poslana.";
$_LANG['pwresetemailrequired'] = "Niste unijeli e-mail adresu";
$_LANG['pwresetemailnotfound'] = "Nije pronađen korisnički račun s navedenom e-mail adresom";
$_LANG['pwresetsecurityquestionrequired'] = "Budući da imate postavljeno sigurnosno pitanje na korisničkom računu, morate odgovoriti na njega.";
$_LANG['pwresetsecurityquestionincorrect'] = "Odgovor na sigurnosno pitanje se ne podudara s odgovorom zabilježenim na Vašem računu";
$_LANG['pwresetsubmit'] = "Pošalji";
$_LANG['pwresetvalidationsent'] = "E-mail potvrde je poslan";
$_LANG['pwresetvalidationcheckemail'] = "Započeo je proces poništenja lozinke. Molimo, provjerite svoju elektroničku pošti za daljnjim uputstvima.";
$_LANG['pwresetkeyinvalid'] = "Adresa za poništenje koju ste slijedili nije valjana. Molimo, pokušajte ponovno.";
$_LANG['pwresetkeyexpired'] = "Adresa za poništenje koju ste slijedili je istekla. Molimo, pokušajte ponovno.";
$_LANG['pwresetvalidationsuccess'] = "Poništenje lozinke je uspjelo";

$_LANG['overagescharges'] = "Staro zaduženje";
$_LANG['overagestotaldiskusage'] = "Ukupna iskorištenost prostora";
$_LANG['overagestotalbwusage'] = "Ukupni promet";

$_LANG['affiliatescommissionspending'] = "Provizije u isčekivanju";
$_LANG['affiliatescommissionsavailable'] = "Dostupni iznos provizija";
$_LANG['affiliatessignups'] = "Broj prijava";
$_LANG['affiliatesconversionrate'] = "Stopa pretvorbe";

$_LANG['configoptionqtyminmax'] = "%s ima minimum potrebnih %s i maksimum %s";

$_LANG['creditcardnostore'] = "Označite ovu kućicu ako NE želite da sačuvamo podatke Vaše kreditne kartice za ponovne uplate";
$_LANG['creditcarddelete'] = "Izbriši pohranjene podatke kreditne kartice";
$_LANG['creditcarddeleteconfirmation'] = "Pohranjeni podaci kreditne kartice su maknuti iz Vašeg korisničkog računa";
$_LANG['creditcardupdatenotpossible'] = "Podaci kreditne kartice trenutno ne mogu biti ažurirani. Molimo, pokušajte kasnije.";

$_LANG['invoicepaymentsuccessconfirmation'] = "Zahvaljujemo! Vaša uplata je bila uspješna.";
$_LANG['invoicepaymentfailedconfirmation'] = "Nažalost, Vaša uplata nije uspjela.<br />Molimo, pokušajte ponovno ili kontaktirajte podršku.";

# Version 4.2

$_LANG['promoappliedbutnodiscount'] = "Promocijski kod koji ste unijeli je primjenjen na Vašu košaricu, no nema stavki na koje se popust odnosi. Molimo, pogledajte uvjete popusta.";

$_LANG['upgradeerroroverdueinvoice'] = "Trenutno ne možete povećati ili smanjiti proizvod jer je račun za sljedeću obnovu već generiran.<br /><br />Za nastavak, molimo, izvršite uplatu i bit ćete u mogućnosti povećavati i smanjivati, a iznos razlike bit će Vam naplaćen ili pridodan na račun.";

$_LANG['subaccountactivate'] = "Aktiviraj pod-račun";
$_LANG['subaccountactivatedesc'] = "Označi za pod-račun s pristupom korisničkim stranicama";
$_LANG['subaccountpermissions'] = "Dopuštenja pod-računa";
$_LANG['subaccountpermsprofile'] = "Izmijeni profil glavnog korisnika računa";
$_LANG['subaccountpermscontacts'] = "Pregled & upravljanje kontaktima";
$_LANG['subaccountpermsproducts'] = "Pregled proizvoda & usluga";
$_LANG['subaccountpermsmanageproducts'] = "Pregled & upravljanje lozinkama proizvoda";
$_LANG['subaccountpermsdomains'] = "Pregled domena";
$_LANG['subaccountpermsmanagedomains'] = "Upravljanje postavkama domene";
$_LANG['subaccountpermsinvoices'] = "Pregled & plaćanje računa";
$_LANG['subaccountpermstickets'] = "Pregled & otvaranje upita za podršku";
$_LANG['subaccountpermsaffiliates'] = "Pregled & upravljanje affiliate računom";
$_LANG['subaccountpermsemails'] = "Pregled e-mail poruka";
$_LANG['subaccountpermsorders'] = "Nove narudžbe/Povećanja/Otkazivanja";
$_LANG['subaccountpermissiondenied'] = "Nemate dopuštenja za pristup stranici";
$_LANG['subaccountallowedperms'] = "Vaša dopuštenja su:";
$_LANG['subaccountcontactmaster'] = "Kontaktirajte glavnog korisnika računa ukoliko smatrate da je došlo do pogreške.";

$_LANG['knowledgebasealsoread'] = "Također pročitajte";

$_LANG['orderpaymenttermtriennially'] = "Trogodišnje";
$_LANG['orderpaymentterm36month'] = "Cijena za 36 mjeseci";

$_LANG['domainrenewals'] = "Obnove domena";
$_LANG['domaindaysuntilexpiry'] = "Dana do isteka";
$_LANG['domainrenewalsnoneavailable'] = "Nema domena za obnovu na Vašem računu";
$_LANG['domainrenewalspastgraceperiod'] = "Prošlo rezdoblje obnove";
$_LANG['domainrenewalsingraceperiod'] = "Posljednja prilika za obnovu!";
$_LANG['domainrenewalsdays'] = "Dana";
$_LANG['domainrenewalsdaysago'] = "Dana prije";

$_LANG['invoicespartialpayments'] = "Djelomično plaćanje";
$_LANG['invoicestotaldue'] = "Ukupno dugovanje";

$_LANG['masspaytitle'] = "Grupno plaćanje";
$_LANG['masspaydescription'] = "Niže je sažetak odabranih računa i njihov ukupni iznos. Za izvršenje uplate, odaberite način plaćanja.";
$_LANG['masspayselected'] = "Platiti odabrano";
$_LANG['masspayall'] = "Platiti sve";
$_LANG['masspaymakepayment'] = "Izvršiti plaćanje";

# Version 4.3

$_LANG['searchenterdomain'] = "Upišite domenu za pretragu";
$_LANG['searchfilter'] = "Filter";

$_LANG['suspendreason'] = "Razlog suspenzije";
$_LANG['suspendreasonoverdue'] = "Dugovanje nije podmireno na vrijeme";

$_LANG['vpsnetmanagement'] = "VPS Management";
$_LANG['vpsnetpowermanagement'] = "Power Management";
$_LANG['poweron'] = "Power On";
$_LANG['poweroffforced'] = "Power Off (Forced)";
$_LANG['powerreboot'] = "Reboot";
$_LANG['powershutdown'] = "Shutdown";
$_LANG['vpsnetcpugraphs'] = "CPU Graphs";
$_LANG['vpsnetnetworkgraphs'] = "Network Graphs";
$_LANG['vpsnethourly'] = "Hourly";
$_LANG['vpsnetdaily'] = "Daily";
$_LANG['vpsnetweekly'] = "Weekly";
$_LANG['vpsnetmonthly'] = "Monthly";
$_LANG['view'] = "View";
$_LANG['vpsnetbackups'] = "Backup Options";
$_LANG['vpsnetgenbackup'] = "Generate Backup";
$_LANG['vpsnetrestorebackup'] = "Restore Backup";
$_LANG['vpsnetrestorebackupwarning'] = "Restoring the backup will over write your VPS server";
$_LANG['vpsnetnobackups'] = "There are no backups";
$_LANG['vpsnetrunning'] = "Running";
$_LANG['vpsnetnotrunning'] = "Not Running";
$_LANG['vpsnetpowercycling'] = "Power is cycling";
$_LANG['vpsnetcloud'] = "Cloud";
$_LANG['vpsnettemplate'] = "Template";
$_LANG['vpsnetstatus'] = "System Status";
$_LANG['vpsnetbwusage'] = "Bandwidth Usage";

$_LANG['twitterlatesttweets'] = "Zadnje Twitter poruke";
$_LANG['twitterfollow'] = "Pratite nas na Twitteru";
$_LANG['twitterfollowus'] = "Pratite nas";
$_LANG['twitterfollowuswhy'] = "i saznajte zanimljive novosti i akcije";

$_LANG['chatlivehelp'] = "Pomoć uživo";

$_LANG['domainrelease'] = "Oslobodi domenu";
$_LANG['domainreleasedescription'] = "Unesite novi TAG ovdje kako biste prebacili Vašu domenu novom registraru";
$_LANG['domainreleasetag'] = "Tag novog registrara";

# Ajax Order Form

$_LANG['orderformtitle'] = "Obrazac za naručivanje";

$_LANG['signup'] = "Prijavi se";
$_LANG['loading'] = "Učitavanje...";

$_LANG['ordersummarybegin'] = "Kolica su prazna<br/>Molimo Vas za početak odaberite proizvod...";

$_LANG['cartchooseproduct'] = "Izaberite ulsugu";
$_LANG['cartconfigurationoptions'] = "Opcije za podešavanje";

$_LANG['ordererrorsoccurred'] = "Pojavila se greška i mora biti ispravljena prije odlaska na blagajnu:";
$_LANG['ordererrortermsofservice'] = "Morate pristati na Uvjete poslovanja";
$_LANG['ordertostickconfirm'] = "Molimo Vas, označite kućicu ako se slažete s";

$_LANG['cartnewcustomer'] = "Ja sam NOVI korisnik";
$_LANG['cartexistingcustomer'] = "Ja sam postojeći korisnik";

$_LANG['cartpromo'] = "Promocija";
$_LANG['cartenterpromo'] = "Unesite promotivni kod";
$_LANG['cartremovepromo'] = "Ukloni Promo";

$_LANG['cartrecurringcharges'] = "Ponavljajući troškovi";

$_LANG['cartenterdomain'] = "Molimo Vas unuesite dolje domenu koju želite koristiti.";

$_LANG['cartdomainavailableoptions'] = "Čestitamo, domena je slobodna!";
$_LANG['cartdomainavailableregister'] = "Molim Vas registrirajte domenu za";
$_LANG['cartdomainavailablemanual'] = "Sam ću je registrirati";

$_LANG['cartdomainunavailableoptions'] = "Žao nam je, ali ova domena je već zauzeta. Ukoliko ste vi vlasnik, molimo Vas izaberite jednu od opcija navedenih dolje...";
$_LANG['cartdomainunavailabletransfer'] = "Molim Vas za transfer domene";
$_LANG['cartdomainunavailablemanual'] = "Ova domena je već moja i sam ću osvježiti podatke o nameserverima";

$_LANG['cartdomaininvalid'] = "Domena koju ste upisali nije valjana. Upišite samo naziv domene bez www, npr. luxart-webstudio.com";

# Version 4.4

$_LANG['dlinvalidlink'] = "Link koji ste slijedli nije valjan. Molimo Vas kontaktirajte podršku";

$_LANG['domaindnsmanagementlaunch'] = "Pokreni DNS Manager";
$_LANG['domainemailforwardinglaunch'] = "Pokreni Mail Forwarding Manager";

# Version 4.5

$_LANG['domaindnspriority'] = "Prioritet";
$_LANG['domaindnsmxonly'] = "Prioritet za Record for MX Only";

$_LANG['orderpromoprestart'] = "Ova promocija još nije krenula, molim Vas pokušajte kasnije.";

$_LANG['ticketmerge'] = "SPOJENO";

$_LANG['quote'] = "Ponuda";
$_LANG['quotestitle'] = "Moje ponude";
$_LANG['quoteview'] = "View";
$_LANG['quotedownload'] = "Vidi/Preuzmi";
$_LANG['quoteacceptbtn'] = "Accept Quote";
$_LANG['quotedlpdfbtn'] = "Download PDF";
$_LANG['quotediscountheading'] = "Discount (%)";
$_LANG['noquotes'] = "Na Vašem računu trenutno nema spremljenih ponuda.<br />Kako biste zatražili ponudu, pošaljite karticu/ticket.";
$_LANG['quotenumber'] = "Ponuda #";
$_LANG['quotesubject'] = "Naslov";
$_LANG['quotedatecreated'] = "Datum";
$_LANG['quotevaliduntil'] = "Vrijedi do";
$_LANG['quotestage'] = "Status";
$_LANG['quoterecipient'] = "Za";
$_LANG['quoteqty'] = "Kom";
$_LANG['quotedesc'] = "Opis";
$_LANG['quoteunitprice'] = "Jed. cijena";
$_LANG['quotediscount'] = "Popust %";
$_LANG['quotelinetotal'] = "Ukupno";
$_LANG['quotestagedraft'] = "Nacrt";
$_LANG['quotestagedelivered'] = "Dostavljeno";
$_LANG['quotestageonhold'] = "Na čekanju";
$_LANG['quotestageaccepted'] = "Prihvaćena";
$_LANG['quotestagelost'] = "Lost";
$_LANG['quotestagedead'] = "Dead";
$_LANG['quoteref'] = "Nova ponuda #";
$_LANG['quotedeposit'] = "Polog";
$_LANG['quotefinalpayment'] = "Razlika od depozita";

$_LANG['invoiceoneoffpayment'] = "Plati sve račune odjednom";
$_LANG['invoicesubscriptionpayment'] = "Izradi automatsku periodičku pretplatu";

$_LANG['invoicepaymentpendingreview'] = "Hvala! Plaćanje je uspjelo i bit će pridodano vašem računu, čim završi 2Checkout postupak provjere.<br /><br />Molimo Vas za strpljenje, s obzirom da ovo može potrajati i nekoliko sati.";

$_LANG['step'] = "Korak %s";
$_LANG['cartdomainexists'] = "Ova domena je već upisana u našoj bazi podataka i ne može biti ponovno naručena";
$_LANG['cartcongratsdomainavailable'] = "Čestitke, %s je dostupna!";
$_LANG['cartregisterhowlong'] = "Na koliko dugo želite registrirati?";
$_LANG['cartdomaintaken'] = "Nažalost, %s je već zauzeta";
$_LANG['carttransfernotregistered'] = "%s još uvijek izgleda nije registrirana";
$_LANG['carttransferpossible'] = "Čestitke, domenu %s moguće je transferirati kod nas za samo %s";
$_LANG['cartotherdomainsuggestions'] = "Ostale domene za koje bi mogli biti zainteresirani...";
$_LANG['cartdomainsconfiginfo'] = "Za domenu koju ste odabrali dostupne su slijedeće opcije. Obavezna polja onačena su sa *.";
$_LANG['cartnameserverchoice'] = "Odabir nameservera";
$_LANG['cartnameserverchoicedefault'] = "Koristi zadane nameservere za naš hosting";
$_LANG['cartnameserverchoicecustom'] = "Koristi prilagođene nameservere";
$_LANG['cartfollowingaddonsavailable'] = "Za Vaše proizvode dostupni su slijedeći dodaci & usluge.";
$_LANG['cartregisterdomainchoice'] = "Registriraj novu domenu";
$_LANG['carttransferdomainchoice'] = "Prebacite Vašu domenu od drugog registrara";
$_LANG['cartexistingdomainchoice'] = "Koristit ću svoju postojeću domenu i uredit ću podatke o nameserverima";
$_LANG['cartsubdomainchoice'] = "Koristi poddomenu od %s";
$_LANG['carterrordomainconfigskipped'] = "Morate se vratiti i ispuniti gore obavezna polja o podešavanju domene";
$_LANG['cartproductchooseoptions'] = "Odaberite opcije";
$_LANG['cartproductselection'] = "Odabir proizvoda";
$_LANG['cartreviewcheckout'] = "Pregled & Blagajna";
$_LANG['cartchoosecycle'] = "Odaberite period plaćanja";
$_LANG['cartavailableaddons'] = "Dostupni dodaci";
$_LANG['cartsetupfees'] = "Naknada za otvaranje računa";
$_LANG['cartchooseanotherproduct'] = "Odaberite drugi paket";
$_LANG['cartaddandcheckout'] = "Dodaj u košaricu & Blagajna";
$_LANG['cartchooseanothercategory'] = "Izaberite drugu kategoriju";
$_LANG['carttryanotherdomain'] = "Odaberite drugu domenu";
$_LANG['cartmakedomainselection'] = "Molim Vas upišite domenu koju želite koristiti s Vašom hosting uslugom tako da odaberete jednu od opcija dolje.";
$_LANG['cartfraudcheck'] = "Provjera za slučaj prevare";

$_LANG['newcustomer'] = "Novi korisnik";
$_LANG['existingcustomer'] = "Postojeći korisnik";
$_LANG['newcustomersignup'] = "Još uvijek niste registrirani? %sKliknite ovdje i učinite to odmah...%s";

$_LANG['upgradeonselectedoptions'] = "(na odabrane opcije)";
$_LANG['recurringpromodesc'] = "Ovaj promo kod također uključuje i %s periodički popust<br />(Popust će se primijeniti na slijedećoj obnovi usluge)";

# Version 4.5.2

$_LANG['ajaxcartcheckout'] = "Odmah idi na blagajnu &raquo;";
$_LANG['ordersummarybegin'] = "Kolica su prazna<br/>Molimo Vas za početak odaberite proizvod...";
$_LANG['ajaxcartconfigreqnotice'] = "Na putu ste za prijavu kod nas, ali prije toga morate odabrati domenu, da biste mogli izabrati proizvode iz ponude...";

# Version 5.0.0

$_LANG['cancelrequestdomain'] = "Otkazati obnovu domene?";
$_LANG['cancelrequestdomaindesc'] = "Već imate aktivnu regitraciju domene  za domenu koja je povezana s ovim paketom.<br />Ova domena je vrijedi do %s po cijeni %s za %s godinu/e<br /><br />Ako želite otkazati domenu i dopustiti da istekne kad nakon intervala registracije, označite donju kućicu.";
$_LANG['cancelrequestdomainconfirm'] = "Potvrđujem da želim obnoviti ovu domenu";

$_LANG['startingfrom'] = "S početkom od";

$_LANG['orderpromopriceoverride'] = "Preinaka cijene";
$_LANG['orderpromofreesetup'] = "Beplatno podešavanje";

$_LANG['thereisaproblem'] = "Oops, pojavio se problem...";
$_LANG['problemgoback'] = "Vratite se natrag i pokušajte ponovo";

$_LANG['quantity'] = "Količina";
$_LANG['cartqtyenterquantity'] = "Želite li više od jednog proizvoda ove vrste? Ovdje unesite količinu:";
$_LANG['cartqtyupdate'] = "Osvježi";
$_LANG['invoiceqtyeach'] = "/svaka";

$_LANG['nschoicedefault'] = "Koristi zadane nameservere";
$_LANG['nschoicecustom'] = "Koristi druge nameservere (unesite ih dolje)";

$_LANG['jumpto'] = "Skoči na";
$_LANG['top'] = "Vrh";

$_LANG['domaincontactusexisting'] = "Upotrijebite postojeći kontakt";
$_LANG['domaincontactusecustom'] = "Navedite relevantne informacije u nastavku";
$_LANG['domaincontactchoose'] = "Izaberite kontakt";
$_LANG['domaincontactprimary'] = "Primarni profil podataka";

$_LANG['invoicepdfgenerated'] = "PDF genereran";

$_LANG['domainrenewalsbeforerenewlimit'] = "Minimalno vrijeme obnove %s dana unaprijed";

$_LANG['promonewsignupsonly'] = "Ovaj promotivni kod valjan je samo za nove klijente";

# Bulk Domain Management

$_LANG['domainbulkmanagement'] = "Upravljanje višestrukim domenama";
$_LANG['domainbulkmanagementchangesaffect'] = "Promjene koje su navedene dolje obuhvatit će slijedeće domene:";
$_LANG['domainbulkmanagementchangeaffect'] = "Ova promjena će se primjeniti na slijedeće domene:";
$_LANG['domaincannotbemanaged'] = "ne može se upravljati automatski - molimo Vas kontaktirajte podršku vezano za promjene koje želite napraviti";
$_LANG['domainbulkmanagementnotpossible'] = "Nažalost, ove postavke trenutno  ne mogu biti uređivane iz korisničke zone. Molimo Vas kontaktirajte podršku vezano za promjene koje ste željeli napraviti.";

$_LANG['domainmanagens'] = "Upravljanje nameserverima";

$_LANG['domainautorenewstatus'] = "Status automatske obnove";
$_LANG['domainautorenewinfo'] = "Automatska obnova pomaže u zaštiti Vaše domene. Kad je uključena, mi ćemo Vam nekoliko tjedana prije isteka domene automatski poslati ponudu za obnovu, kako biste na vrijeme izvršili plaćanje i obnovili domenu";
$_LANG['domainautorenewrecommend'] = "Naša je preporuka da uključite automatsko obnavljanje domene i spriječite mogući gubitak domene.";

$_LANG['domainreglockstatus'] = "Status registra zaključano";
$_LANG['domainreglockinfo'] = "Zaključavanje registra (poznato kao i Zaštita od krađe) štiti Vašu domenu od neautoriziranog transfera domene";
$_LANG['domainreglockrecommend'] = "Naša je preporuka da ova opcija bude uključena, osim u slučaju kad premještate Vašu domenu negdje drugdje.";
$_LANG['domainreglockenable'] = "Uključi zaključavanje registra";
$_LANG['domainreglockdisable'] = "Isključi zaključavanje registra";

$_LANG['domaincontactinfoedit'] = "Uredi kontakt informacije";

$_LANG['domainmassrenew'] = "Obnovi domene";

# reCAPTCHA

$_LANG['captchatitle'] = "Spam bot verifikacija";
$_LANG['captchaverify'] = "Molimo Vas upišite znakove koji vidite na slici dolje u za to predviđenu kućicu. Ovo je obavezno zbog zaštite od automatiziranih prijava.";
$_LANG['captchaverifyincorrect'] = "Znakovi koje ste unijeli ne podudaraju se s onima na slici. Pokušajte ponovo.";
$_LANG['recaptcha-invalid-site-private-key'] = "Došlo je do greške. Molimo Vas kontaktirajte podršku (error code: cap1)";
$_LANG['recaptcha-invalid-request-cookie'] = "Došlo je do greške. Pokušajte ponovo (error code: cap2)";
$_LANG['recaptcha-incorrect-captcha-sol'] = "Znakovi koje ste unijeli ne podudaraju se riječi za verifikaciju. Pokušajte ponovo.";

# Product Bundles

$_LANG['bundledeal'] = "Prodaja više paketa!";
$_LANG['bundlevaliddateserror'] = "Prodaja više paketa nije dostupna";
$_LANG['bundlevaliddateserrordesc'] = "Ova opcija ili nije još aktivna ili je istekla. Ukoliko mislite da je ovo pogrešno molimo kontaktirajte podršku.";
$_LANG['bundlemaxusesreached'] = "Opcije nije dostupna";
$_LANG['bundlemaxusesreacheddesc'] = "Ova opcija je dostigla najveći broj dozvoljenih korisnika tako da vise nije dostupna. Molimo vas kontaktirajte nas ukoliko ste zainteresirani za naše usluge da vidimo sto možemo učiniti za vas.";
$_LANG['bundlereqsnotmet'] = "Preduvjeti za opciju nisu zadovoljeni";
$_LANG['bundlewarningpromo'] = "Izabrana opcija se nemože koristiti sa bilo kojim drugim promotivnim opcijama";
$_LANG['bundlewarningproductcycle'] = "Selektirana opcija traži da odaberete vrjeme plačanja '%s' za proizvod %s da bi bila omogućena";
$_LANG['bundlewarningproductconfopreq'] = "Selektirana opcija traži da odaberete '%s' za '%s' da bi ste se kvalificirali za nju";
$_LANG['bundlewarningproductconfopyesnoenable'] = "Selektirana opcija traži da odaberete opciju '%s' da bi ste se kvalificirali za nju";
$_LANG['bundlewarningproductconfopyesnodisable'] = "Selektirana opcija traži da ne odaberete '%s' da bi ste se kvalificirali";
$_LANG['bundlewarningproductconfopqtyreq'] = "Selektirana opcija traži da odaberete količinu '%s' za '%s' da bi ste se kvalificirali";
$_LANG['bundlewarningproductaddonreq'] = "Selektirana opcija traži da odaberete dodatak '%s' za proizvod %s da bi ste se kvalificirali";
$_LANG['bundlewarningdomainreq'] = "Selektirana opcija traži da prebacite ili kupite domenu %s da se kvalificirate";
$_LANG['bundlewarningdomaintld'] = "Selektirana opcija traži da odaberete domenu sa ekstenijom(ama) '%s' za domenu %s da bi ste se kvalificirali";
$_LANG['bundlewarningdomainregperiod'] = "Selektirana opcija traži da odaberete registracijski period '%s' za domenu %s da bi ste se kvalificirali";
$_LANG['bundlewarningdomainaddon'] = "Selektirana opcija traži da odaberete dodatak '%s' za domenu %s da bi ste se kvalificirali";

# New Client Area Template  Lines

$_LANG['navservices'] = "Usluge";
$_LANG['navservicesorder'] = "Naruči nove usluge";
$_LANG['navdomains'] = "Domene";
$_LANG['navrenewdomains'] = "Obnovi domene";
$_LANG['navregisterdomain'] = "Registriraj novu domenu";
$_LANG['navtransferdomain'] = "Premjestite domenu kod nas";
$_LANG['navwhoislookup'] = "Pretraga Domena";
$_LANG['navbilling'] = "Računi";
$_LANG['navsupport'] = "Podrška";
$_LANG['navtickets'] = "Zahtjevi";
$_LANG['navopenticket'] = "Podnesi zahjtev";
$_LANG['navmanagecc'] = "Upravljaj kreditnom karticom";
$_LANG['navemailssent'] = "Poslana pošta";

$_LANG['hello'] = "Pozdrav";
$_LANG['account'] = "Račun";
$_LANG['login'] = "Prijava";
$_LANG['register'] = "Registtracija";
$_LANG['forgotpw'] = "Zaboravili ste lozinku?";
$_LANG['editaccountdetails'] = "Uredite informacije o računu";

$_LANG['clientareanavccdetails'] = "Detalji kreditne kartice";
$_LANG['clientareanavcontacts'] = "Kontakti";

$_LANG['manageyouraccount'] = "Upravljajte svojim računom";
$_LANG['accountoverview'] = "Pregled računa";
$_LANG['paymentmethod'] = "Način plaćanja";
$_LANG['paymentmethoddefault'] = "Odaberi zadano (Postavi po narudžbi)";
$_LANG['productmanagementactions'] = "Upravljačke aktivnosti";
$_LANG['clientareanoaddons'] = "Nema još kupljenih dodataka";
$_LANG['downloadssearch'] = "Pretraži datoteke";
$_LANG['emailviewmessage'] = "Pogledaj poruku";
$_LANG['resultsperpage'] = "Rezultata po stranici";
$_LANG['accessdenied'] = "Pristup zabranjen";
$_LANG['search'] = "Traži";
$_LANG['cancel'] = "Odustani";
$_LANG['clientareabacklink'] = "&laquo; Nazad";
$_LANG['backtoserviceslist'] = "&laquo; Back to Services List";
$_LANG['backtodomainslist'] = "&laquo; Back to Domains List";

$_LANG['clientareahomeorder'] = "Otvorite obrazac za narudžbu kako biste pregledali proizvode i usluge koji nudimo. Postojeći klijenti također ovdje mogu kupiti dodatne opcije za svoje usluge/proizvode.";
$_LANG['clientareahomelogin'] = "Već ste se registrirali kod nas? Ako jeste, kliknite na donji gumb za prijavu u korisničku zonu u kojoj možete upravljati svojim računom.";
$_LANG['clientareahomeorderbtn'] = "Idi na obrazac za naručivanje";
$_LANG['clientareahomeloginbtn'] = "Sigurna prijava korisnika";

$_LANG['clientareaproductsintro'] = "Ovo su sve usluge koje su registrirane uz ovaj račun";
$_LANG['clientareaproductdetailsintro'] = "Here is an overview of your product/service with us.";
$_LANG['clientareadomainsintro'] = "Ovo su sve domene koje su registrirane uz ovaj račun.";
$_LANG['invoicesintro'] = "Dolje možete pregledati cijelu povijest vaših financija s nama.";
$_LANG['quotesintro'] = "Ovdje su sve Vaše ponude koje smo kreirali za Vas.";
$_LANG['emailstagline'] = "Ovdje su sve kopije nedavne el. pošte koju samo Vam slali...";
$_LANG['supportticketsintro'] = "Podnesite i pratite ovdje sve svoje zahtjeve prema nama...";
$_LANG['addfundsintro'] = "Uplatite novac unaprijed";
$_LANG['registerintro'] = "Kreirajte račun kod nas. . .";
$_LANG['masspayintro'] = "Platite sve račune koji su izlistani dolje jednom jedinom transakcijom odabirom metode plaćanja.";
$_LANG['domaincheckerintro'] = "Krenite s pretragom slobodne domene...";
$_LANG['networkstatusintro'] = "Status servera i vijesti o mrežnom statusu.";

$_LANG['creditcardyourinfo'] = "Informacije o računima i naplati";
$_LANG['ourlatestnews'] = "Najnovije vijesti";
$_LANG['ccexpiringsoon'] = "Kreditna kartice uskoro ističe";
$_LANG['ccexpiringsoondesc'] = "Vaša kreditna kartica uskoro ističe, molim Vas osigurajte %s osvježavanje Vaših podataka%s kad stignete";
$_LANG['availcreditbal'] = "Stanje kreditnog računa";
$_LANG['availcreditbaldesc'] = "Kod nas imate iznos kredita od %s i to će automatski biti pridodano prvom novom računu.";
$_LANG['youhaveoverdueinvoices'] = "You have %s Overdue Invoice(s)";
$_LANG['overdueinvoicesdesc'] = "Da biste izbjegli prekid usluge, molim Vas da platite otvorene račune što prije. %sPlati odmah &raquo;%s";
$_LANG['supportticketsnoneopen'] = "Trenutno nemate otvorenih zahtjeva";
$_LANG['invoicesnoneunpaid'] = "Trenutno nemate neplaćenih računa";

$_LANG['registerdisablednotice'] = "Za registraciju, molimo Vas da ispunite <strong><a href=\"cart.php\">narudžbu</a></strong>";

$_LANG['pwstrength'] = "Jačina lozinke";
$_LANG['pwstrengthenter'] = "Unesite lozinku";
$_LANG['pwstrengthweak'] = "Slaba lozinka";
$_LANG['pwstrengthmoderate'] = "Umjerno jaka lozinka";
$_LANG['pwstrengthstrong'] = "Jaka lozinka";

$_LANG['managing'] = "Upravljanje";
$_LANG['information'] = "Informacije";
$_LANG['withselected'] = "S odabranim";
$_LANG['managedomain'] = "Upravljanje domenom";
$_LANG['changenameservers'] = "Promijeni Nameservere";
$_LANG['clientareadomainmanagedns'] = "Upravljaj DNS-ovima";
$_LANG['clientareadomainmanageemailfwds'] = "Upravljaj proslijeđivanjem E-maila";
$_LANG['moduleactionsuccess'] = "Akcija uspješno završena!";
$_LANG['moduleactionfailed'] = "Akcija nije uspjela";

$_LANG['domaininfoexp'] = "Ovdje desno možete pronaći detalje o svojoj domeni. Za upravljanje domenom koristite gornje tabove.";
$_LANG['domainrenewexp'] = "Omogući automatsku obnovu kako biste automaski dobivali obavijesti prije nego što Vam domena istekne.";
$_LANG['domainnsexp'] = "Ovdje možete promijeniti usmjeravanje vaše domene. Molimo Vas da uzmete u obzir da je za promjene potrebno i do 24 sata propagacije.";
$_LANG['domainlockingexp'] = "Zaključajte svoju domenu kako biste ju zaštitili od neovlaštenog transfera.";
$_LANG['domaincurrentlyunlocked'] = "Domena je trenutno otključana!";
$_LANG['domaincurrentlyunlockedexp'] = "Trebali bi ste zaključati registar, osim u slučaju da premještate domenu.";
$_LANG['searchmultipletlds'] = "Search Multiple TLDs";

$_LANG['networkstatustitle'] = "Status mreže";
$_LANG['networkstatusnone'] = "Trenutno nema problema s %s Mrežom";
$_LANG['serverstatusheadingtext'] = "Dolje je pregled u stvarnom vremenu naših servera.";

$_LANG['clientareacancelreasonrequired'] = "Morate unijeti razlog otkazivanja";

$_LANG['addfundsdescription'] = "Dodajte sredstva na Vaš račun, kako biste izbjegli puno malih transakcija i omogućili automatsko generiranje računa.";
$_LANG['addfundsnonrefundable'] = "* Svi depozitu su nepovratni.";

$_LANG['creditcardexpirydateinvalid'] = "Datum isteka mora biti unesen u formatu MM/GG i ne smije biti u prošlosti";

$_LANG['domaincheckerchoosedomain'] = "Izaberite domenu...";
$_LANG['domaincheckerchecknewdomain'] = "Provjerite dostupnost nove domene";
$_LANG['domaincheckerdomainexample'] = " npr. yourdomain.com";
$_LANG['domaincheckerinvalidtld'] = "nije valjana TLD. Molim Vas pokušajte iznova.";
$_LANG['domaincheckerhostingonly'] = "Naruči samo hosting uslugu";
$_LANG['domaincheckeravailtransfer'] = "Dostupna za transfer";
$_LANG['domaincheckerenterdomain'] = "Prije nego krenete s naručivanjem usluge hostinga kod nas, provjerite da li je domena koju želite slobodna ili ćete napraviti transfer ili želite naručiti samo hosting...";
$_LANG['domaincheckerbulkinvaliddomain'] = "Jedna ili više domena, koje ste unijeli dolje je neispravna i zbog toga je isključena iz rezultata.";

$_LANG['kbquestionsearchere'] = "Imate pitanja? Krenite s pretragom ovdje.";
$_LANG['contactus'] = "Kontaktirajte nas";

$_LANG['opennewticket'] = "Podnesi novi zahtjev";
$_LANG['searchtickets'] = "Unesite broj zahtjeva ili naslov";
$_LANG['supportticketspriority'] = "Važnost";
$_LANG['supportticketsubmitted'] = "Podnesen";
$_LANG['supportticketscontact'] = "Kontakt";
$_LANG['supportticketsticketlastupdated'] = "Zadnja izmjena";

$_LANG['upgradedowngradepackage'] = "Upgrade/Downgrade";
$_LANG['upgradedowngradechooseproduct'] = "Izaberi proizvod";

$_LANG['jobtitlereqforcompany'] = "(Obavezno u slučaju da je upisano ime organizacije)";

$_LANG['downloadproductrequired'] = "Downloading this item requires you to have an active instance of the following product/service:";

$_LANG['affiliatesignuptitle'] = "Get Paid for Referring Customers to Us";
$_LANG['affiliatesignupintro'] = "Activate your affiliate account and start earning money today...";
$_LANG['affiliatesignupinfo1'] = "We pay commissions for every signup that comes via your custom signup link.";
$_LANG['affiliatesignupinfo2'] = "We track the visitors you refer to us using cookies, so users you refer don't have to purchase instantly for you to receive your commission.  Cookies last for up to 90 days following the initial visit.";
$_LANG['affiliatesignupinfo3'] = "If you would like to find out more, please contact us.";

# Version 5.1

$_LANG['copyright'] = "Copyright";
$_LANG['allrightsreserved'] = "All Rights Reserved";
$_LANG['supportticketsclose'] = "Close Ticket";
$_LANG['affiliatesinitialthen'] = "Initially then";
$_LANG['invoicesoutstandingbalance'] = "Outstanding Balance";

$_LANG['cpanellogin'] = "Login to cPanel";
$_LANG['cpanelwhmlogin'] = "Login to WHM";
$_LANG['cpanelwebmaillogin'] = "Login to Webmail";
$_LANG['enkompasslogin'] = "Login to Enkompass";
$_LANG['plesklogin'] = "Login to Plesk Control Panel";
$_LANG['helmlogin'] = "Login to Helm Control Panel";
$_LANG['hypervmrestart'] = "Restart VPS Server";
$_LANG['siteworxlogin'] = "Login to SiteWorx Control Panel";
$_LANG['nodeworxlogin'] = "Login to NodeWorx Control Panel";
$_LANG['veportallogin'] = "Login to vePortal";
$_LANG['virtualminlogin'] = "Login to Control Panel";
$_LANG['websitepanellogin'] = "Login to Control Panel";
$_LANG['whmsoniclogin'] = "Login to Control Panel";
$_LANG['xpanelmaillogin'] = "Login to Webmail";
$_LANG['xpanellogin'] = "Login to XPanel";
$_LANG['heartinternetlogin'] = "Login to Control Panel";
$_LANG['gamecplogin'] = "Login to GameCP";
$_LANG['fluidvmrestart'] = "Restart VPS Server";
$_LANG['enomtrustedesc'] = "The TRUSTe Control Panel contains the set up wizard to get your Privacy Policy up and running.";
$_LANG['enomtrustelogin'] = "Login to TrustE Control Panel";
$_LANG['directadminlogin'] = "Login to DirectAdmin";
$_LANG['centovacastlogin'] = "Login to Centova Cast";
$_LANG['castcontrollogin'] = "Login to Control Panel";

$_LANG['sslconfigurenow'] = "Configure Now";
$_LANG['sslprovisioningdate'] = "SSL Provisioning Date";
$_LANG['globalsignvoucherscode'] = "Your OneClickSSL Voucher Code";
$_LANG['globalsignvouchersnotissued'] = "Not Yet Issued";

$_LANG['domaintrffailreasonunavailable'] = "Failure Reason Unavailable";

$_LANG['clientareaprojects'] = "My Projects";

$_LANG['clientgroupdiscount'] = "Client Discount";
$_LANG['billableitemshours'] = "Hours";
$_LANG['billableitemshour'] = "Hour";

$_LANG['invoicefilename'] = "Invoice-";
$_LANG['quotefilename'] = "Quote-";

# Licensing Addon

$_LANG['licensingkey'] = "License Key";
$_LANG['licensingvaliddomains'] = "Valid Domains";
$_LANG['licensingvalidips'] = "Valid IPs";
$_LANG['licensingvaliddirectory'] = "Valid Directory";
$_LANG['licensingstatus'] = "License Status";
$_LANG['licensingreissue'] = "Reissue License";
$_LANG['licensingreissued'] = "The Valid Domain, IP and Directory will be detected & saved the next time the license is used.";

# Domain Addons

$_LANG['domainaddons'] = "Addons";
$_LANG['domainaddonsinfo'] = "The following addons are available for your domain(s)...";
$_LANG['domainaddonsdnsmanagement'] = "DNS Host Record Management";
$_LANG['domainaddonsidprotectioninfo'] = "Protect your personal information and reduce the amount of spam to your inbox by enabling ID Protection.";
$_LANG['domainaddonsdnsmanagementinfo'] = "External DNS Hosting can help speed up your website and improve availability with reduced redundancy.";
$_LANG['domainaddonsemailforwardinginfo'] = "Get emails forwarded to alternate email addresses of your choice so that you can monitor all from a single account.";
$_LANG['domainaddonsbuynow'] = "Buy Now for";
$_LANG['domainaddonsperyear'] = "/Year";
$_LANG['domainaddonscancelareyousure'] = "Are you sure you want to disable & cancel this domain addon?";
$_LANG['domainaddonsconfirm'] = "Confirm Cancellation";
$_LANG['domainaddonscancelsuccess'] = "Addon Deactivated Successfully!";
$_LANG['domainaddonscancelfailed'] = "Failed to deactivate addon. Please contact support.";

# Version 5.2

$_LANG['yourclientareahostingaddons'] = "You have the following addons for this product.";
$_LANG['loginrequired'] = "Login Required";
$_LANG['unsubscribe'] = "Unsubscribe";
$_LANG['emailoptout'] = "Newsletter Opt-out";
$_LANG['newsletterunsubscribe'] = "Newsletter Unsubscribe";
$_LANG['emailoptoutdesc'] = "Tick to unsubscribe from our newsletters";
$_LANG['alreadyunsubscribed'] = "You have already unsubscribed from our newsletter.";
$_LANG['newsletterresubscribe'] = "If you wish to re-subscribe you can do so from the %sMy Details%s section of our client area at any time.";
$_LANG['unsubscribehashinvalid'] = "Unsubscribe failed, please contact support.";
$_LANG['unsubscribesuccess'] = "Unsubscribe Successful";
$_LANG['newsletterremoved'] = "Thank you, Your email has now been removed from our mailing list.";
$_LANG['erroroccured'] = "An Error Occurred";
$_LANG['pwresetsuccessdesc'] = "Your password has now been reset. %sClick here%s to continue to the client area...";
$_LANG['pwresetenternewpw'] = "Please enter your desired new password below.";
$_LANG['ordererrorsbudomainbanned'] = "The subdomain prefix you entered is not allowed - please try another";

$_LANG['ticketfeedbacktitle'] = "Feedback Request for Ticket";

$_LANG['nosupportdepartments'] = "No support departments found. Please try again later.";

$_LANG['feedbackclosed'] = "Feedback cannot be provided until the ticket is closed";
$_LANG['feedbackprovided'] = "You have already provided feedback for this ticket";
$_LANG['feedbackthankyou'] = "We thank you for taking the time to provide your feedback.";
$_LANG['feedbackreceived'] = "Submission Received";
$_LANG['feedbackdesc'] = "Please can we ask you to take a moment of your time to fill out the below form about the quality of your experience with our support team.";
$_LANG['feedbackclickreview'] = "Click here to Review The Ticket";
$_LANG['feedbackopenedat'] = "Opened At";
$_LANG['feedbacklastreplied'] = "Last Replied To";
$_LANG['feedbackstaffinvolved'] = "Staff Involved";
$_LANG['feedbacktotalduration'] = "Total Duration";
$_LANG['feedbackpleaserate1'] = "Please rate (on a scale of 1 to 10) how well";
$_LANG['feedbackpleasecomment1'] = "Please comment on how well";
$_LANG['feedbackhandled'] = "handled this support request";
$_LANG['feedbackworst'] = "Worst";
$_LANG['feedbackbest'] = "Best";
$_LANG['feedbackimprove'] = "How may we make your experience better in the future?";
$_LANG['pleaserate2'] = "handled this support request";
$_LANG['returnclient'] = "Return to Client Area";

$_LANG['clientareanavsecurity'] = "Security Settings";
$_LANG['twofactorauth'] = "Two-Factor Authentication";
$_LANG['twofaenable'] = "Enable Two-Factor Authentication";
$_LANG['twofadisable'] = "Disable Two-Factor Authentication";
$_LANG['twofaenableclickhere'] = "Click here to Enable";
$_LANG['twofadisableclickhere'] = "Click here to Disable";
$_LANG['twofaenforced'] = "The system administrator has enforced that you must enable Two-Factor Authentication before you can continue. This page will guide you through the process of setting it up.";
$_LANG['twofasetup'] = "Two-Factor Authentication Setup Process";
$_LANG['twofasetupgetstarted'] = "Get Started";
$_LANG['twofaactivationintro'] = "Two-Factor Authentication adds an extra layer of protection to logins. Once enabled &amp; configured, each time you sign in you will be asked to enter both your username & password as well as a second factor such as a security code.";
$_LANG['twofaactivationmultichoice'] = "To continue, please choose your desired Two-Factor Authentication method from below.";
$_LANG['twofadisableintro'] = "To disable Two-Factor Authentication please confirm your password in the field below.";
$_LANG['twofaactivationerror'] = "An error occurred while attempting to activate Two-Factor Authentication for your account. Please try again.";
$_LANG['twofamoduleerror'] = "An error occurred loading the module. Please try again.";
$_LANG['twofaactivationcomplete'] = "Two-Factor Authentication Setup is Complete!";
$_LANG['twofadisableconfirmation'] = "Two-Factor Authentication has now been disabled for your account.";
$_LANG['twofabackupcodeis'] = "Your Backup Code is";
$_LANG['twofanewbackupcodeis'] = "Your New Backup Code is";
$_LANG['twofabackupcodelogin'] = "Enter Your Backup Code Above to Login";
$_LANG['twofabackupcodeexpl'] = "Write this down on paper and keep it safe.<br />It will be needed if you ever lose your 2nd factor device or it is unavailable to you.";
$_LANG['twofaconfirmpw'] = "Enter Your Password";
$_LANG['twofa2ndfactorreq'] = "Your second factor is required to complete login.";
$_LANG['twofa2ndfactorincorrect'] = "The second factor you supplied was incorrect. Please try again.";
$_LANG['twofabackupcodereset'] = "Login via Backup Code Successful. Backup Codes are valid once only. It will now be reset.";
$_LANG['twofacantaccess2ndfactor'] = "Can't Access Your 2nd Factor Device?";
$_LANG['twofaloginusingbackupcode'] = "Login using Backup Code";
$_LANG['twofageneralerror'] = "An error occurred loading the module. Please try again.";

$_LANG['continue'] = "Continue";
$_LANG['disable'] = "Disable";
$_LANG['manage'] = "Manage";
