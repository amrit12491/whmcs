INSERT INTO `tbladminperms` (`roleid`, `permid`) VALUES ('1', '123'), ('1', '124'), ('2', '123'), ('2', '124');

UPDATE tblconfiguration SET value='5.1.2' WHERE setting='Version';